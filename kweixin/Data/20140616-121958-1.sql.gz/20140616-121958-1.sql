-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : weiphp
-- 
-- Part : #1
-- Date : 2014-06-16 12:19:58
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `wp_action`
-- -----------------------------
DROP TABLE IF EXISTS `wp_action`;
CREATE TABLE `wp_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='系统行为表';

-- -----------------------------
-- Records of `wp_action`
-- -----------------------------
INSERT INTO `wp_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一�\�', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了管理中�\�', '1', '0', '1393685660');
INSERT INTO `wp_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上�\�5�\�', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `wp_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '0', '1383285646');
INSERT INTO `wp_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上�\�5�\�', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章�\�\r\n表[model]，记录编号[record]�\�', '2', '0', '1386139726');
INSERT INTO `wp_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上�\�10�\�', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `wp_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `wp_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模�\�', '', '', '1', '1', '1383295057');
INSERT INTO `wp_action` VALUES ('8', 'update_attribute', '更新属�\�', '新增或更新或删除属�\�', '', '', '1', '1', '1383295963');
INSERT INTO `wp_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `wp_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `wp_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');
INSERT INTO `wp_action` VALUES ('12', 'admin_login', '登录后台', '管理员登录后�\�', '', '[user|get_nickname]在[time|time_format]登录了后�\�', '2', '1', '1393685618');

-- -----------------------------
-- Table structure for `wp_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_action_log`;
CREATE TABLE `wp_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1455 DEFAULT CHARSET=utf8 COMMENT='行为日志表';

-- -----------------------------
-- Records of `wp_action_log`
-- -----------------------------
INSERT INTO `wp_action_log` VALUES ('1447', '12', '1', '454300729', 'member', '1', 'joint4�\�2014-06-13 18:11登录了后�\�', '1', '1402654275');
INSERT INTO `wp_action_log` VALUES ('1448', '7', '1', '454300729', 'model', '64', '操作url�\�/index.php?s=/Admin/Model/update.html', '1', '1402657526');
INSERT INTO `wp_action_log` VALUES ('1449', '12', '1', '454300729', 'member', '1', 'joint4�\�2014-06-14 15:09登录了后�\�', '1', '1402729772');
INSERT INTO `wp_action_log` VALUES ('1450', '12', '376', '454300729', 'member', '376', 'joint5�\�2014-06-14 17:23登录了后�\�', '1', '1402737788');
INSERT INTO `wp_action_log` VALUES ('1451', '12', '376', '454300729', 'member', '376', 'joint5�\�2014-06-14 17:23登录了后�\�', '1', '1402737810');
INSERT INTO `wp_action_log` VALUES ('1452', '12', '1', '454300729', 'member', '1', 'joint4�\�2014-06-14 17:30登录了后�\�', '1', '1402738200');
INSERT INTO `wp_action_log` VALUES ('1453', '12', '1', '454301311', 'member', '1', 'joint4�\�2014-06-16 09:11登录了后�\�', '1', '1402881112');
INSERT INTO `wp_action_log` VALUES ('1454', '12', '1', '454301311', 'member', '1', 'joint4�\�2014-06-16 12:19登录了后�\�', '1', '1402892369');

-- -----------------------------
-- Table structure for `wp_addon_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_addon_category`;
CREATE TABLE `wp_addon_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `icon` int(10) unsigned NOT NULL COMMENT '分类图标',
  `title` varchar(255) NOT NULL COMMENT '分类名',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_addon_category`
-- -----------------------------
INSERT INTO `wp_addon_category` VALUES ('1', '74', '教育行业', '2');
INSERT INTO `wp_addon_category` VALUES ('2', '74', '基础插件', '0');
INSERT INTO `wp_addon_category` VALUES ('3', '74', '互动�\�', '1');
INSERT INTO `wp_addon_category` VALUES ('4', '74', '高级插件', '3');

-- -----------------------------
-- Table structure for `wp_addons`
-- -----------------------------
DROP TABLE IF EXISTS `wp_addons`;
CREATE TABLE `wp_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  `type` tinyint(1) DEFAULT '0' COMMENT '插件类型 0 普通插件 1 微信插件 2 易信插件',
  `cate_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `wp_addons`
-- -----------------------------
INSERT INTO `wp_addons` VALUES ('15', 'EditorForAdmin', '后台编辑�\�', '用于增强整站长文本的输入和显�\�', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"2\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '0', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512015', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('22', 'DevTeam', '开发团队信�\�', '开发团队成员信�\�', '0', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1391687096', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信�\�', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('5', 'Editor', '前台编辑�\�', '用于增强整站长文本的输入和显�\�', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '0', 'null', 'thinkphp', '0.1', '1379842319', '1', '0', '');
INSERT INTO `wp_addons` VALUES ('9', 'SocialComment', '通用社交化评�\�', '集成了各种社交化评论插件，轻松集成到系统中�\�', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"1669260\",\"comment_short_name_duoshuo\":\"\",\"comment_form_pos_duoshuo\":\"buttom\",\"comment_data_list_duoshuo\":\"10\",\"comment_data_order_duoshuo\":\"asc\"}', 'thinkphp', '0.1', '1380273962', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('16', 'Vote', '投票', '支持文本和图片两类的投票功能', '1', '{\"random\":\"1\"}', '地下凡星', '0.1', '1388811198', '1', '1', '3');
INSERT INTO `wp_addons` VALUES ('17', 'Chat', '智能聊天', '通过网络上支持的智能API，实现：天气、翻译、藏头诗、笑话、歌词、计算、域名信�\�/备案/收录查询、IP查询、手机号码归属、人工智能聊天等功能', '1', '{\"simsim_key\":\"41250a68-3cb5-43c8-9aa2-d7b3caf519b1\",\"simsim_url\":\"http:\\/\\/sandbox.api.simsimi.com\\/request.p\",\"i9_url\":\"http:\\/\\/www.xiaojo.com\\/bot\\/chata.php\",\"rand_reply\":\"\\u6211\\u4eca\\u5929\\u7d2f\\u4e86\\uff0c\\u660e\\u5929\\u518d\\u966a\\u4f60\\u804a\\u5929\\u5427\\r\\n\\u54c8\\u54c8~~\\r\\n\\u4f60\\u8bdd\\u597d\\u591a\\u554a\\uff0c\\u4e0d\\u8ddf\\u4f60\\u804a\\u4e86\\r\\n\\u867d\\u7136\\u4e0d\\u61c2\\uff0c\\u4f46\\u89c9\\u5f97\\u4f60\\u8bf4\\u5f97\\u5f88\\u5bf9\\r\\n123\"}', '地下凡星', '0.1', '1389454867', '0', '1', '2');
INSERT INTO `wp_addons` VALUES ('18', 'Wecome', '欢迎�\�', '用户关注公众号时发送的欢迎信息，支持文本，图片，图文的信息', '1', '{\"type\":\"1\",\"title\":\"\",\"description\":\"欢迎关注，请<a href=\"[follow]\">绑定账号</a>后体验更多功�\�\",\"pic_url\":\"\",\"url\":\"\"}', '地下凡星', '0.1', '1389620372', '0', '1', '2');
INSERT INTO `wp_addons` VALUES ('19', 'UserCenter', '微信用户中心', '实现3G首页、微信登录，微信用户绑定，微信用户信息初始化等基本功�\�', '1', '{\"random\":\"1\"}', '地下凡星', '0.1', '1390660425', '1', '1', '2');
INSERT INTO `wp_addons` VALUES ('23', 'HelloWorld', '微信示列', '这是一个临时描�\�', '1', 'null', '无名', '0.1', '1393038143', '0', '1', '');
INSERT INTO `wp_addons` VALUES ('24', 'BaiduStatistics', '百度统计', '这是百度统计功能，只要开启插件并设置统计代码，就可以使用统计功能�\�', '1', '{\"code\":\"\"}', 'weiphp.cn', '1.0', '1393116011', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('56', 'CustomMenu', '自定义菜�\�', '自定义菜单能够帮助公众号丰富界面，让用户更好更快地理解公众号的功�\�', '1', 'null', '凡星', '0.1', '1398264735', '1', '1', '2');
INSERT INTO `wp_addons` VALUES ('31', 'Robot', '机器人聊�\�', '实现的效果如�\�\r\n用户输入：“机器人学习时间�\�\r\n微信回复：“你的问题是？�\�\r\n用户输入：“这个世界上谁最美？�\�\r\n微信回复�\� “你的答案是？�\�\r\n用户回复�\� “当然是你啦！�\�\r\n微信回复：“我明白啊，不信你可以问问我�\�\r\n用户回复：“这个世界上谁最美？�\�\r\n微信回复：“当然是你啦！�\�', '1', 'null', '地下凡星', '0.1', '1393987090', '0', '1', '4');
INSERT INTO `wp_addons` VALUES ('36', 'Extensions', '融合第三�\�', '第三方功能扩�\�', '1', 'null', '地下凡星', '0.1', '1394268715', '1', '1', '4');
INSERT INTO `wp_addons` VALUES ('32', 'Suggestions', '建议意见', '用户在微信里输入“建议意见”四个字时，返回一个图文信息，引导用户进入填写建议意见�\�3G页面，用户填写信息提交后显示感谢之意并提示关闭页面返回微�\�\r\n管理员可以在管理中心里看到用户反馈的内容列表，并对内容进行编辑，删除操作', '1', '{\"need_truename\":\"0\",\"need_mobile\":\"0\"}', '地下凡星', '0.1', '1394264272', '1', '1', '3');
INSERT INTO `wp_addons` VALUES ('38', 'Card', '会员�\�', '这是一个临时描�\�', '1', 'null', '无名', '0.1', '1395235360', '0', '1', '2');
INSERT INTO `wp_addons` VALUES ('39', 'WeiSite', '微官�\�', '微官�\�', '1', 'null', '凡星', '0.1', '1395326578', '0', '1', '4');
INSERT INTO `wp_addons` VALUES ('42', 'Leaflets', '微信宣传�\�', '微信公众号二维码推广页面，用作推广或者制作广告易拉宝，可以发布到QQ群微博博客论坛等�\�...', '1', '{\"random\":\"1\"}', '凡星', '0.1', '1396056935', '0', '1', '2');
INSERT INTO `wp_addons` VALUES ('48', 'CustomReply', '自定义回�\�', '这是一个临时描�\�', '1', 'null', '凡星', '0.1', '1396578089', '1', '1', '2');
INSERT INTO `wp_addons` VALUES ('49', 'Forms', '通用表单', '管理员可以轻松地增加一个表单用于收集用户的信息，如活动报名、调查反馈、预约填单等', '1', 'null', '凡星', '0.1', '1396688995', '1', '1', '4');
INSERT INTO `wp_addons` VALUES ('50', 'Survey', '微调�\�', '这是一个临时描�\�', '1', 'null', '凡星', '0.1', '1396883644', '1', '1', '3');
INSERT INTO `wp_addons` VALUES ('51', 'Exam', '微考试', '主要功能有试卷管理，题目录入管理，考生信息和考分汇总管理�\�', '1', 'null', '凡星', '0.1', '1397035112', '1', '1', '1');
INSERT INTO `wp_addons` VALUES ('53', 'Test', '微测�\�', '主要功能有问卷管理，题目录入管理，用户信息和得分汇总管理�\�', '1', 'null', '凡星', '0.1', '1397142151', '1', '1', '1');
INSERT INTO `wp_addons` VALUES ('54', 'Diy', '万能页面', '可以通过拖拉的方式配置一�\�3G页面', '1', 'null', '凡星', '0.1', '1397360521', '1', '1', '4');
INSERT INTO `wp_addons` VALUES ('58', 'Cascade', '级联菜单', '支持无级级联菜单，用于地区选择、多层分类选择等场景。菜单的数据来源支持查询数据库和直接用户按格式输入两种方�\�', '1', 'null', '凡星', '0.1', '1398694996', '0', '0', '');
INSERT INTO `wp_addons` VALUES ('59', 'Coupon', '优惠�\�', '配合粉丝圈子，打造粉丝互动的运营激励基础', '1', 'null', '凡星', '0.1', '1399259217', '1', '1', '3');
INSERT INTO `wp_addons` VALUES ('60', 'Scratch', '刮刮�\�', '刮刮�\�', '1', 'null', '凡星', '0.1', '1399273157', '1', '1', '3');
INSERT INTO `wp_addons` VALUES ('63', 'Juhe', '聚合数据', '集成聚合数据（http://www.juhe.cn）平台的功能', '1', '{\"stock\":\"\",\"exchange\":\"\",\"gold\":\"\"}', '凡星', '0.1', '1399810730', '0', '1', '4');
INSERT INTO `wp_addons` VALUES ('64', 'Tongji', '运营统计', '统计每个插件使用情况', '1', 'null', '凡星', '0.1', '1401437689', '1', '1', '2');
INSERT INTO `wp_addons` VALUES ('65', 'MicroCatering', '微餐�\�', '微餐饮是专为餐饮行业开发的微信公众平台营销服务解决方案。基于微信公众平台，顾客可以通过微信查看餐厅介绍、就餐环境、菜品、订餐、订座、指引到店线路，顾客可以享受微信会员卡、积分、优惠券、大转盘刮刮卡等优惠服务。所有点单可通过pc来管理，并且订单有短信、飞信、邮件等多种通知方式�\�', '1', 'null', '陌路生人(Les、拉帮姐�\�)', '0.1', '1402729898', '1', '1', '');

-- -----------------------------
-- Table structure for `wp_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `wp_attachment`;
CREATE TABLE `wp_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `wp_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `wp_attribute`;
CREATE TABLE `wp_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=887 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `wp_attribute`
-- -----------------------------
INSERT INTO `wp_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) NOT NULL', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重�\�', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('4', 'category_id', '所属分�\�', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('6', 'root', '根节�\�', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编�\�', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模�\�', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('10', 'position', '推荐�\�', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相�\�', '1', '1:列表推荐\r\n2:频道页推�\�\r\n4:首页推荐', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转�\�', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处�\�', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('13', 'display', '可见�\�', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可�\�\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `wp_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `wp_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `wp_attribute` VALUES ('16', 'view', '浏览�\�', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('17', 'comment', '评论�\�', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使�\�', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('19', 'level', '优先�\�', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠�\�', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('22', 'status', '数据状�\�', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审�\�\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('25', 'template', '详情页显示模�\�', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定�\�', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('26', 'bookmark', '收藏�\�', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `wp_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('29', 'template', '详情页显示模�\�', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处�\�', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `wp_attribute` VALUES ('34', 'keyword', '关键�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1388815953', '1388815953', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('35', 'addon', '关键词所属插�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '5', '1', '1', '1388816207', '1388816207', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('36', 'aim_id', '插件表里的ID�\�', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '1', '', '5', '1', '1', '1388816287', '1388816287', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('37', 'cTime', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '5', '0', '1', '1388816392', '1388816392', '', '1', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('38', 'keyword', '关键�\�', 'varchar(50) NOT NULL', 'string', '', '用户在微信里回复此关键词将会触发此投票�\�', '1', '', '6', '1', '1', '1392969972', '1388930888', 'keyword_unique', '1', '此关键词已经存在，请换成别的关键词再试试', 'function', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('39', 'title', '投票标题', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '6', '1', '1', '1388931041', '1388931041', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('40', 'description', '投票描述', 'text NOT NULL', 'textarea', '', '', '1', '', '6', '0', '1', '1400633517', '1388931173', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('41', 'picurl', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '支持JPG、PNG格式，较好的效果为大�\�360*200，小�\�200*200', '1', '', '6', '0', '1', '1388931285', '1388931285', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('42', 'type', '选择类型', 'char(10) NOT NULL', 'radio', '0', '', '1', '0:单�\�\r\n1:多�\�', '6', '1', '1', '1388936429', '1388931487', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('43', 'start_date', '开始日�\�', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '6', '0', '1', '1388931734', '1388931734', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('44', 'end_date', '结束日期', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '6', '0', '1', '1388931769', '1388931769', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('45', 'is_img', '文字/图片投票', 'tinyint(2) NOT NULL', 'radio', '0', '', '0', '0:文字投票\r\n1:图片投票', '6', '1', '1', '1389081985', '1388931941', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('46', 'vote_count', '投票�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '6', '0', '1', '1388932035', '1388932035', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('47', 'cTime', '投票创建时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '6', '1', '1', '1388932128', '1388932128', '', '1', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('48', 'vote_id', '投票ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '7', '1', '1', '1388982678', '1388933478', '', '3', '', 'regex', '$_REQUEST[\'vote_id\']', '3', 'string');
INSERT INTO `wp_attribute` VALUES ('49', 'name', '选项标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '7', '1', '1', '1388933552', '1388933552', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('50', 'image', '图片选项', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '5', '', '7', '0', '1', '1388984467', '1388933679', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('51', 'opt_count', '当前选项投票�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '7', '0', '1', '1388933860', '1388933860', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('52', 'order', '选项排序', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '7', '0', '1', '1388933951', '1388933951', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('53', 'vote_id', '投票ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '8', '1', '1', '1388934189', '1388934189', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('54', 'user_id', '用户ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '8', '0', '1', '1388934265', '1388934265', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('55', 'token', '用户TOKEN', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '8', '0', '1', '1388934296', '1388934296', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('56', 'options', '选择选项', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '8', '1', '1', '1388934351', '1388934351', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('57', 'cTime', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '8', '0', '1', '1388934413', '1388934392', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('58', 'mTime', '更新时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '6', '0', '1', '1390634006', '1390634006', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('78', 'is_use', '是否为当前公众号', 'tinyint(2) NOT NULL', 'bool', '0', '', '0', '0:�\�\r\n1:�\�', '11', '0', '1', '1391682184', '1391682184', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('77', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '11', '0', '1', '1392946897', '1391597344', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('66', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '6', '0', '1', '1391397388', '1391397388', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('67', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '5', '0', '1', '1391399528', '1391399528', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('68', 'uid', '用户ID', 'int(10) NOT NULL', 'num', '', '', '0', '', '11', '1', '1', '1391575873', '1391575210', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('69', 'public_name', '公众号名�\�', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '11', '1', '1', '1391576452', '1391575955', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('70', 'public_id', '公众号原始id', 'varchar(100) NOT NULL', 'string', '', '请正确填写，保存后不能再修改，且无法接收到微信的信息', '1', '', '11', '1', '1', '1391576472', '1391576015', '', '3', '公众号原始ID已经存在，请不要重复增加', 'unique', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('71', 'wechat', '微信�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '11', '1', '1', '1391576484', '1391576144', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('72', 'interface_url', '接口地址', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '11', '0', '1', '1392946881', '1391576234', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('73', 'headface_url', '公众号头�\�', 'varchar(255) NOT NULL', 'picture', '', '', '1', '', '11', '0', '1', '1391599849', '1391576300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('74', 'area', '地区', 'varchar(50) NOT NULL', 'string', '', '', '0', '', '11', '0', '1', '1392946934', '1391576435', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('75', 'addon_config', '插件配置', 'text NOT NULL', 'textarea', '', '', '0', '', '11', '0', '1', '1391576537', '1391576537', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('76', 'addon_status', '插件状�\�', 'text NOT NULL', 'textarea', '', '', '0', '', '11', '0', '1', '1391576571', '1391576571', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('187', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '31', '0', '1', '1395485303', '1395485303', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('186', 'content', '通知内容', 'text NOT NULL', 'editor', '', '', '1', '', '31', '0', '1', '1395485247', '1395485247', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('185', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '31', '0', '1', '1395485192', '1395485192', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('183', 'number', '卡号', 'varchar(50) NULL', 'string', '', '', '3', '', '30', '0', '1', '1395484806', '1395483310', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('184', 'cTime', '加入时间', 'int(10) NULL', 'datetime', '', '', '0', '', '30', '0', '1', '1395484366', '1395484366', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('182', 'phone', '手机�\�', 'varchar(30) NULL', 'string', '', '', '1', '', '30', '0', '1', '1395483248', '1395483248', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('181', 'username', '姓名', 'varchar(100) NULL', 'string', '', '', '1', '', '30', '0', '1', '1395483048', '1395483048', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('180', 'uid', '用户UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '30', '0', '1', '1395482973', '1395482973', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('90', 'type', '公众号类�\�', 'char(10) NOT NULL', 'radio', '0', '', '1', '0:订阅�\�\r\n1:服务�\�', '11', '0', '1', '1393718575', '1393718575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('91', 'appid', 'AppId', 'varchar(255) NOT NULL', 'string', '', '认证服务号的AppId', '1', '', '11', '0', '1', '1393718830', '1393718735', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('92', 'secret', 'Secret', 'varchar(255) NOT NULL', 'string', '', '认证服务号的Secret', '1', '', '11', '0', '1', '1393718806', '1393718806', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('93', 'group_id', '等级', 'int(10) UNSIGNED NOT NULL', 'select', '0', '', '0', '', '11', '0', '1', '1393753499', '1393724468', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('94', 'title', '等级�\�', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '13', '0', '1', '1393724854', '1393724854', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('95', 'addon_status', '插件权限', 'text NOT NULL', 'checkbox', '', '', '1', '1:好人\r\n2:环境', '13', '0', '1', '1393731903', '1393725072', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('96', 'version', '版本�\�', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '1', '', '14', '1', '1', '1393770457', '1393770457', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('97', 'title', '升级包名', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '14', '1', '1', '1393770499', '1393770499', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('98', 'description', '描述', 'text NOT NULL', 'textarea', '', '', '1', '', '14', '0', '1', '1393770546', '1393770546', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('99', 'create_date', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '14', '0', '1', '1393770591', '1393770591', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('100', 'download_count', '下载统计', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '14', '0', '1', '1393770659', '1393770659', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('101', 'package', '升级包地址', 'varchar(255) NOT NULL', 'textarea', '', '', '1', '', '14', '1', '1', '1393812247', '1393770727', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('166', 'keyword', '关键�\�', 'varchar(255) NOT NULL', 'string', '', '多个关键词请用空格格开', '1', '', '22', '1', '1', '1393912492', '1393911842', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('165', 'keyword_filter', '关键词过�\�', 'tinyint(2) NOT NULL', 'bool', '0', '如设置电影为触发�\�,用户输入 电影 美国�\� 时，如果启用过滤只将美国派这个词发送到的你的接口，如果不过�\� 就是整个 电影 美国派全部发送到的接�\�', '1', '0:不过�\�\r\n1:过滤', '22', '0', '1', '1394268410', '1393912057', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('161', 'api_token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '22', '0', '1', '1393922455', '1393912408', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('162', 'cTime', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '22', '0', '1', '1393913608', '1393913608', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('108', 'keyword_length', '关键词长�\�', 'int(10) UNSIGNED  NULL', 'num', '0', '', '0', '', '5', '0', '1', '1398837058', '1393918566', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('109', 'keyword_type', '匹配类型', 'tinyint(2)  NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '5', '0', '1', '1393979962', '1393919686', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('110', 'extra_text', '文本扩展', 'text  NULL', 'textarea', '', '', '1', '', '5', '0', '1', '1393919736', '1393919736', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('111', 'extra_int', '数字扩展', 'int(10)  NULL', 'num', '', '', '1', '', '5', '0', '1', '1393919798', '1393919798', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('163', 'api_url', '第三方URL', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '22', '0', '1', '1393912354', '1393912354', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('164', 'output_format', '数据输出格式', 'tinyint(1) NULL', 'select', '0', '', '1', '0:标准微信xml\r\n1:json格式', '22', '0', '1', '1394268422', '1393912288', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('113', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '16', '1', '1', '1394068622', '1394033402', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('114', 'uid', '用户ID', 'int(10) UNSIGNED NULL', 'num', '0', '', '0', '', '16', '0', '1', '1394087760', '1394033447', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('115', 'content', '内容', 'text  NULL', 'editor', '', '', '1', '', '16', '1', '1', '1394033484', '1394033484', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('116', 'cTime', '发布时间', 'int(10)  NULL', 'datetime', '', '', '0', '', '16', '0', '1', '1394033571', '1394033571', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('117', 'attach', '附件', 'varchar(255)  NULL', 'file', '', '', '1', '', '16', '0', '1', '1394033674', '1394033674', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('118', 'is_top', '置顶', 'int(10) NULL', 'num', '0', '0表示不置顶，否则其它值表示置顶且值是置顶的时�\�', '0', '0:不置�\�\r\n1:置顶', '16', '0', '1', '1394068971', '1394068787', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('119', 'cid', '分类', 'tinyint(4)  NULL', 'select', '', '', '1', '1:安装使用\r\n2:BUG反馈\r\n3:发展建议\r\n4:微信需�\�\r\n5:微信开�\�\r\n6:微信运营\r\n7:站内公告', '16', '1', '1', '1394069964', '1394069964', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('120', 'view_count', '浏览�\�', 'int(11) UNSIGNED NULL', 'num', '0', '', '0', '', '16', '0', '1', '1394072168', '1394072168', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('121', 'reply_count', '回复�\�', 'int(11) UNSIGNED NULL', 'num', '0', '', '0', '', '16', '0', '1', '1394072217', '1394072217', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('122', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '17', '1', '1', '1394068622', '1394033402', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('123', 'uid', '用户ID', 'int(10) UNSIGNED NULL', 'num', '0', '', '0', '', '17', '0', '1', '1394087733', '1394033447', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('124', 'content', '内容', 'text  NULL', 'editor', '', '', '1', '', '17', '1', '1', '1394033484', '1394033484', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('125', 'cTime', '发布时间', 'int(10)  NULL', 'datetime', '', '', '0', '', '17', '0', '1', '1394033571', '1394033571', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('126', 'attach', '插件安装�\�', 'varchar(255)  NULL', 'file', '', '', '1', '', '17', '0', '1', '1394084870', '1394033674', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('127', 'is_top', '置顶', 'int(10) NULL', 'num', '0', '0表示不置顶，否则其它值表示置顶且值是置顶的时�\�', '0', '0:不置�\�\r\n1:置顶', '17', '0', '1', '1394068971', '1394068787', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('128', 'cid', '分类', 'tinyint(4)  NULL', 'select', '', '', '1', '1:基础模块\r\n2:行业模块\r\n3:会议活动\r\n4:娱乐模块\r\n5:其它模块', '17', '1', '1', '1394085304', '1394069964', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('129', 'view_count', '浏览�\�', 'int(11) UNSIGNED NULL', 'num', '0', '', '0', '', '17', '0', '1', '1394072168', '1394072168', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('135', 'download_count', '下载�\�', 'int(10) UNSIGNED NULL', 'num', '0', '', '0', '', '17', '0', '1', '1394085763', '1394085763', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('132', 'img_2', '插件截图2', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '17', '0', '1', '1394084821', '1394084714', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('131', 'img_1', '插件截图1', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '17', '0', '1', '1394084842', '1394084635', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('133', 'img_3', '插件截图3', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '17', '0', '1', '1394084757', '1394084757', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('134', 'img_4', '插件截图4', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '17', '0', '1', '1394084797', '1394084797', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('136', 'cTime', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '18', '0', '1', '1393234678', '1393234678', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('137', 'content', '内容', 'text NOT NULL', 'textarea', '', '', '1', '', '18', '1', '1', '1393234583', '1393234583', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('138', 'uid', '用户ID', 'int(10) NOT NULL', 'num', '0', '', '0', '', '18', '0', '1', '1393234534', '1393234534', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('160', 'keyword_type', '关键词类�\�', 'tinyint(2) NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '22', '0', '1', '1394268247', '1393921586', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('652', 'sort', '排序�\�', 'tinyint(4)  NULL', 'num', '0', '数值越小越靠前', '1', '', '85', '0', '1', '1394523288', '1394519175', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('651', 'pid', '一级菜�\�', 'tinyint(2) NULL', 'select', '0', '如果是一级菜单，选择“无”即�\�', '1', '0:�\�', '85', '0', '1', '1394519296', '1394518930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('650', 'title', '菜单�\�', 'varchar(50) NOT NULL', 'string', '', '可创建最�\� 3 个一级菜单，每个一级菜单下可创建最�\� 5 个二级菜单。编辑中的菜单不会马上被用户看到，请放心调试�\�', '1', '', '85', '0', '1', '1394519941', '1394518988', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('649', 'keyword', '关联关键�\�', 'varchar(100) NULL', 'string', '', '关联关键词和关联URL选填一�\�', '1', '', '85', '0', '1', '1394519232', '1394519054', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('648', 'url', '关联URL', 'varchar(255)   NULL', 'string', '', '', '1', '', '85', '0', '1', '1394519090', '1394519090', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('194', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '31', '0', '1', '1395911896', '1395911896', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('195', 'token', 'Token', 'varchar(100) NOT NULL', 'string', '', '', '0', '', '30', '0', '1', '1395973788', '1395912028', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('197', 'title', '分类标题', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '33', '0', '1', '1395988016', '1395988016', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('198', 'icon', '分类图片', 'int(10) UNSIGNED  NULL', 'picture', '', '', '1', '', '33', '0', '1', '1395988966', '1395988966', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('199', 'url', '外链', 'varchar(255) NOT NULL', 'string', '', '为空时默认跳转到该分类的文章列表页面', '1', '', '33', '0', '1', '1401408363', '1395989660', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('200', 'is_show', '显示', 'tinyint(2) NOT NULL', 'bool', '1', '', '1', '0: 不显�\�\r\n1: 显示', '33', '0', '1', '1395989709', '1395989709', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('201', 'token', 'Token', 'varchar(100)  NULL', 'string', '', '', '0', '', '33', '0', '1', '1395989760', '1395989760', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('202', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '34', '1', '1', '1396061575', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('203', 'keyword_type', '关键词类�\�', 'tinyint(2) NULL', 'select', '', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '34', '0', '1', '1396061814', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('204', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '34', '1', '1', '1396061877', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('205', 'intro', '简�\�', 'text NULL', 'textarea', '', '', '1', '', '34', '0', '1', '1396061947', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('206', 'cate_id', '所属类�\�', 'int(10) UNSIGNED NULL', 'select', '0', '要先在微官网分类里配置好分类才可选择', '1', '0:请选择分类', '34', '0', '1', '1396078914', '1396062003', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('207', 'cover', '封面图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '34', '0', '1', '1396062093', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('208', 'content', '内容', 'text NOT NULL', 'editor', '', '', '1', '', '34', '0', '1', '1396062146', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('209', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '34', '0', '1', '1396075102', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('210', 'title', '标题', 'varchar(255) NULL', 'string', '', '可为�\�', '1', '', '35', '0', '1', '1396098316', '1396098316', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('211', 'img', '图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '35', '1', '1', '1396098349', '1396098349', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('212', 'url', '链接地址', 'varchar(255) NULL', 'string', '', '', '1', '', '35', '0', '1', '1396098380', '1396098380', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('213', 'is_show', '是否显示', 'tinyint(2) NULL', 'bool', '1', '', '1', '0:不显�\�\r\n1:显示', '35', '0', '1', '1396098464', '1396098464', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('214', 'sort', '排序', 'int(10) UNSIGNED NULL', 'num', '0', '值越小越靠前', '1', '', '35', '0', '1', '1396098682', '1396098682', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('215', 'token', 'Token', 'varchar(100) NULL', 'string', '', '', '0', '', '35', '0', '1', '1396098747', '1396098747', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('216', 'url', '关联URL', 'varchar(255)   NULL', 'string', '', '', '1', '', '36', '0', '1', '1394519090', '1394519090', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('218', 'title', '菜单�\�', 'varchar(50) NOT NULL', 'string', '', '可创建最�\� 3 个一级菜单，每个一级菜单下可创建最�\� 5 个二级菜单。编辑中的菜单不会马上被用户看到，请放心调试�\�', '1', '', '36', '0', '1', '1394519941', '1394518988', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('219', 'pid', '一级菜�\�', 'tinyint(2) NULL', 'select', '0', '如果是一级菜单，选择“无”即�\�', '1', '0:�\�', '36', '0', '1', '1394519296', '1394518930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('220', 'sort', '排序�\�', 'tinyint(4)  NULL', 'num', '0', '数值越小越靠前', '1', '', '36', '0', '1', '1394523288', '1394519175', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('221', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '36', '0', '1', '1394526820', '1394526820', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('423', 'sort', '排序�\�', 'int(10)  NULL', 'num', '0', '数值越小越靠前', '1', '', '33', '0', '1', '1396340334', '1396340334', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('424', 'icon', '图标', 'int(10) UNSIGNED NULL', 'picture', '', '根据选择的底部模板决定是否需要上传图�\�', '1', '', '36', '0', '1', '1396506297', '1396506297', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('425', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '数值越小越靠前', '1', '', '34', '0', '1', '1396510508', '1396510508', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('426', 'view_count', '浏览�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '34', '0', '1', '1396510630', '1396510630', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('427', 'keyword', '关键�\�', 'varchar(255) NOT NULL', 'string', '', '多个关键词请用空格分开：例�\�: �\� �\� �\�', '1', '', '62', '0', '1', '1396578460', '1396578212', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('428', 'keyword_type', '关键词类�\�', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '62', '0', '1', '1396623302', '1396578249', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('429', 'content', '回复内容', 'text NOT NULL', 'textarea', '', '请不要多�\�1000字否则无法发送。支持加超链接，但URL必须带http://', '1', '', '62', '0', '1', '1396607362', '1396578597', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('430', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '64', '1', '1', '1396061575', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('431', 'keyword_type', '关键词类�\�', 'tinyint(2) NULL', 'select', '', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '64', '0', '1', '1396061814', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('432', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '64', '1', '1', '1396061877', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('433', 'intro', '简�\�', 'text NULL', 'textarea', '', '', '1', '', '64', '0', '1', '1396061947', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('434', 'cate_id', '所属类�\�', 'int(10) UNSIGNED NULL', 'select', '0', '要先在微官网分类里配置好分类才可选择', '1', '0:请选择分类', '64', '0', '1', '1396078914', '1396062003', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('435', 'cover', '封面图片', 'int(10) UNSIGNED NULL', 'picture', '', '', '1', '', '64', '0', '1', '1396062093', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('436', 'content', '内容', 'text NOT NULL', 'editor', '', '', '1', '', '64', '0', '1', '1396062146', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('437', 'cTime', '发布时间', 'int(10) NULL', 'datetime', '', '', '0', '', '64', '0', '1', '1396075102', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('438', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '数值越小越靠前', '1', '', '64', '0', '1', '1396510508', '1396510508', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('439', 'view_count', '浏览�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '64', '0', '1', '1396510630', '1396510630', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('440', 'view_count', '浏览�\�', 'int(10) UNSIGNED NULL', 'num', '0', '', '0', '', '62', '0', '1', '1396580643', '1396580643', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('441', 'sort', '排序�\�', 'int(10) UNSIGNED NULL', 'num', '0', '', '1', '', '62', '0', '1', '1396580674', '1396580674', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('444', 'keyword', '关键�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '65', '0', '1', '1396602514', '1396602514', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('445', 'keyword_type', '关键词类�\�', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '65', '0', '1', '1396602706', '1396602548', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('446', 'mult_ids', '多图文ID', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '65', '0', '1', '1396602601', '1396602578', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('447', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '65', '0', '1', '1396602821', '1396602821', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('448', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '64', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('449', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '62', '0', '1', '1396603007', '1396603007', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('481', 'finish_tip', '用户提交后提示内�\�', 'text NOT NULL', 'textarea', '', '为空默认为：提交成功，谢谢参�\�', '1', '', '69', '0', '1', '1396676366', '1396673689', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('478', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '69', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('479', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '69', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('480', 'password', '表单密码', 'varchar(255) NOT NULL', 'string', '', '如要用户输入密码才能进入表单，则填写此项。否则留空，用户可直接进入表�\�', '0', '', '69', '0', '1', '1396871497', '1396672643', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('472', 'keyword_type', '关键词类�\�', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '69', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('473', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '69', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('474', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '69', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('475', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '69', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('476', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '69', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('471', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '69', '1', '1', '1396866048', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('493', 'type', '字段类型', 'char(50) NOT NULL', 'select', 'string', '用于表单中的展示方式', '1', 'string:单行输入\r\ntextarea:多行输入\r\nradio:单�\�\r\ncheckbox:多�\�\r\nselect:下拉选择\r\ndatetime:时间\r\npicture:上传图片\r\ncascade:级联', '70', '1', '1', '1398742035', '1396683600', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('492', 'title', '字段标题', 'varchar(255) NOT NULL', 'string', '', '请输入字段标题，用于表单显示', '1', '', '70', '1', '1', '1396676830', '1396676830', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('486', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '70', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('511', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '73', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('494', 'extra', '参数', 'text NOT NULL', 'textarea', '', '字段类型为单选、多选、下拉选择和级联选择时的定义数据，其它字段类型为�\�', '1', '', '70', '0', '1', '1396835020', '1396685105', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('495', 'value', '默认�\�', 'varchar(255) NOT NULL', 'string', '', '字段的默认�\�', '1', '', '70', '0', '1', '1396685291', '1396685291', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('490', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '70', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('491', 'name', '字段�\�', 'varchar(100) NOT NULL', 'string', '', '请输入字段名 英文字母开头，长度不超�\�30', '1', '', '70', '1', '1', '1396676840', '1396676792', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('496', 'remark', '字段备注', 'varchar(255) NOT NULL', 'string', '', '用于表单中的提示', '1', '', '70', '0', '1', '1396685482', '1396685482', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('497', 'is_must', '是否必填', 'tinyint(2) NOT NULL', 'bool', '', '用于自动验证', '1', '0:�\�\r\n1:�\�', '70', '0', '1', '1396685579', '1396685579', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('498', 'validate_rule', '正则验证', 'varchar(255) NOT NULL', 'string', '', '为空表示不作验证', '1', '', '70', '0', '1', '1396685776', '1396685776', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('499', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '70', '0', '1', '1396685825', '1396685825', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('500', 'error_info', '出错提示', 'varchar(255) NOT NULL', 'string', '', '验证不通过时的提示�\�', '1', '', '70', '0', '1', '1396685920', '1396685920', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('501', 'uid', '用户ID', 'int(10) NOT NULL', 'num', '', '', '0', '', '71', '0', '1', '1396688042', '1396688042', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('502', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '71', '0', '1', '1396688187', '1396688187', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('503', 'forms_id', '表单ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '71', '0', '1', '1396710064', '1396688308', '', '3', '', 'regex', '', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('504', 'value', '表单�\�', 'text NOT NULL', 'textarea', '', '', '0', '', '71', '0', '1', '1396688355', '1396688355', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('505', 'cTime', '增加时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '71', '0', '1', '1396688434', '1396688434', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('506', 'can_edit', '是否允许编辑', 'tinyint(2) NOT NULL', 'bool', '0', '用户提交表单是否可以再编�\�', '1', '0:不允�\�\r\n1:允许', '69', '0', '1', '1396688624', '1396688624', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('507', 'forms_id', '表单ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '70', '0', '1', '1396710040', '1396690613', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('508', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '71', '0', '1', '1396690911', '1396690911', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('509', 'is_show', '是否显示', 'tinyint(2) NOT NULL', 'select', '1', '是否显示在表单中', '1', '1:显示\r\n0:不显�\�', '70', '0', '1', '1396848437', '1396848437', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('510', 'content', '详细介绍', 'text NOT NULL', 'editor', '', '可不�\�', '1', '', '69', '0', '1', '1396865295', '1396865295', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('512', 'keyword_type', '关键词类�\�', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '73', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('513', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '73', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('514', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '73', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('515', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '73', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('516', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '73', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('518', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '73', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('519', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '73', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('520', 'finish_tip', '结束�\�', 'text NOT NULL', 'textarea', '', '为空默认为：调研完成，谢谢参�\�', '1', '', '73', '0', '1', '1396953940', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('523', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '74', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('524', 'intro', '问题描述', 'text NOT NULL', 'textarea', '', '', '1', '', '74', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('528', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '74', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('529', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '74', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('533', 'is_must', '是否必填', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:�\�\r\n1:�\�', '74', '0', '1', '1396954649', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('532', 'extra', '参数', 'text NOT NULL', 'textarea', '', '类型为单选、多选时的定义数据，格式见上面的提示', '1', '', '74', '0', '1', '1396954558', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('531', 'type', '问题类型', 'char(50) NOT NULL', 'radio', 'radio', '', '1', 'radio:单选题\r\ncheckbox:多选题\r\ntextarea:简答题', '74', '1', '1', '1396962517', '1396954463', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('530', 'survey_id', 'survey_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '74', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('534', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '74', '0', '1', '1396955010', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('548', 'answer', '回答内容', 'text NOT NULL', 'textarea', '', '', '0', '', '75', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('547', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '75', '0', '1', '1396955581', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('546', 'uid', '用户UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '75', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('545', 'question_id', 'question_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '75', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('542', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '75', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('543', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '75', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('544', 'survey_id', 'survey_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '75', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('549', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '76', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('550', 'keyword_type', '关键词类�\�', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '76', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('551', 'title', '试卷标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '76', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('552', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '76', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('553', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '76', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('554', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '76', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('555', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '76', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('556', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '76', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('557', 'finish_tip', '结束�\�', 'text NOT NULL', 'textarea', '', '为空默认为：考试完成，谢谢参�\�', '1', '', '76', '0', '1', '1396953940', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('558', 'title', '题目标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '77', '1', '1', '1397037377', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('559', 'intro', '题目描述', 'text NOT NULL', 'textarea', '', '', '1', '', '77', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('560', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '77', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('561', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '77', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('562', 'is_must', '是否必填', 'tinyint(2) NOT NULL', 'bool', '1', '', '0', '0:�\�\r\n1:�\�', '77', '0', '1', '1397035513', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('563', 'extra', '参数', 'text NOT NULL', 'textarea', '', '每个选项换一行，每项输入格式如：A:男人', '1', '', '77', '0', '1', '1397036210', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('564', 'type', '题目类型', 'char(50) NOT NULL', 'radio', 'radio', '', '1', 'radio:单选题\r\ncheckbox:多选题', '77', '1', '1', '1397036281', '1396954463', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('565', 'exam_id', 'exam_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '77', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('566', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '77', '0', '1', '1396955010', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('576', 'start_time', '考试开始时�\�', 'int(10) NOT NULL', 'datetime', '', '为空表示什么时候开始都可以', '1', '', '76', '0', '1', '1397036762', '1397036762', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('567', 'answer', '回答内容', 'text NOT NULL', 'textarea', '', '', '0', '', '78', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('568', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '78', '0', '1', '1396955581', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('569', 'uid', '用户UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '78', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('570', 'question_id', 'question_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '78', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('571', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '78', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('572', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '78', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('573', 'exam_id', 'exam_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '78', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('574', 'score', '分�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '考生答对此题的得分数', '1', '', '77', '0', '1', '1397035609', '1397035609', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('575', 'answer', '标准答案', 'varchar(255) NOT NULL', 'string', '', '多个答案用空格分开，如�\� A B C', '1', '', '77', '0', '1', '1397035889', '1397035889', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('577', 'end_time', '考试结束时间', 'int(10) NOT NULL', 'datetime', '', '为空表示不限制结束时�\�', '1', '', '76', '0', '1', '1397036831', '1397036831', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('578', 'score', '得分', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '78', '0', '1', '1397040133', '1397040133', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('579', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '79', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('580', 'keyword_type', '关键词类�\�', 'tinyint(2) NOT NULL', 'select', '0', '', '1', '0:完全匹配\r\n1:左边匹配\r\n2:右边匹配\r\n3:模糊匹配', '79', '1', '1', '1396624426', '1396061765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('581', 'title', '问卷标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '79', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('582', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '79', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('583', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '79', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('584', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '79', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('586', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '79', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('587', 'finish_tip', '评论�\�', 'text NOT NULL', 'textarea', '', '详细说明见上面的提示，配置格式：[0-59]不合�\�', '1', '', '79', '0', '1', '1397142371', '1396953940', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('590', 'title', '题目标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '80', '1', '1', '1397037377', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('591', 'intro', '题目描述', 'text NOT NULL', 'textarea', '', '', '1', '', '80', '0', '1', '1396954176', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('592', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '80', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('593', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '80', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('594', 'is_must', '是否必填', 'tinyint(2) NOT NULL', 'bool', '1', '', '0', '0:�\�\r\n1:�\�', '80', '0', '1', '1397035513', '1396954649', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('595', 'extra', '参数', 'text NOT NULL', 'textarea', '', '输入格式见上面的提示', '1', '', '80', '0', '1', '1397142592', '1396954558', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('596', 'type', '题目类型', 'char(50) NOT NULL', 'radio', 'radio', '', '0', 'radio:单选题', '80', '1', '1', '1397142548', '1396954463', '', '3', '', 'regex', 'radio', '1', 'string');
INSERT INTO `wp_attribute` VALUES ('597', 'test_id', 'test_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '80', '1', '1', '1396954240', '1396954240', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('598', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '80', '0', '1', '1396955010', '1396955010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('601', 'answer', '回答内容', 'text NOT NULL', 'textarea', '', '', '0', '', '81', '0', '1', '1396955766', '1396955766', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('602', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '81', '0', '1', '1396955581', '1396955581', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('603', 'uid', '用户UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '81', '0', '1', '1396955530', '1396955530', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('604', 'question_id', 'question_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '81', '1', '1', '1396955412', '1396955392', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('605', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '81', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('606', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '81', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('607', 'test_id', 'test_id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '81', '1', '1', '1396955403', '1396955369', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('608', 'score', '得分', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '81', '0', '1', '1397040133', '1397040133', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('609', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '82', '1', '1', '1399038073', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('611', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '82', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('612', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '82', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('613', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '82', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('614', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '82', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('616', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '82', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('617', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '82', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('618', 'url', '访问网址', 'varchar(255) NOT NULL', 'string', '', '为空则自动生�\�', '0', '', '82', '0', '1', '1398416321', '1397361414', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('619', 'is_close', '是否关闭', 'tinyint(2) NOT NULL', 'bool', '0', '关闭后用户不能再访问该页�\�', '1', '0:开�\�\r\n1:关闭', '82', '0', '1', '1397361841', '1397361510', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('620', 'need_login', '游客访问', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:允许\r\n1:禁止', '82', '0', '1', '1397361769', '1397361769', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('621', 'layout', '页面参数', 'text NOT NULL', 'textarea', '', '', '0', '', '82', '0', '1', '1397474846', '1397474846', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('622', 'view_count', '浏览�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '82', '0', '1', '1397475862', '1397475862', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('678', 'img_1', '商品图片1', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '83', '0', '1', '1398598870', '1398598870', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('679', 'img_2', '商品图片2', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '83', '0', '1', '1398598904', '1398598904', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('625', 'title', '商品名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '83', '1', '1', '1397520732', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('626', 'intro', '商品简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '83', '0', '1', '1397521079', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('627', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '83', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('628', 'cover', '商品封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '83', '0', '1', '1397521134', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('629', 'content', '商品详情', 'text NOT NULL', 'editor', '', '', '1', '', '83', '0', '1', '1397521004', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('630', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '83', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('631', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '83', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('632', 'param', '商品参数', 'text NOT NULL', 'editor', '', '', '1', '', '83', '0', '1', '1397521446', '1397521446', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('633', 'ad_url', '商品广告页面', 'varchar(255) NOT NULL', 'string', '', '可为空，填写商品广告页面的地址', '1', '', '83', '0', '1', '1397521579', '1397521579', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('634', 'buy_url', '购买地址', 'varchar(255) NOT NULL', 'string', '', '用户点击购买按钮时跳转的地址，可以是淘宝等网店的购买地址', '1', '', '83', '0', '1', '1397524287', '1397524287', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('635', 'cate_id_1', '商品一级分�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '83', '0', '1', '1397524477', '1397524433', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('636', 'cate_id_2', '商品二级分类', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '83', '0', '1', '1397524466', '1397524466', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('637', 'market_price', '市场�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '83', '0', '1', '1397525480', '1397525480', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('638', 'discount_price', '打折�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '为空时只显示市场�\�', '1', '', '83', '0', '1', '1397525579', '1397525579', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('639', 'view_count', '浏览�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '83', '0', '1', '1397525660', '1397525660', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('640', 'name', '分类标识', 'varchar(255) NOT NULL', 'string', '', '只能使用英文', '5', '', '84', '0', '1', '1398510681', '1397529355', '', '3', '只能输入由数字�\�26个英文字母或者下划线组成的标识名', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('641', 'title', '分类标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '84', '1', '1', '1397529407', '1397529407', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('642', 'icon', '分类图标', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '84', '0', '1', '1397529461', '1397529461', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('643', 'pid', '上一级分�\�', 'int(10) UNSIGNED NOT NULL', 'select', '0', '如果你要增加一级分类，这里选择“无”即�\�', '1', '0:�\�', '84', '0', '1', '1398266132', '1397529555', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('644', 'path', '分类路径', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '84', '0', '1', '1397529604', '1397529604', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('645', 'module', '分类所属功�\�', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '84', '0', '1', '1397529671', '1397529671', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('646', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '数值越小越靠前', '1', '', '84', '0', '1', '1397529705', '1397529705', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('647', 'is_show', '是否显示', 'tinyint(2) NOT NULL', 'bool', '1', '', '1', '0:不显�\�\r\n1:显示', '84', '0', '1', '1397532496', '1397529809', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('653', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '85', '0', '1', '1394526820', '1394526820', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('654', 'module', '模块�\�', 'varchar(255) NOT NULL', 'string', 'Diy', '页面所属的模块', '0', '', '82', '0', '1', '1398350642', '1398350642', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('655', 'intro', '分类描述', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '84', '0', '1', '1398414247', '1398414247', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('656', 'url', '关联URL', 'varchar(255)   NULL', 'string', '', '可用{site_url}代表当前网站根地址', '1', '', '86', '0', '1', '1399083504', '1394519090', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('657', 'title', '菜单�\�', 'varchar(50) NOT NULL', 'string', '', '可创建最�\� 3 个一级菜单，每个一级菜单下可创建最�\� 5 个二级菜单。编辑中的菜单不会马上被用户看到，请放心调试�\�', '1', '', '86', '0', '1', '1394519941', '1394518988', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('658', 'pid', '一级菜�\�', 'tinyint(2) NULL', 'select', '0', '如果是一级菜单，选择“无”即�\�', '1', '0:�\�', '86', '0', '1', '1394519296', '1394518930', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('659', 'sort', '排序�\�', 'tinyint(4)  NULL', 'num', '0', '数值越小越靠前', '1', '', '86', '0', '1', '1394523288', '1394519175', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('660', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '86', '0', '1', '1394526820', '1394526820', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('661', 'icon', '图标', 'int(10) UNSIGNED NULL', 'picture', '', '根据选择的底部模板决定是否需要上传图�\�', '1', '', '86', '0', '1', '1396506297', '1396506297', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('662', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '84', '0', '1', '1398593086', '1398523502', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('665', 'title', '积分描述', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '87', '1', '1', '1398563786', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('666', 'name', '积分标识', 'varchar(50) NULL', 'string', '', '', '1', '', '87', '1', '1', '1398563853', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('667', 'mTime', '修改时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '87', '0', '1', '1396624664', '1396624664', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('668', 'experience', '经验�\�', 'int(10) NOT NULL', 'num', '0', '可以是正数，也可以是负数，如 -10 表示�\�10个经验�\�', '1', '', '87', '0', '1', '1398564024', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('669', 'score', '财富�\�', 'int(10) NOT NULL', 'num', '0', '可以是正数，也可以是负数，如 -10 表示�\�10个财富�\�', '1', '', '87', '0', '1', '1398564097', '1396062146', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('671', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '0', '', '0', '', '87', '0', '1', '1398564146', '1396602859', '', '3', '', 'regex', '', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('673', 'credit_name', '积分标识', 'varchar(50) NOT NULL', 'string', '', '', '1', '', '88', '0', '1', '1398564405', '1398564405', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('672', 'uid', '用户ID', 'int(10) NOT NULL', 'num', '0', '', '1', '', '88', '0', '1', '1398564351', '1398564351', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('674', 'experience', '经验�\�', 'int(10) NOT NULL', 'num', '0', '', '1', '', '88', '0', '1', '1398564448', '1398564448', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('675', 'score', '财富�\�', 'int(10) NOT NULL', 'num', '0', '', '1', '', '88', '0', '1', '1398564486', '1398564486', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('676', 'cTime', '记录时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '88', '0', '1', '1398564567', '1398564567', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('677', 'admin_uid', '操作者UID', 'int(10) NOT NULL', 'num', '0', '', '0', '', '88', '0', '1', '1398564629', '1398564629', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('680', 'img_3', '商品图片3', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '83', '0', '1', '1398598938', '1398598938', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('681', 'img_4', '商品图片4', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '83', '0', '1', '1398598960', '1398598960', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('682', 'img_5', '商品图片5', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '83', '0', '1', '1398598981', '1398598981', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('683', 'cate_id', '商品分类', 'char(50) NOT NULL', 'cascade', '', '', '1', 'type=db&table=common_category&module=shop_category', '83', '0', '1', '1398693036', '1398599395', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('684', 'token', '公众�\�', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '89', '0', '1', '1398845862', '1398845862', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('685', 'openid', 'OpenId', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '89', '0', '1', '1398845911', '1398845911', '', '3', '', 'regex', 'get_openid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('686', 'nickname', '昵称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '89', '0', '1', '1398845957', '1398845957', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('687', 'sex', '性别', 'tinyint(1) unsigned NOT NULL ', 'select', '0', '', '1', '0:保密 \r\n1:男�\�\r\n2:女�\�', '89', '0', '1', '1398846138', '1398846138', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('688', 'city', '城市', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '89', '0', '1', '1398846223', '1398846223', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('689', 'province', '省份', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '89', '0', '1', '1398846249', '1398846249', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('690', 'country', '国家', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '89', '0', '1', '1398846270', '1398846270', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('691', 'language', '语言', 'varchar(50) NOT NULL', 'string', 'zh_CN', '', '1', '', '89', '0', '1', '1398846305', '1398846305', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('692', 'headimgurl', '头像', 'varchar(255) NOT NULL', 'picture', '', '', '1', '', '89', '0', '1', '1398846357', '1398846357', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('693', 'subscribe_time', '关注时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '89', '0', '1', '1398846406', '1398846406', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('694', 'mobile', '手机�\�', 'varchar(30) NOT NULL', 'string', '', '', '1', '', '89', '0', '1', '1398848001', '1398848001', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('695', 'status', '用户状�\�', 'tinyint(1) NULL', 'select', '1', '', '0', '0:未关�\�\r\n1:已关�\�\r\n2:已绑�\�\r\n3:会员卡成�\�', '89', '0', '1', '1398924711', '1398924711', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('696', 'uid', '管理员UID', 'int(10) NOT NULL', 'num', '', '可以在用�\�>用户信息页面的列表第一找到管理员的UID', '1', '', '90', '1', '1', '1398944756', '1398933236', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('697', 'mp_id', '公众号ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '90', '1', '1', '1398933300', '1398933300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('698', 'is_creator', '是否为创建�\�', 'tinyint(2) NOT NULL', 'bool', '0', '', '0', '0:不是\r\n1:�\�', '90', '0', '1', '1398933380', '1398933380', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('699', 'addon_status', '插件权限', 'text NOT NULL', 'checkbox', '', '', '1', '', '90', '0', '1', '1398933475', '1398933475', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('700', 'is_use', '是否为当前管理的公众�\�', 'tinyint(2) NOT NULL', 'bool', '0', '', '0', '0:不是\r\n1:�\�', '90', '0', '1', '1398996982', '1398996975', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('701', 'bug_count', '成交�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '83', '0', '1', '1399002900', '1399002900', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('702', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '91', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('713', 'use_tips', '使用说明', 'varchar(255) NOT NULL', 'textarea', '', '用户获取优惠券后显示的提示信�\�', '1', '', '91', '1', '1', '1399274330', '1399259489', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('704', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '91', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('705', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '91', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('712', 'end_time', '结束时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '91', '0', '1', '1399259433', '1399259433', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('707', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '91', '0', '1', '1396624534', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('709', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '91', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('710', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '91', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('711', 'start_time', '开始时�\�', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '91', '0', '1', '1399259416', '1399259416', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('714', 'end_tips', '过期说明', 'text NOT NULL', 'textarea', '', '活动过期或者结束说�\�', '1', '', '91', '0', '1', '1399259570', '1399259570', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('778', 'end_img', '过期提示图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '可为�\�', '1', '', '91', '0', '1', '1400989793', '1400989793', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('717', 'num', '优惠券数�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '0表示不限制数�\�', '1', '', '91', '0', '1', '1399259838', '1399259808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('719', 'max_num', '每人最多允许获取次�\�', 'int(10) UNSIGNED NOT NULL', 'num', '1', '0表示不限制数�\�', '1', '', '91', '0', '1', '1400992221', '1399260079', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('720', 'follower_condtion', '粉丝状�\�', 'char(50) NOT NULL', 'select', '1', '粉丝达到设置的状态才能获�\�', '1', '0:不限�\�\r\n1:已关�\�\r\n2:已绑定信�\�\r\n3:会员卡成�\�', '91', '0', '1', '1399260479', '1399260479', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('721', 'credit_conditon', '积分限制', 'int(10) UNSIGNED NOT NULL', 'num', '0', '粉丝达到多少积分后才能领取，领取后不扣积�\�', '1', '', '91', '0', '1', '1399260618', '1399260618', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('722', 'credit_bug', '积分消费', 'int(10) UNSIGNED NOT NULL', 'num', '0', '用积分中的财富兑换、兑换后扣除相应的积分财�\�', '1', '', '91', '0', '1', '1399260764', '1399260764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('723', 'addon_condition', '插件场景限制', 'varchar(255) NOT NULL', 'string', '', '格式：[插件�\�:id值]，如[投票:10]表示对ID�\�10的投票投完才能领取，更多的说明见表单上的提示', '1', '', '91', '0', '1', '1399274022', '1399261026', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('724', 'collect_count', '已领取数', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '91', '0', '1', '1400992246', '1399270900', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('725', 'view_count', '浏览人数', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '91', '0', '1', '1399270926', '1399270926', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('726', 'sn', 'SN�\�', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '92', '0', '1', '1399272236', '1399272228', '', '3', '', 'regex', 'uniqid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('727', 'uid', '粉丝UID', 'int(10) NOT NULL', 'num', '', '', '0', '', '92', '0', '1', '1399772738', '1399272401', '', '3', '', 'regex', 'get_mid', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('728', 'cTime', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '92', '0', '1', '1399272456', '1399272456', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('729', 'is_use', '是否已使�\�', 'tinyint(2) NOT NULL', 'bool', '0', '', '0', '0:未使�\�\r\n1:已使�\�', '92', '0', '1', '1400601159', '1399272514', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('730', 'use_time', '使用时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '92', '0', '1', '1399272560', '1399272537', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('731', 'addon', '来自的插�\�', 'varchar(255) NOT NULL', 'string', 'Coupon', '', '4', '', '92', '0', '1', '1399272651', '1399272651', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('732', 'target_id', '来源ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '4', '', '92', '0', '1', '1399272705', '1399272705', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('733', 'keyword', '关键�\�', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '93', '1', '1', '1396624337', '1396061575', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('734', 'use_tips', '使用说明', 'varchar(255) NOT NULL', 'textarea', '', '用户获取刮刮卡后显示的提示信�\�', '1', '', '93', '1', '1', '1399274330', '1399259489', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('735', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '93', '1', '1', '1396624461', '1396061859', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('736', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '93', '0', '1', '1396624505', '1396061947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('737', 'end_time', '结束时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '93', '0', '1', '1399259433', '1399259433', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('738', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '可为�\�', '1', '', '93', '0', '1', '1399710705', '1396062093', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('739', 'cTime', '发布时间', 'int(10) UNSIGNED NOT NULL', 'datetime', '', '', '0', '', '93', '0', '1', '1396624612', '1396075102', '', '3', '', 'regex', 'time', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('740', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '93', '0', '1', '1396602871', '1396602859', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('741', 'start_time', '开始时�\�', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '93', '0', '1', '1399259416', '1399259416', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('742', 'end_tips', '过期说明', 'text NOT NULL', 'textarea', '', '活动过期或者结束说�\�', '1', '', '93', '0', '1', '1399259570', '1399259570', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('764', 'end_img', '过期提示图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '可为�\�', '1', '', '93', '0', '1', '1399712676', '1399711987', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('746', 'predict_num', '预计参与人数', 'int(10) UNSIGNED NOT NULL', 'num', '', '预计人数直接影响抽奖概率：中奖概�\� = 奖品总数/(预估活动人数*每人抽奖次数) 要确�\�100%中奖可设置为1', '1', '', '93', '1', '1', '1399710446', '1399259992', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('747', 'max_num', '每人最多允许抽奖次�\�', 'int(10) UNSIGNED NOT NULL', 'num', '1', '0表示不限制数�\�', '1', '', '93', '0', '1', '1399260079', '1399260079', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('748', 'follower_condtion', '粉丝状�\�', 'char(50) NOT NULL', 'select', '1', '粉丝达到设置的状态才能获�\�', '1', '0:不限�\�\r\n1:已关�\�\r\n2:已绑定信�\�\r\n3:会员卡成�\�', '93', '0', '1', '1399260479', '1399260479', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('749', 'credit_conditon', '积分限制', 'int(10) UNSIGNED NOT NULL', 'num', '0', '粉丝达到多少积分后才能领取，领取后不扣积�\�', '1', '', '93', '0', '1', '1399260618', '1399260618', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('750', 'credit_bug', '积分消费', 'int(10) UNSIGNED NOT NULL', 'num', '0', '用积分中的财富兑换、兑换后扣除相应的积分财�\�', '1', '', '93', '0', '1', '1399260764', '1399260764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('751', 'addon_condition', '插件场景限制', 'varchar(255) NOT NULL', 'string', '', '格式：[插件�\�:id值]，如[投票:10]表示对ID�\�10的投票投完才能领取，更多的说明见表单上的提示', '1', '', '93', '0', '1', '1399274022', '1399261026', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('752', 'collect_count', '已领取人�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '93', '0', '1', '1399270900', '1399270900', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('753', 'view_count', '浏览人数', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '93', '0', '1', '1399270926', '1399270926', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('754', 'addon', '来源插件', 'varchar(255) NOT NULL', 'string', 'Scratch', '', '0', '', '94', '0', '1', '1399348676', '1399348676', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('755', 'target_id', '来源ID', 'int(10) UNSIGNED NOT NULL', '', '', '', '4', '', '94', '0', '1', '1399557884', '1399348699', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('756', 'title', '奖项标题', 'varchar(255) NOT NULL', 'string', '', '如特等奖、一等奖。。�\�', '1', '', '94', '0', '1', '1399557606', '1399348734', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('757', 'name', '奖项', 'varchar(255) NOT NULL', 'string', '', '如iphone、吹风机�\�', '1', '', '94', '0', '1', '1399557624', '1399348785', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('758', 'num', '名额数量', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '1', '', '94', '0', '1', '1399557753', '1399348843', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('759', 'update_time', '更新时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '93', '0', '1', '1399562468', '1399359204', '', '3', '', 'regex', 'time', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('760', 'sort', '排序�\�', 'int(10) UNSIGNED NOT NULL', 'num', '0', '值越小越靠前', '1', '', '94', '0', '1', '1399557716', '1399557716', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('761', 'img', '奖品图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '94', '0', '1', '1399557997', '1399557997', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('762', 'prize_id', '奖项ID', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '92', '0', '1', '1399686317', '1399686317', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('766', 'prize_title', '奖项', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '92', '0', '1', '1399790367', '1399790367', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('767', 'jump_url', '提交后跳转的地址', 'varchar(255) NOT NULL', 'string', '', '要以http://开头的完整地址，为空时不跳�\�', '1', '', '69', '0', '1', '1399800276', '1399800276', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('768', 'icon', '分类图标', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '95', '0', '1', '1400047745', '1400047745', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('769', 'title', '分类�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '95', '0', '1', '1400047764', '1400047764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('770', 'sort', '排序�\�', 'int(10) NOT NULL', 'num', '0', '值越小越靠前', '1', '', '95', '0', '1', '1400050453', '1400047786', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('772', 'score', '财富�\�', 'int(10) NOT NULL', 'num', '0', '', '1', '', '89', '0', '1', '1400054524', '1400054524', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('773', 'experience', '经验�\�', 'int(10) NOT NULL', 'num', '0', '', '1', '', '89', '0', '1', '1400054551', '1400054551', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('774', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '88', '0', '1', '1400603451', '1400603451', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('775', 'nickname', '用户昵称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '0', '1', '1400687052', '1400687052', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('776', 'mobile', '手机�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '0', '1', '1400687075', '1400687075', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('777', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '18', '0', '1', '1400687900', '1400687900', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('779', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '96', '0', '1', '1401371165', '1401371165', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('780', 'month', '月份', 'int(10) NOT NULL', 'num', '', '', '1', '', '96', '0', '1', '1401371192', '1401371192', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('781', 'day', '日期', 'int(10) NOT NULL', 'num', '', '', '1', '', '96', '0', '1', '1401371209', '1401371209', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('782', 'content', '统计数据', 'text NOT NULL', 'textarea', '', '', '1', '', '96', '0', '1', '1401371292', '1401371292', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('783', 'request_count', '请求�\�', 'int(10) NOT NULL', 'num', '0', '用户回复的次�\�', '0', '', '5', '0', '1', '1401938983', '1401938983', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('784', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '22', '0', '1', '1402454223', '1402454223', '', '3', '', 'regex', 'get_token', '1', 'function');
INSERT INTO `wp_attribute` VALUES ('785', 'jump_url', '外链', 'varchar(255) NOT NULL', 'string', '', '如需跳转填写网址(记住必须有http://)如果填写了图文详细内容，这里请留空，不要设置�\�', '1', '', '64', '0', '1', '1402482073', '1402482073', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('786', 'token', ' Token ', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '97', '0', '1', '1401108700', '1401103980', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('787', 'keyword', ' 关键�\� ', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '97', '1', '1', '1401108295', '1401108295', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('788', 'intro', '封面简�\�', 'text NOT NULL', 'textarea', '', '', '1', '', '97', '1', '1', '1401108377', '1401108377', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('789', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '97', '1', '1', '1401108330', '1401108330', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('790', 'cover', '封面图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '97', '1', '1', '1401108403', '1401108403', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('791', 'kfname', '客服名称', 'varchar(255) NOT NULL', 'string', '', '用于评论中显示的回复名称', '1', '', '97', '0', '1', '1401118036', '1401118036', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('792', 'TemplateIndex', '模板编号', 'varchar(255) NOT NULL', 'string', 'default', '使用的模板编�\�', '0', '', '97', '0', '1', '1401195917', '1401195917', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('793', 'paixu', '排序', 'int(10) NOT NULL', 'num', '0', '数字越大排序越靠前，默认按添加时间排�\�', '1', '', '98', '0', '1', '1401541928', '1401120081', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('794', 'state', '状�\�', 'tinyint(2) NOT NULL', 'bool', '0', '菜品下架后不会出现在菜单�\�', '1', '0:上架\r\n1:下架', '98', '0', '1', '1401203673', '1401203673', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('795', 'review_count', '评论数量', 'int(10) NOT NULL', 'num', '0', '', '0', '', '98', '0', '1', '1401111125', '1401111125', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('796', 'icon', ' 菜品封面 ', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '98', '0', '1', '1401202313', '1401202313', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('797', 'dishes_num', '菜品编号', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '98', '1', '1', '1401110538', '1401110538', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('798', 'price', '价格', 'varchar(255) NOT NULL', 'string', '', '菜品的原�\�', '1', '', '98', '1', '1', '1401110913', '1401110899', '/^(d*.d{0,2}|d+).*$/', '3', '请输入正确的菜品价格', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('799', 'introduction', '菜品简�\�', 'text NOT NULL', 'editor', '', '', '1', '', '98', '0', '1', '1401110665', '1401110665', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('800', 'name', '菜品名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '98', '1', '1', '1401110494', '1401110485', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('801', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '98', '0', '1', '1401201073', '1401201073', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('802', 'youhuiid', '优惠id', 'int(10) NOT NULL', 'num', '0', '表示该菜品属于那个优惠id', '0', '', '98', '0', '1', '1401693201', '1401688829', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('803', 'fenz', '每分', 'varchar(255) NOT NULL', 'string', '*', '设置哪一分钟执行本任务，多个值之间用半角逗号 \",\" 隔开�\�*”为不限�\�', '1', '', '99', '0', '1', '1401207395', '1401207395', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('804', 'xiaos', '每时', 'varchar(255) NOT NULL', 'string', '*', '设置哪一小时执行本任务，�\�*”为不限�\�', '1', '', '99', '0', '1', '1401207176', '1401207176', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('805', 'yue', '每月', 'varchar(255) NOT NULL', 'string', '*', '设置哪一月执行本任务，�\�*”为不限�\�', '1', '', '99', '0', '1', '1401207146', '1401207010', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('806', 'day', '每日', 'varchar(255) NOT NULL', 'string', '*', '设置哪一日执行本任务，�\�*”为不限�\�', '1', '', '99', '0', '1', '1401207130', '1401207130', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('807', 'zhou', '每周', 'varchar(255) NOT NULL', 'string', '*', '设置星期几执行本任务，�\�*”为不限制，本设置会覆盖下面的“日”设�\�', '1', '', '99', '0', '1', '1401206983', '1401206983', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('808', 'starttime_endtime', '开始和结束时间的序列化数据', 'text NOT NULL', 'textarea', '', '开始和结束时间的序列化数据', '0', '', '99', '0', '1', '1401112431', '1401112431', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('809', 'state', '状�\�', 'tinyint(2) NOT NULL', 'bool', '0', '停用后，计划任务将不会执�\�', '1', '0:启用\r\n1:停用', '99', '0', '1', '1401112617', '1401112617', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('810', 'upruntime', '上次执行时间', 'int(10) NOT NULL', 'datetime', '', '上次任务执行的时�\�', '0', '', '99', '0', '1', '1401112687', '1401112687', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('811', 'downruntime', '下次任务执行时间', 'int(10) NOT NULL', 'datetime', '', '下次任务执行的时�\�', '0', '', '99', '0', '1', '1401112735', '1401112735', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('812', 'title', '任务名称', 'text NOT NULL', 'textarea', '', '', '1', '', '99', '1', '1', '1401112503', '1401112503', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('813', 'type', '任务类型', 'int(10) NOT NULL', 'num', '0', '0:一次型,1:周期�\�,2:自定义时�\�', '1', '', '99', '0', '1', '1401206909', '1401206909', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('814', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '99', '0', '1', '1401205393', '1401205393', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('815', 'ztnum', '桌台编号', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '100', '0', '1', '1401118219', '1401118219', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('816', 'setid', '餐厅id', 'int(10) NOT NULL', 'num', '', '关联的餐厅id', '0', '', '100', '0', '1', '1401540887', '1401205798', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('817', 'paixu', '排序', 'int(10) NOT NULL', 'num', '0', '数字越大排序越靠�\�', '1', '', '100', '0', '1', '1401540899', '1401205965', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('818', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '100', '0', '1', '1401205346', '1401205346', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('819', 'ztdes', '餐位简�\�', 'text NOT NULL', 'editor', '', '', '1', '', '100', '0', '1', '1401118486', '1401118486', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('820', 'state', '状�\�', 'char(50) NOT NULL', 'select', '0', '', '1', '0:空闲\r\n1:已被预约\r\n2:维修�\�\r\n3:其他', '100', '0', '1', '1401540990', '1401118861', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('821', 'yongccount', '用餐人数', 'int(10) NOT NULL', 'num', '', '', '1', '', '100', '0', '1', '1401118515', '1401118515', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('822', 'zttype', '餐位类型', 'varchar(255) NOT NULL', 'select', '0', '', '1', '0:大厅\r\n1:包间', '100', '0', '1', '1401540934', '1401118323', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('823', 'ztname', '餐位或包间名�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '100', '0', '1', '1401118448', '1401118448', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('824', 'yycount', '预约人数', 'int(10) NOT NULL', 'num', '', '', '1', '', '101', '0', '1', '1401119030', '1401119030', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('825', 'sex', '预约人性别', 'int(10) NOT NULL', 'num', '0', '0未知,1�\�,2�\�', '1', '', '101', '0', '1', '1401117511', '1401117511', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('826', 'usermobile', '预约人电�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '101', '0', '1', '1401117326', '1401117326', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('827', 'username', '预约人姓�\�', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '101', '0', '1', '1401117300', '1401117300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('828', 'openid', '关联微信用户id', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '101', '0', '1', '1401117271', '1401117271', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('829', 'tablemanage_id', '桌台编号', 'int(10) NOT NULL', 'num', '', '', '0', '', '101', '0', '1', '1401113324', '1401113324', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('830', 'set_id', '关联的餐厅编�\�', 'int(10) NOT NULL', 'num', '', '', '0', '', '101', '0', '1', '1401206543', '1401206543', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('831', 'paixu', '排序', 'int(10) NOT NULL', 'num', '0', '数字越大,排序越靠�\�', '1', '', '102', '0', '1', '1401471365', '1401471365', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('832', 'pic', '菜系图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '102', '0', '1', '1401113921', '1401113921', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('833', 'name', '菜系名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '102', '1', '1', '1401113870', '1401113870', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('834', 'state', '状�\�', 'tinyint(2) NOT NULL', 'bool', '0', '停用后将不会显示在菜系栏�\�', '1', '0:启用\r\n1:停用', '102', '0', '1', '1401114031', '1401114031', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('835', 'setid', '关联的餐厅id', 'int(10) NOT NULL', 'num', '', '', '0', '', '102', '0', '1', '1401433017', '1401433017', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('836', 'dishesdatas', '菜品集合', 'text NOT NULL', 'textarea', '', '关联的菜品id集合序列�\�', '0', '', '102', '0', '1', '1401432947', '1401432947', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('837', 'introduction', '简�\�', 'text NOT NULL', 'editor', '', '', '1', '', '102', '0', '1', '1401113979', '1401113979', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('838', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '102', '0', '1', '1401204630', '1401204630', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('839', 'plcontent', '评论内容', 'text NOT NULL', 'editor', '', '', '1', '', '103', '0', '1', '1401117765', '1401117765', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('840', 'pltime', '评论时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '103', '0', '1', '1401117727', '1401117727', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('841', 'hftime', '回复时间', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '103', '0', '1', '1401117866', '1401117866', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('842', 'hfcontent', '回复内容', 'text NOT NULL', 'editor', '', '', '1', '', '103', '0', '1', '1401117839', '1401117839', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('843', 'type', '评论类型', 'int(10) NOT NULL', 'num', '0', '评论类型0菜品,1餐位', '0', '', '103', '0', '1', '1401115001', '1401115001', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('844', 'openid', '关联的用户id', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '103', '0', '1', '1401114232', '1401114232', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('845', 'set_id', '关联的餐厅id', 'int(10) NOT NULL', 'num', '', '', '0', '', '103', '0', '1', '1401114207', '1401114207', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('846', 'dishes_id', '关联的菜品id或者关联的桌台id', 'int(10) NOT NULL', 'num', '', '', '0', '', '103', '0', '1', '1401114340', '1401114300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('847', 'pingji', '菜品评级', 'int(10) NOT NULL', 'num', '3', '菜品的星级程度从1-5�\�', '0', '', '103', '0', '1', '1401114619', '1401114619', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('848', 'tablemanage_id', '关联的餐位编�\�', 'int(10) NOT NULL', 'num', '', '', '0', '', '104', '0', '1', '1401116922', '1401116922', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('849', 'endtime', '过期时间', 'varchar(255) NOT NULL', 'string', '', '订单未支付过期时�\�', '0', '', '104', '0', '1', '1401699274', '1401116798', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('850', 'zftype', '支付方式', 'char(50) NOT NULL', 'select', '0', '', '0', '0:支付�\�\r\n1:微信支付\r\n2:网银\r\n3:拉卡�\�\r\n4:线下支付', '104', '0', '1', '1401636926', '1401116261', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('851', 'price', '点餐原总价', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '104', '0', '1', '1401115978', '1401115968', '/^(d*.d{0,2}|d+).*$/', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('852', 'yhprice', '优惠后的总价', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '104', '0', '1', '1401116031', '1401116031', '/^(d*.d{0,2}|d+).*$/', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('853', 'openid', '关联的微信用户id', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '104', '0', '1', '1401115609', '1401115609', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('854', 'dishes_count_datas', '点餐的菜品数量序列化数据', 'text NOT NULL', 'textarea', '', '', '0', '', '104', '0', '1', '1401115713', '1401115713', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('855', 'set_id', '关联的餐厅id', 'int(10) NOT NULL', 'num', '', '', '0', '', '104', '0', '1', '1401115308', '1401115308', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('856', 'statekz', '状态扩�\�', 'char(50) NOT NULL', 'select', '0', '', '3', '0:未支�\�\r\n1:已支�\�\r\n2:(未支�\�)申请取消订单\r\n3:(已支�\�)申请取消订单\r\n4:(已支�\�)退款中\r\n5:(已支�\�)拒绝申请取消订单\r\n6:已取�\�', '104', '0', '1', '1402220841', '1401116657', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('857', 'dcnum', '点餐单号', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '104', '0', '1', '1401116387', '1401116387', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('858', 'state', '状�\�', 'char(50) NOT NULL', 'select', '0', '确认后的订单取消需要进入审核处�\�', '3', '0:未确�\�\r\n1:已确�\�', '104', '0', '1', '1402218290', '1401116514', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('859', 'diningtypes', '点餐类型', 'char(50) NOT NULL', 'select', '0', '', '0', '0:点餐\r\n1:预约\r\n2:外卖', '104', '0', '1', '1401637742', '1401117110', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('860', 'beizhu', '备注', 'text NOT NULL', 'textarea', '', '', '1', '', '104', '0', '1', '1401612088', '1401612088', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('861', 'cpcount', '菜品总数�\�', 'int(10) NOT NULL', 'num', '0', '', '0', '', '104', '0', '1', '1401611560', '1401611560', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('862', 'ctime', '创建时间', 'varchar(255) NOT NULL', 'string', '', '订单创建时间', '0', '', '104', '0', '1', '1402216495', '1401609275', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('863', 'jctime', '就餐时间', 'varchar(255) NOT NULL', 'string', '', '用餐时间', '1', '', '104', '0', '1', '1401699089', '1401609319', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('864', 'contactid', '关联的联系id', 'int(10) NOT NULL', 'num', '', '联系信息id', '0', '', '104', '0', '1', '1401609458', '1401609458', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('865', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '104', '0', '1', '1401610691', '1401610691', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('866', 'ismain', '是否为主�\�', 'tinyint(2) NOT NULL', 'bool', '0', '设置为主要后,可以出现在菜品页面推�\�', '0', '0:不是\r\n1:�\�', '105', '0', '1', '1401686835', '1401686207', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('867', 'name', '优惠分类名称', 'varchar(255) NOT NULL', 'string', '', '如特价，推荐，限时优惠，特供', '1', '', '105', '0', '1', '1401539832', '1401119661', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('868', 'state', '状�\�', 'tinyint(2) NOT NULL', 'bool', '0', '停用后将不会显示在优惠分类栏目中', '1', '0:启用\r\n1:停用', '105', '0', '1', '1401119857', '1401119857', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('869', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '105', '0', '1', '1401205296', '1401205296', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('870', 'dishesdatas', '菜品id和优惠价格序列化数据', 'text NOT NULL', 'textarea', '', '', '0', '', '105', '0', '1', '1401539979', '1401119705', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('871', 'paixu', '排序', 'int(10) NOT NULL', 'num', '0', '数字越大排序越靠前，默认按添加时间排�\�', '1', '', '105', '0', '1', '1401539873', '1401120018', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('872', 'setid', '餐厅id', 'int(10) NOT NULL', 'num', '', '关联的餐厅id', '0', '', '105', '0', '1', '1401540169', '1401539914', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('873', 'setid', '餐厅id', 'int(10) NOT NULL', 'num', '', '', '0', '', '106', '0', '1', '1401617668', '1401617668', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('874', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '106', '0', '1', '1401610661', '1401610661', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('875', 'openid', '用户id', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '106', '0', '1', '1401610734', '1401610734', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('876', 'cpid', '菜品id', 'int(10) NOT NULL', 'num', '', '关联的菜品id', '0', '', '106', '0', '1', '1401610839', '1401610839', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('877', 'address', '联系地址', 'varchar(555) NOT NULL', 'string', '', '', '1', '', '107', '0', '1', '1401694266', '1401694266', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('878', 'truename', '用户名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '107', '0', '1', '1401694187', '1401694187', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('879', 'tel', '联系电话', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '107', '0', '1', '1401694239', '1401694239', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('880', 'token', 'Token', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '107', '0', '1', '1401694162', '1401694162', '', '3', '', 'regex', 'get_token', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('881', 'openid', '微信id', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '107', '0', '1', '1401694285', '1401694285', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('882', 'isdefault', '是否默认', 'tinyint(2) NOT NULL', 'bool', '0', '是否默认常用的地址', '0', '0:不是\r\n1:�\�', '107', '0', '1', '1401694451', '1401694451', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `wp_attribute` VALUES ('883', 'set_id', '餐厅id', 'int(10) NOT NULL', 'num', '', '', '0', '', '107', '0', '1', '1401695024', '1401695024', '', '3', '', 'regex', '', '3', 'function');

-- -----------------------------
-- Table structure for `wp_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_extend`;
CREATE TABLE `wp_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `wp_auth_extend`
-- -----------------------------
INSERT INTO `wp_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `wp_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `wp_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `wp_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `wp_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `wp_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_group`;
CREATE TABLE `wp_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_auth_group`
-- -----------------------------
INSERT INTO `wp_auth_group` VALUES ('1', 'admin', '1', '默认用户�\�', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `wp_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');

-- -----------------------------
-- Table structure for `wp_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_group_access`;
CREATE TABLE `wp_auth_group_access` (
  `uid` int(10) DEFAULT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `wp_auth_rule`;
CREATE TABLE `wp_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`module`,`name`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=222 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_auth_rule`
-- -----------------------------
INSERT INTO `wp_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('6', 'admin', '1', 'Admin/Index/index', '首页', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据�\�', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `wp_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('217', 'admin', '1', 'admin/addons/weixin', '微信插件', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('218', 'admin', '2', 'Admin/Addons/weixin', '插件管理', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('219', 'admin', '1', 'admin/PublicGroup/PublicGroup', '公众号等�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('220', 'admin', '1', 'admin/PublicGroup/PublicAdmin', '公众号管�\�', '1', '');
INSERT INTO `wp_auth_rule` VALUES ('221', 'admin', '1', 'admin/update/index', '在线升级', '1', '');

-- -----------------------------
-- Table structure for `wp_card_member`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_member`;
CREATE TABLE `wp_card_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(10) DEFAULT NULL COMMENT '用户UID',
  `username` varchar(100) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(30) DEFAULT NULL COMMENT '手机号',
  `number` varchar(50) DEFAULT NULL COMMENT '卡号',
  `cTime` int(10) DEFAULT NULL COMMENT '加入时间',
  `token` varchar(100) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_card_member`
-- -----------------------------
INSERT INTO `wp_card_member` VALUES ('35', '363', 'lipeng', '15027158270', '80001', '1402810864', 'gh_ccbc7c79380e');

-- -----------------------------
-- Table structure for `wp_card_notice`
-- -----------------------------
DROP TABLE IF EXISTS `wp_card_notice`;
CREATE TABLE `wp_card_notice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '通知内容',
  `cTime` int(10) DEFAULT NULL COMMENT '发布时间',
  `token` varchar(100) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_category`;
CREATE TABLE `wp_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `wp_category`
-- -----------------------------
INSERT INTO `wp_category` VALUES ('1', 'blog', '博客', '0', '0', '10', '', '', '', '', '', '', '', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1382701539', '1', '0');

-- -----------------------------
-- Table structure for `wp_channel`
-- -----------------------------
DROP TABLE IF EXISTS `wp_channel`;
CREATE TABLE `wp_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_common_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_common_category`;
CREATE TABLE `wp_common_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '分类标识',
  `title` varchar(255) NOT NULL COMMENT '分类标题',
  `icon` int(10) unsigned NOT NULL COMMENT '分类图标',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上一级分类',
  `path` varchar(255) NOT NULL COMMENT '分类路径',
  `module` varchar(255) NOT NULL COMMENT '分类所属功能',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  `is_show` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `intro` varchar(255) NOT NULL COMMENT '分类描述',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_config`
-- -----------------------------
DROP TABLE IF EXISTS `wp_config`;
CREATE TABLE `wp_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_config`
-- -----------------------------
INSERT INTO `wp_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'WeiPHP微信开发框�\�', '0');
INSERT INTO `wp_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'WeiPHP微信开发框�\�', '1');
INSERT INTO `wp_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键�\�', '1', '', '网站搜索引擎关键�\�', '1378898976', '1381390100', '1', 'WeiPHP,ThinkPHP,OneThink', '8');
INSERT INTO `wp_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开�\�', '站点关闭后其他用户不能访问，管理员可以正常访�\�', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `wp_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `wp_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案�\�', '1', '', '设置在网站底部显示的备案号，如“沪ICP�\�12007941�\�-2', '1378900335', '1379235859', '1', '苏ICP�\�14004339�\�', '9');
INSERT INTO `wp_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐�\�', '2', '', '文档推荐位，推荐到多个位置KEY值相加即�\�', '1379053380', '1379235329', '1', '1:列表页推�\�\r\n2:频道页推�\�\r\n4:网站首页推荐', '3');
INSERT INTO `wp_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见�\�', '2', '', '文章可见性仅影响前台显示，后台不收影�\�', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可�\�\r\n2:仅管理员可见', '4');
INSERT INTO `wp_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗�\�', '后台颜色风格', '1379122533', '1379235904', '1', 'blue_color', '10');
INSERT INTO `wp_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n3:用户\r\n4:系统', '4');
INSERT INTO `wp_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类�\�', '4', '', '类型 1-用于扩展显示内容�\�2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制�\�', '6');
INSERT INTO `wp_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配�\�', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `wp_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功�\�', '2', '0:关闭草稿功能\r\n1:开启草稿功�\�\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `wp_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `wp_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录�\�', '4', '', '后台数据每页显示记录�\�', '1379503896', '1391938052', '1', '20', '10');
INSERT INTO `wp_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注�\�', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `wp_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `wp_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须�\� / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `wp_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设�\�20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `wp_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压�\�', '4', '0:不压�\�\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `wp_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级�\�', '4', '1:普�\�\r\n4:一�\�\r\n9:最�\�', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `wp_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模�\�', '4', '0:关闭\r\n1:开�\�', '是否开启开发者模�\�', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `wp_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname', '0');
INSERT INTO `wp_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方�\�', '0', '', '仅超级管理员可访问的控制器方�\�', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `wp_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '20', '0');
INSERT INTO `wp_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `wp_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开�\�', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');
INSERT INTO `wp_config` VALUES ('38', 'WEB_SITE_VERIFY', '4', '登录验证�\�', '1', '0:关闭,1:开�\�', '登录时是否需要验证码', '1378898976', '1378898976', '1', '0', '2');
INSERT INTO `wp_config` VALUES ('42', 'ACCESS', '2', '未登录时可访问的页面', '4', '', '不区分大小写', '1390656601', '1390664079', '1', 'Home/User/*\r\nHome/Index/*\r\nhome/weixin/*\r\nadmin/File/*\r\nhome/File/*\r\nhome/Forum/*', '0');
INSERT INTO `wp_config` VALUES ('44', 'DEFAULT_PUBLIC_GROUP_ID', '0', '公众号默认等级ID', '3', '', '前台新增加的公众号的默认等级，值为0表示不做权限控制，公众号拥有全部插件的权�\�', '1393759885', '1393759981', '1', '0', '1');
INSERT INTO `wp_config` VALUES ('45', 'SYSTEM_UPDATE_REMIND', '4', '系统升级提醒', '4', '0:关闭\r\n1:开�\�', '开启后官方有新升级信息会及时在后台的网站设置页面头部显示升级提�\�', '1393764263', '1393764263', '1', '1', '5');
INSERT INTO `wp_config` VALUES ('46', 'SYSTEM_UPDATRE_VERSION', '0', '系统升级最新版本号', '4', '', '记录当前系统的版本号，这是与官方比较是否有升级包的唯一标识，不熟悉者只勿改变其数�\�', '1393764702', '1394337646', '1', '20140611', '0');
INSERT INTO `wp_config` VALUES ('47', 'FOLLOW_YOUKE_UID', '0', '粉丝游客ID', '0', '', '', '1398927704', '1398927704', '1', '-3477', '0');
INSERT INTO `wp_config` VALUES ('48', 'DEFAULT_PUBLIC', '0', '注册后默认可管理的公众号ID', '3', '', '可为空。配置用户注册后即可管理的公众号ID，多个时用英文逗号分割', '1398928794', '1398929088', '1', '', '0');
INSERT INTO `wp_config` VALUES ('49', 'DEFAULT_PUBLIC_CREATE_MAX_NUMB', '0', '默认用户最多可创建的公众号�\�', '3', '', '注册用户最多的创建数，也可以在用户管理里对每个用户设置不同的�\�', '1398949652', '1398950115', '1', '5', '0');
INSERT INTO `wp_config` VALUES ('50', 'COPYRIGHT', '1', '版权信息', '1', '', '', '1401018910', '1401018910', '1', 'WeiPHP 版权所�\�', '3');

-- -----------------------------
-- Table structure for `wp_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `wp_coupon`;
CREATE TABLE `wp_coupon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `start_time` int(10) NOT NULL COMMENT '开始时间',
  `end_time` int(10) NOT NULL COMMENT '结束时间',
  `use_tips` varchar(255) NOT NULL COMMENT '使用说明',
  `end_tips` text NOT NULL COMMENT '过期说明',
  `num` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券数量',
  `max_num` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '每人最多允许获取次数',
  `follower_condtion` char(50) NOT NULL DEFAULT '1' COMMENT '粉丝状态',
  `credit_conditon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分限制',
  `credit_bug` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分消费',
  `addon_condition` varchar(255) NOT NULL COMMENT '插件场景限制',
  `collect_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '已领取数',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览人数',
  `end_img` int(10) unsigned NOT NULL COMMENT '过期提示图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_credit_config`
-- -----------------------------
DROP TABLE IF EXISTS `wp_credit_config`;
CREATE TABLE `wp_credit_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '积分描述',
  `name` varchar(50) DEFAULT NULL COMMENT '积分标识',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `experience` int(10) NOT NULL DEFAULT '0' COMMENT '经验值',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '财富值',
  `token` varchar(255) NOT NULL DEFAULT '0' COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_credit_config`
-- -----------------------------
INSERT INTO `wp_credit_config` VALUES ('1', '关注公众�\�', 'subscribe', '1398565037', '10', '10', '0');
INSERT INTO `wp_credit_config` VALUES ('2', '取消关注公众�\�', 'unsubscribe', '1398565077', '-10', '-10', '0');
INSERT INTO `wp_credit_config` VALUES ('3', '参与投票', 'vote', '1398565597', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('4', '参与调研', 'survey', '1398565640', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('5', '参与考试', 'exam', '1398565659', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('6', '参与测试', 'test', '1398565681', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('7', '微信聊天', 'chat', '1398565740', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('8', '建议意见反馈', 'suggestions', '1398565798', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('9', '会员卡绑�\�', 'card_bind', '1398565875', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('10', '获取优惠�\�', 'coupons', '1398565926', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('11', '访问微网�\�', 'weisite', '1398565973', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('12', '查看自定义回复内�\�', 'custom_reply', '1398566068', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('13', '填写通用表单', 'forms', '1398566118', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('14', '访问微商�\�', 'shop', '1398566206', '0', '0', '0');
INSERT INTO `wp_credit_config` VALUES ('15', '参与投票', 'vote', '1398758905', '10', '50', 'gh_a23e6c0ae2e3');
INSERT INTO `wp_credit_config` VALUES ('16', '参与调研', 'survey', '1398759248', '1', '2', 'gh_a23e6c0ae2e3');
INSERT INTO `wp_credit_config` VALUES ('17', '关注公众�\�', 'subscribe', '1400145471', '10', '10', '-1');
INSERT INTO `wp_credit_config` VALUES ('18', '取消关注公众�\�', 'unsubscribe', '1399989514', '-10', '-10', '-1');
INSERT INTO `wp_credit_config` VALUES ('19', '获取优惠�\�', 'coupons', '1400059943', '0', '0', '-1');

-- -----------------------------
-- Table structure for `wp_credit_data`
-- -----------------------------
DROP TABLE IF EXISTS `wp_credit_data`;
CREATE TABLE `wp_credit_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `credit_name` varchar(50) NOT NULL COMMENT '积分标识',
  `experience` int(10) NOT NULL DEFAULT '0' COMMENT '经验值',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '财富值',
  `cTime` int(10) NOT NULL COMMENT '记录时间',
  `admin_uid` int(10) NOT NULL DEFAULT '0' COMMENT '操作者UID',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=844 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_credit_data`
-- -----------------------------
INSERT INTO `wp_credit_data` VALUES ('662', '363', 'weisite', '0', '0', '1402479795', '0', '539811ab60f21');
INSERT INTO `wp_credit_data` VALUES ('663', '-3350', 'unsubscribe', '-10', '-10', '1402480769', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('664', '-3351', 'subscribe', '10', '10', '1402480800', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('665', '363', 'chat', '0', '0', '1402480849', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('666', '363', 'unsubscribe', '-10', '-10', '1402482756', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('667', '363', 'subscribe', '10', '10', '1402482791', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('668', '363', 'unsubscribe', '-10', '-10', '1402482977', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('669', '363', 'subscribe', '10', '10', '1402482993', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('670', '363', 'unsubscribe', '-10', '-10', '1402483139', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('671', '363', 'subscribe', '10', '10', '1402483159', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('672', '363', 'weisite', '0', '0', '1402483244', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('673', '-3352', 'subscribe', '10', '10', '1402483917', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('674', '363', 'unsubscribe', '-10', '-10', '1402484773', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('675', '363', 'subscribe', '10', '10', '1402484790', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('676', '363', 'unsubscribe', '-10', '-10', '1402485017', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('677', '363', 'subscribe', '10', '10', '1402485037', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('678', '363', 'custom_reply', '0', '0', '1402485920', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('679', '363', 'weisite', '0', '0', '1402486855', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('680', '363', 'unsubscribe', '-10', '-10', '1402487174', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('681', '363', 'subscribe', '10', '10', '1402487197', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('682', '363', 'unsubscribe', '-10', '-10', '1402487624', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('683', '363', 'subscribe', '10', '10', '1402487646', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('684', '363', 'chat', '0', '0', '1402487660', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('685', '363', 'custom_reply', '0', '0', '1402489779', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('686', '-3353', 'chat', '0', '0', '1402492145', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('687', '363', 'custom_reply', '0', '0', '1402492159', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('688', '363', 'chat', '0', '0', '1402492338', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('689', '-3371', 'chat', '0', '0', '1402492482', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('690', '-3374', 'custom_reply', '0', '0', '1402492590', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('691', '-3377', 'weisite', '0', '0', '1402495282', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('692', '-3378', 'chat', '0', '0', '1402495339', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('693', '-3384', 'weisite', '0', '0', '1402535775', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('694', '363', 'chat', '0', '0', '1402536772', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('695', '-3385', 'unsubscribe', '-10', '-10', '1402537161', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('696', '-3386', 'subscribe', '10', '10', '1402537184', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('697', '363', 'unsubscribe', '-10', '-10', '1402537352', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('698', '363', 'subscribe', '10', '10', '1402537373', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('699', '363', 'unsubscribe', '-10', '-10', '1402537478', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('700', '363', 'subscribe', '10', '10', '1402537493', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('701', '363', 'chat', '0', '0', '1402537625', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('702', '365', 'unsubscribe', '-10', '-10', '1402538290', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('703', '365', 'subscribe', '10', '10', '1402538326', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('704', '365', 'unsubscribe', '-10', '-10', '1402538413', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('705', '365', 'subscribe', '10', '10', '1402538435', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('706', '365', 'unsubscribe', '-10', '-10', '1402538535', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('707', '365', 'subscribe', '10', '10', '1402538571', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('708', '363', 'unsubscribe', '-10', '-10', '1402538645', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('709', '363', 'subscribe', '10', '10', '1402538662', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('710', '-3391', 'custom_reply', '0', '0', '1402538710', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('711', '363', 'chat', '0', '0', '1402538805', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('712', '363', 'unsubscribe', '-10', '-10', '1402539432', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('713', '363', 'subscribe', '10', '10', '1402539489', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('714', '363', 'unsubscribe', '-10', '-10', '1402539544', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('715', '363', 'subscribe', '10', '10', '1402539596', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('716', '363', 'unsubscribe', '-10', '-10', '1402539668', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('717', '363', 'subscribe', '10', '10', '1402539683', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('718', '363', 'unsubscribe', '-10', '-10', '1402540072', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('719', '363', 'subscribe', '10', '10', '1402540090', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('720', '363', 'unsubscribe', '-10', '-10', '1402540290', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('721', '363', 'subscribe', '10', '10', '1402540307', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('722', '363', 'unsubscribe', '-10', '-10', '1402540398', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('723', '363', 'subscribe', '10', '10', '1402540440', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('724', '363', 'unsubscribe', '-10', '-10', '1402540524', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('725', '363', 'subscribe', '10', '10', '1402540539', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('726', '363', 'custom_reply', '0', '0', '1402540590', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('727', '-3392', 'unsubscribe', '-10', '-10', '1402541246', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('728', '-3393', 'subscribe', '10', '10', '1402541279', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('729', '366', 'chat', '0', '0', '1402541348', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('730', '363', 'unsubscribe', '-10', '-10', '1402541412', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('731', '363', 'subscribe', '10', '10', '1402541474', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('732', '363', 'custom_reply', '0', '0', '1402544575', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('733', '-3394', 'chat', '0', '0', '1402559838', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('734', '-3403', 'subscribe', '10', '10', '1402573687', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('735', '-3404', 'subscribe', '10', '10', '1402573982', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('736', '363', 'custom_reply', '0', '0', '1402575050', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('737', '363', 'chat', '0', '0', '1402575054', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('738', '363', 'weisite', '0', '0', '1402575055', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('739', '-3405', 'subscribe', '10', '10', '1402575087', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('740', '-3406', 'chat', '0', '0', '1402580325', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('741', '-3407', 'chat', '0', '0', '1402620955', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('742', '-3409', 'subscribe', '10', '10', '1402621302', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('743', '365', 'unsubscribe', '-10', '-10', '1402621500', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('744', '365', 'subscribe', '10', '10', '1402621537', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('745', '365', 'unsubscribe', '-10', '-10', '1402621706', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('746', '365', 'subscribe', '10', '10', '1402621730', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('747', '370', 'weisite', '0', '0', '1402621754', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('748', '365', 'chat', '0', '0', '1402622195', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('749', '365', 'weisite', '0', '0', '1402622509', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('750', '363', 'chat', '0', '0', '1402624518', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('751', '363', 'custom_reply', '0', '0', '1402625565', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('752', '363', 'chat', '0', '0', '1402626213', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('753', '1', 'custom_reply', '0', '0', '1402626439', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('754', '-3410', 'chat', '0', '0', '1402632113', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('755', '-3414', 'subscribe', '10', '10', '1402641428', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('756', '363', 'chat', '0', '0', '1402642472', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('757', '-3415', 'chat', '0', '0', '1402642604', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('758', '363', 'chat', '0', '0', '1402642855', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('759', '363', 'custom_reply', '0', '0', '1402643027', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('760', '363', 'unsubscribe', '-10', '-10', '1402643328', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('761', '364', 'chat', '0', '0', '1402643973', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('762', '364', 'unsubscribe', '-10', '-10', '1402643996', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('763', '366', 'chat', '0', '0', '1402646080', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('764', '-3417', 'unsubscribe', '-10', '-10', '1402646221', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('765', '-3418', 'chat', '0', '0', '1402649683', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('766', '-3421', 'chat', '0', '0', '1402650546', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('767', '363', 'subscribe', '10', '10', '1402652305', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('768', '363', 'chat', '0', '0', '1402652886', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('769', '363', 'custom_reply', '0', '0', '1402652965', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('770', '1', 'custom_reply', '0', '0', '1402653323', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('771', '363', 'chat', '0', '0', '1402653333', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('772', '1', 'custom_reply', '0', '0', '1402655170', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('773', '1', 'custom_reply', '0', '0', '1402656333', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('774', '1', 'weisite', '0', '0', '1402660289', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('775', '365', 'chat', '0', '0', '1402660451', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('776', '365', 'custom_reply', '0', '0', '1402660594', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('777', '1', 'weisite', '0', '0', '1402660774', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('778', '365', 'weisite', '0', '0', '1402660809', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('779', '-3424', 'weisite', '0', '0', '1402662647', '0', '-1');
INSERT INTO `wp_credit_data` VALUES ('780', '363', 'chat', '0', '0', '1402663031', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('781', '363', 'unsubscribe', '-10', '-10', '1402663137', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('782', '363', 'subscribe', '10', '10', '1402663187', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('783', '1', 'custom_reply', '0', '0', '1402663744', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('784', '365', 'chat', '0', '0', '1402688416', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('785', '-3439', 'subscribe', '10', '10', '1402729425', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('786', '-3441', 'subscribe', '10', '10', '1402729988', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('787', '363', 'chat', '0', '0', '1402730345', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('788', '-3443', 'unsubscribe', '-10', '-10', '1402738753', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('789', '363', 'chat', '0', '0', '1402740109', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('790', '363', 'weisite', '0', '0', '1402794101', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('791', '365', 'unsubscribe', '-10', '-10', '1402794439', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('792', '365', 'subscribe', '10', '10', '1402794485', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('793', '363', 'custom_reply', '0', '0', '1402794626', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('794', '363', 'unsubscribe', '-10', '-10', '1402795029', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('795', '363', 'subscribe', '10', '10', '1402795080', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('796', '363', 'chat', '0', '0', '1402795368', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('797', '365', 'chat', '0', '0', '1402795388', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('798', '1', 'custom_reply', '0', '0', '1402795645', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('799', '365', 'chat', '0', '0', '1402796710', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('800', '1', 'custom_reply', '0', '0', '1402796801', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('801', '363', 'chat', '0', '0', '1402797118', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('802', '363', 'chat', '0', '0', '1402797486', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('803', '366', 'weisite', '0', '0', '1402799038', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('804', '366', 'chat', '0', '0', '1402799121', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('805', '365', 'weisite', '0', '0', '1402799237', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('806', '363', 'chat', '0', '0', '1402800424', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('807', '363', 'unsubscribe', '-10', '-10', '1402800600', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('808', '363', 'subscribe', '10', '10', '1402800620', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('809', '363', 'chat', '0', '0', '1402801237', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('810', '365', 'chat', '0', '0', '1402801886', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('811', '363', 'chat', '0', '0', '1402801899', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('812', '363', 'custom_reply', '0', '0', '1402801949', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('813', '363', 'custom_reply', '0', '0', '1402803183', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('814', '363', 'chat', '0', '0', '1402803221', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('815', '1', 'suggestions', '0', '0', '1402804076', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('816', '363', 'custom_reply', '0', '0', '1402806280', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('817', '363', 'chat', '0', '0', '1402806303', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('818', '363', 'unsubscribe', '-10', '-10', '1402809128', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('819', '363', 'subscribe', '10', '10', '1402809154', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('820', '363', 'card_bind', '0', '0', '1402810864', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('821', '1', 'custom_reply', '0', '0', '1402813074', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('822', '363', 'custom_reply', '0', '0', '1402821515', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('823', '363', 'chat', '0', '0', '1402821576', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('824', '-3465', 'subscribe', '10', '10', '1402822939', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('825', '377', 'custom_reply', '0', '0', '1402822999', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('826', '-3466', 'subscribe', '10', '10', '1402828770', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('827', '365', 'weisite', '0', '0', '1402885834', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('828', '-3468', 'custom_reply', '0', '0', '1402886425', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('829', '-3472', 'chat', '0', '0', '1402886474', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('830', '-3476', 'subscribe', '10', '10', '1402886651', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('831', '379', 'custom_reply', '0', '0', '1402886738', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('832', '379', 'chat', '0', '0', '1402886803', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('833', '379', 'weisite', '0', '0', '1402886823', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('834', '379', 'custom_reply', '0', '0', '1402887089', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('835', '379', 'chat', '0', '0', '1402887402', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('836', '379', 'custom_reply', '0', '0', '1402887468', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('837', '379', 'custom_reply', '0', '0', '1402887769', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('838', '1', 'weisite', '0', '0', '1402889340', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('839', '363', 'unsubscribe', '-10', '-10', '1402889992', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('840', '363', 'subscribe', '10', '10', '1402890030', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('841', '363', 'unsubscribe', '-10', '-10', '1402890228', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('842', '363', 'subscribe', '10', '10', '1402890238', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_credit_data` VALUES ('843', '1', 'weisite', '0', '0', '1402892141', '0', 'gh_ccbc7c79380e');

-- -----------------------------
-- Table structure for `wp_custom_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_menu`;
CREATE TABLE `wp_custom_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `url` varchar(255) DEFAULT NULL COMMENT '关联URL',
  `keyword` varchar(100) DEFAULT NULL COMMENT '关联关键词',
  `title` varchar(50) NOT NULL COMMENT '菜单名',
  `pid` tinyint(2) DEFAULT '0' COMMENT '一级菜单',
  `sort` tinyint(4) DEFAULT '0' COMMENT '排序号',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_custom_menu`
-- -----------------------------
INSERT INTO `wp_custom_menu` VALUES ('55', '', '孕婴知识', '孕婴知识', '0', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('56', '', '育儿宝典', '育儿宝典', '0', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('57', '', '互动社区', '互动社区', '0', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('58', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/62.html', '', '备孕知识', '55', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('59', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/63.html', '', '孕期知识', '55', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('60', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/65.html', '', '产后康复', '55', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('61', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/64.html', '', '婴儿护理', '55', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('62', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html', '', '学前教育', '56', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('63', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/71.html', '', '成长教育', '56', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('64', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/67.html', '', '交流互动', '57', '1', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('65', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/69.html', '', '积分兑换', '57', '3', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('66', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/68.html', '', '幸运时刻', '57', '2', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('71', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/70.html', '', '关于我们', '57', '4', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('68', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/59.html', '', '健康保健', '56', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('69', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/60.html', '', '亲子游戏', '56', '0', 'gh_ccbc7c79380e');
INSERT INTO `wp_custom_menu` VALUES ('70', '/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/66.html', '', '宝贝秀', '57', '0', 'gh_ccbc7c79380e');

-- -----------------------------
-- Table structure for `wp_custom_reply_mult`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_reply_mult`;
CREATE TABLE `wp_custom_reply_mult` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词类型',
  `mult_ids` varchar(255) NOT NULL COMMENT '多图文ID',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_custom_reply_news`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_reply_news`;
CREATE TABLE `wp_custom_reply_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) DEFAULT NULL COMMENT '关键词类型',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text COMMENT '简介',
  `cate_id` int(10) unsigned DEFAULT '0' COMMENT '所属类别',
  `cover` int(10) unsigned DEFAULT NULL COMMENT '封面图片',
  `content` text NOT NULL COMMENT '内容',
  `cTime` int(10) DEFAULT NULL COMMENT '发布时间',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `jump_url` varchar(255) NOT NULL COMMENT '外链',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_custom_reply_news`
-- -----------------------------
INSERT INTO `wp_custom_reply_news` VALUES ('57', '饮食帮助�\�', '3', '饮食助长,宝宝吃出高个�\�', '', '59', '381', '<h2 class=\"entry_name\" style=\"text-align: center;\">饮食助长,宝宝吃出高个�\�</h2><p><strong>导语�\�</strong>这个季节是宝宝们出外活动的好时节，爸爸妈妈们也以“放养”的态度对待，其实也是为了能让宝宝多多运动，快快长高。宝宝长个子，那就一定要从营养上多多总结啦，看似什么都不缺的宝贝，身体内需要哪些营养元素的支持，爸爸妈妈们真的了解吗？而盲目给孩子增高进补，反而会伤害孩子的健康，这些爸爸妈妈们又做对了吗？今天，就跟随小编为爸爸妈妈们整理的资料一起来关注一下吧�\�</p><p><br/></p><p><img src=\"/Uploads/Editor/-1/2014-06-15/539cfcb0e3372.jpg\" title=\"ed2ba9a93.jpg\"/></p><p><strong style=\"text-align: center;\">（甜食糖果要少吃�\�</strong></p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/1(3006).jpg\" jquery17105395756674817389=\"23\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/1(3006).jpg\" width=\"500\" height=\"38\" jquery17105395756674817389=\"12\"/></a></p><p><strong>1.对这种糖果甜食说不：</strong></p><p>吃糖过多会影响体内脂肪的消耗，造成脂肪堆积，还会影响钙质代谢。一些专业人士认为，吃糖量如果达到总食量的16%�\�18%，就可使体内钙质代谢紊乱，妨碍体内的钙化作用，影响长高。另一方面，营养学术语中有“虚卡路里”的说法，即毫无营养的热量。过量饮用含糖分多的饮料，会扰乱消化系统，以致影响正常进食，造成营养不良�\�</p><p><strong>2、吃饭时少喝水：</strong></p><p>吃饭时喝很多水会冲淡胃中的消化液，妨碍食物的消化吸收。另外，饭前喝水会降低食欲，所以要尽量避免。而饭后喝适量的蔬菜汤或牛肉汤等，会对长个有利�\�</p><p><strong>3、细嚼慢咽：</strong></p><p>快吃食物会给胃增加负担，导致消化吸收障碍，甚至引起胃肠疾病�\�</p><p><strong>4、含盐分高的食品要尽量少吃：</strong></p><p>各种腌制食品和香肠，以及熏肉等盐分较高，又是熏制食品，对胃肠黏膜有较大的刺激性，而且这类食品中维生素含量很低，对孩子成长也不利�\�</p><p><strong>5、碳酸饮料要少喝�\�</strong></p><p>偏爱饮用碳酸饮料的儿童有60%因缺钙影响正常发育。特别是可乐型饮料中磷含量过高，过量饮用导致体内钙、磷比例失调，造成发育迟缓�\�</p><p><strong>6、饭后休息一小时左右�\�</strong></p><p>饭后让大脑和全身都休息一下，对消化系统的正常运转是很重要的�\�</p><p><strong>7、拒绝“垃圾食品”的诱惑�\�</strong></p><p>油炸食品、膨化食品、腌制食品、罐头类制品由于在制作过程中营养损失大，又使用了各种添加剂，如香精、防腐剂、色素等，虽然它们提供了大量热量，但蛋白质、维生素等营养成分却很少，长期食用这类食品，可导致儿童营养不良�\�</p><p style=\"TEXT-ALIGN: center\"><br/></p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/2(1993).jpg\" jquery17105395756674817389=\"24\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/2(1993).jpg\" width=\"500\" height=\"38\" jquery17105395756674817389=\"13\"/></a></p><p><br/></p><p>　　每年的春秋两季是补钙的最佳时期。对处于生长发育期的孩子来说，春季更是骨骼生长的黄金季节，为了有利于孩子长高，不要错过春天给孩子补钙的好时机。下面介绍几款补钙美食，妈妈们不要错过�\�</p><p>春天是孩子长个的好季节，孩子长高主要是骨骼发育的结果。骨的主要成分是钙，因此，春季应供给孩子充足的钙。最好采用食补法，含钙丰富的食物有芝麻、黄花菜、萝卜、胡萝卜、海带、芥菜、田螺、虾皮等。再就是排骨汤或骨头汤，这些汤不仅含钙丰富，而且有助于身体对钙的吸收�\�</p><p><span style=\"COLOR: #ff6600\"><strong>一、鲫鱼豆腐汤<br/></strong></span></p><p style=\"TEXT-ALIGN: center\"><br/></p><p><strong><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/gic7689093.jpg\" jquery17105395756674817389=\"25\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/gic7689093.jpg\" width=\"400\" height=\"401\" jquery17105395756674817389=\"14\"/></a></strong></p><p><br/></p><p>　　<strong>原料�\�</strong>鲫鱼250克、嫩豆腐200克、姜、葱、盐、油适量�\�</p><p><strong>制法�\�</strong>先将鱼去鳞、腮、内脏洗净，沥干，豆腐切成1厘米厚�\�5厘米长�\�3厘米宽的块。再将鱼下油锅煎至鱼皮脱水、收紧，放入温水煮开，放少量料酒，改小火，放葱、姜、盐等，煮约8分钟放入切好的豆腐块与鱼同煮�\�6分钟即可�\�</p><p><span style=\"COLOR: #ff6600\"><strong>二、花生海鲜米仁粥</strong></span></p><p style=\"TEXT-ALIGN: center\"><br/></p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/2009060614465144705.jpg\" jquery17105395756674817389=\"26\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/2009060614465144705.jpg\" width=\"400\" height=\"301\" jquery17105395756674817389=\"15\"/></a></p><p><br/></p><p>　　<strong>原料�\�</strong>花生�\�30克，水发海参30克，目鱼30克，虾仁30克，米仁50克，粳米100克，盐、酒适量；葱、姜、米醋少许，汤骨100克�\�</p><p><strong>制法�\�</strong>在锅中加入葱、姜和酒适量，放入汤骨（斩断），烧开后，撇去浮沫，滴入米醋少许，再小火烧40分钟。取出汤骨和葱姜，放入漂洗的米仁，米仁开花后，加入粳米一并熬成粥，加入花生细粒、海参、目鱼和虾仁，一同滚熟，再加入盐、葱末即可�\�</p><p><strong>功效�\�</strong>有养血润肺、去燥除湿等功效，为幼儿补钙营养粥�\�</p><p><span style=\"COLOR: #ff6600\"><strong>三、果酱薄�\�<br/></strong></span></p><p style=\"TEXT-ALIGN: center\"><br/></p><p><strong><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/u2562p20t47d224108f776dt20130503100257.jpg\" jquery17105395756674817389=\"27\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/u2562p20t47d224108f776dt20130503100257.jpg\" width=\"400\" height=\"278\" jquery17105395756674817389=\"16\"/></a></strong></p><p><br/></p><p>　<strong>　原料�\�</strong>面粉60克，鸡蛋2个，牛奶150克。肥�\�1小块，精�\�1克，黄油15克，果酱适量�\�</p><p><strong>制法�\�</strong></p><p>1、将面粉放入碗内，磕入鸡蛋，用竹筷搅拌均匀，再加入精盐和化开的黄油、牛奶搅匀，饧20分钟成面糊�\�</p><p>2、将小锅置火上烧热，用肥肉把锅四周抹一下，倒入一汤勺面糊，使面糊在锅的四周均匀分布，待一面烙熟后，翻过来（不要破碎）再烙另一面至熟�\�</p><p>3、按同样方法烙第二张、第三张，直至烙完为止。在薄饼上放一点果酱，卷起来，即可喂食�\�</p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/3(1309).jpg\" jquery17105395756674817389=\"28\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/3(1309).jpg\" width=\"500\" height=\"38\" jquery17105395756674817389=\"17\"/></a></p><p>另外，建议家长给孩子多吃奶酪、酸奶，注意不要用含乳饮料代替牛奶，因为含乳饮料主要成分是水。蛋、肉、鱼所含人体必需氨基酸比较完备，营养价值高，含蛋白质丰富，宜多吃�\�</p><p>特别推荐五种增高食物：牛奶、沙丁鱼、菠菜、胡萝卜、橘子�\�</p><p><br/></p>', '1402797379', '0', '0', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('55', '学前教育', '3', '教你愉快亲子教育六个小方�\�', '允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ', '61', '380', '<p style=\"word-wrap: break-word; margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; text-indent: 2em; -color: rgb(255, 255, 255);\"><span style=\"word-wrap: break-word; font-weight: 700;\"><span style=\"font-size:4px;word-wrap: break-word;\">一、给孩子一个选择</span></span></p><p><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件。�\�</span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　<span style=\"word-wrap: break-word; font-weight: 700;\">二、接受现在的他�\�</span></span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　如果你感兴趣的仅仅是你的孩子是否是全班最好的朗诵者，那么，你的期望就太过分了。每个孩子都是按照自己的速度来发展、成长的。把你的孩子与其他孩子相比较会让他认为，如果他没能按某一特定标准去学习、做事的话，他就是一个失败者。�\�</span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　<span style=\"word-wrap: break-word; font-weight: 700;\">三、找找是否有隐藏在暗中的困难存在 </span></span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　你是否问过你的孩子为什么突然间不愿意参加集体活动或不愿做家庭作业了吗？也许他会在你的询问下说出心里话——他被坏孩子欺负了，他不喜欢他的老师等等。如果孩子变得毫无动力了，通常他会有一个正当的理由。�\�</span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　<span style=\"word-wrap: break-word; font-weight: 700;\">四、解释你的理由�\�</span></span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　如果你不希望你的孩子放弃钢琴教育，因为你很肯定这是对他有好处的，那么你会怎么做呢？无论你想怎么做，决不能冲你的孩子大喊大叫、声嘶力竭地训斥他。因为大叫后没几分钟，他就不再去听你在说些什么了。�\�</span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　<span style=\"word-wrap: break-word; font-weight: 700;\">五、重视赞扬的作用 </span></span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　赞扬必须是有的放矢的。你仅仅说了句“干得不错”，他就会知道，你并没有真的注意到他和他的成就。�\�</span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　<span style=\"word-wrap: break-word; font-weight: 700;\">六、明智的奖赏 </span></span><br style=\"word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; font-size: 15px; line-height: 22.5px; white-space: normal; -color: rgb(255, 255, 255);\"/><span style=\"font-size:4px;word-wrap: break-word; color: rgb(68, 68, 68); font-family: Tahoma, \'Microsoft Yahei\', Simsun; white-space: normal; -color: rgb(255, 255, 255);\">　　父母会许诺，如果孩子考试考得好，他就会得到一辆自行车；如果考得不好就什么也得不到。事实上，这样对待孩子是一种可怕的态度。建议各位父母不要给你的孩子许以大奖赏�\�</span></p><p><br/></p>', '1402655117', '0', '14', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('56', '健康保健', '3', '宝宝抱着睡易致脊柱弯�\�', '许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲�\�', '59', '377', '<p><span style=\"font-family: Simsun; font-size: 14px; line-height: 24px;\">     许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲�\�</span><br/></p><p><span style=\"font-family: Simsun; font-size: 14px; line-height: 24px;\"><img src=\"http://joint4.xicp.net/Uploads/Editor/-1/2014-06-13/539af71862440.jpg\" title=\"liaI3jS72O4Jw.jpg\" style=\"white-space: normal;\"/></span></p><p><span style=\"font-family: Simsun; font-size: 14px; line-height: 24px;  -color: rgb(255, 255, 255);\">     </span><span style=\"font-family: Simsun; font-size: 14px; line-height: 24px;\">宝宝生长发育过程中，脊柱会逐渐出现三个生理弯曲�\�2�\�3个月左右宝宝能够抬头，出现第一个生理弯曲——颈部脊柱前凸；6个月左右会独坐，出现第二个生理弯曲——胸部脊柱后凸；8�\�9个月时会爬，10�\�11个月能站立，这时会出现第三个生理弯曲——腰部脊柱前凸，12�\�16个月时能走路。就是这些生理弯曲的形成，能使身体保持平衡并直立行走。虽然宝宝在1岁以内就会出现这3个弯曲，但一直要到六七岁时，宝宝的脊柱弯曲才会彻底固定下来。由此可见，</span><a title=\"\" href=\"http://www.wujue.com/yxbk/baby/\" target=\"_blank\" style=\"font-family: Simsun; font-size: 14px; line-height: 24px; text-decoration: none; color: rgb(51, 51, 51);\">婴幼</a><span style=\"font-family: Simsun; font-size: 14px; line-height: 24px;\">儿期的骨骼发育还未成熟和定型，若脊柱长期处于弯曲的状态，就可能出现畸形、不正常弯曲等情况，这将影响宝宝的正常发育。如果得不到纠正，长大后就可能有脊柱侧弯、驼背等现象�\�</span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: Simsun; font-size: 14px; line-height: 24px; white-space: normal;\">　　宝宝希望时刻躺在大人怀中，因为这会让其感到温暖、安定，这是宝宝的正�\�<a class=\"channel_keylink\" href=\"http://www.wujue.com/yxbk/xinli/\" target=\"_blank\" style=\"color: blue;\">心理</a>需求，但是，如果大人特别是老人，总是“爱不释手”，只要宝宝一哭，就抱在怀里哄，时间长了，宝宝就有了过分依赖的心理，最后养成了只有抱着才肯睡觉的习惯。专家认为，抱着宝宝睡觉，不仅会使宝宝睡得不深，身体不能舒展，影响睡眠质量，也不利于宝宝呼吸换气，脊柱长期处于弯曲的状态，会影响其正常发育。所以最好是能够让宝宝在吃饱了奶之后，舒舒服服地躺在床上自然入睡�\�</p><p><span style=\"font-family: Simsun; font-size: 14px; line-height: 24px;  -color: rgb(255, 255, 255);\"><br/></span><br/></p>', '1402664814', '0', '20', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('58', '母乳存留也能做宝宝辅�\�', '3', '母乳存留也能做宝宝辅�\�', '', '59', '383', '<p><strong>导语�\�</strong>母乳喂养的宝贝到了六个月左右，就要开始添加辅食了，不少人疑惑道：难道母乳六个月后，就没有营养价值了吗？其实不然，宝宝的生长速度加快，需要的营养更多了，而且小宝贝需要逐渐断奶，添加辅食以帮助骨骼各方面的生长，所以辅食的补充就很重要了。但是不少妈妈还是希望宝宝能获得更全面的营养，母乳和辅食都不能少，有趣的是，台湾母乳协会就发挥了创意，用库存的母乳或者现挤母乳做辅食，具有高度的营养价值。哇，这个想法是不是很赞，一起跟随小编整理的资料来看看，如何化“母乳”为“辅食”吧�\�</p><p style=\"TEXT-ALIGN: center\"><br/></p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/81990358(1).jpg\" jquery17106551341347814712=\"21\"><img title=\"点击查看大图\" alt=\"母乳喂养\" src=\"http://f.yaolanimage.cn/cms/image/81990358(1).jpg\" width=\"400\" height=\"266\" jquery17106551341347814712=\"11\"/></a></p><p><br/><strong>（母乳喂养）</strong></p><p><br/></p><p>　　母乳中含有珍贵的营养成分，除了单独喂宝宝喝之外，还可以添加在辅食品当中，变成宝宝的营养食品喔!其实已经有许多母乳妈咪发现：把母奶加入食材中也可以增加母乳宝宝对新食物的接受�\�!例如，米粉加上现挤的母奶就是一道初期的辅食品，而香蕉刮泥后再加一点母奶调和稠度也是很多宝宝最爱的食物�\�!</p><p>不过用母乳做成的辅食品，保存的时间可就变短啰。一般的母奶在室温下可以�\�4-6个小时，为了减少营养素被破坏，烹调过程中尽量将母乳的加热温度，维持在摄氏60度以下。但如果加入了其它东西做成辅食品，就无法放置太久，建议最好当餐就要吃完�\�</p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/1(3047).jpg\" jquery17106551341347814712=\"22\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/1(3047).jpg\" width=\"500\" height=\"54\" jquery17106551341347814712=\"12\"/></a></p><p><strong>1、蛋白质</strong></p><p>人乳和牛乳中乳白蛋白与酪蛋白的比率不同。人乳中乳白蛋白占总蛋白的70%以上，与酪蛋白的比例�\�2�\�1。牛乳的比例�\�1�\�4.5。乳白蛋白可促进糖的合成，在胃中遇酸后形成的凝块小，利于消化。而牛奶中大部分是酪蛋白，在婴儿胃中容易结成硬块，不易消化，且可使大便干燥�\�</p><p><strong>2、氨基酸</strong></p><p>人乳中含牛磺酸较牛乳为多。牛磺酸与胆汁酸结合，在消化过程中起重要作用，它可维持细胞的稳定性�\�</p><p><strong>3、乳�\�</strong></p><p>母乳中所含乳糖比牛羊奶含量高，对婴儿脑发育有促进作用。母乳中所含的乙型乳糖有间接抑制大肠杆菌生长的作用。而牛乳中是甲型乳糖，能间接促进大肠杆菌的生长。另外，乙型乳糖还有助于钙的吸收�\�</p><p><strong>4、脂�\�</strong></p><p>母乳中脂肪球少，且含多种消化酶，加上小儿吸吮乳汁时舌咽分泌的舌脂酶，有助于脂肪的消化。故对缺乏胰脂酶的新生儿和早产儿更为有利。此外，母乳中的不饱和脂肪酸对婴儿脑和神经的发育有益�\�</p><p><strong>5、无机盐</strong></p><p>母乳中钙磷的比例�\�2�\�1，易于吸收。对防治佝偻病有一定作用。而牛奶为1�\�2，不易吸收�\�</p><p><strong>6、微量元�\�</strong></p><p>母乳中锌的吸收率可达59.2%，而牛乳仅�\�42%。母乳中铁的吸收率为45%-75%，而牛奶中铁的吸收率为13%。此外，母乳中还有丰富的铜，对保护婴儿娇嫩心血管有很大作用�\�</p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/2(2005).jpg\" jquery17106551341347814712=\"23\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/2(2005).jpg\" width=\"500\" height=\"54\" jquery17106551341347814712=\"13\"/></a></p><p><span style=\"COLOR: #ff6600\"><strong>母乳苹果地瓜�\�<br/></strong></span></p><p style=\"TEXT-ALIGN: center\"><span style=\"COLOR: #ff6600\"></span></p><p><strong><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/a0b3ccf7dbf8120eb26a0c.jpg\" jquery17106551341347814712=\"24\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/a0b3ccf7dbf8120eb26a0c.jpg\" width=\"390\" height=\"214\" jquery17106551341347814712=\"14\"/></a></strong></p><p><br/></p><p>　<strong>　材料�\�</strong>地瓜一�\�15g、苹�\�6g、葡萄干一颗、母�\�50c.c.</p><p><strong>制作方式�\�</strong></p><p>1.先将地瓜洗净，放入电饭锅蒸熟，待凉�\�</p><p>2.再将苹果去皮，切薄片煮软；葡萄干用水泡软备用�\�</p><p>3.食用时，用汤匙捣烂，再加入母乳，稠稀的程度视母乳加入量而定�\�</p><p><strong>营养分析�\�</strong>热量51.1kcal／蛋白质0.91g／脂�\�1.45g／醣�\�8.69g／维生素A228.23RE／维生素B10.06mg／维生素B20.02mg／维生素C4.08mg／钙21.78mg／磷19.11mg／铁0.18mg</p><p><span style=\"COLOR: #ff6600\"><strong>母乳鸡蓉玉米浓汤<br/></strong></span></p><p style=\"TEXT-ALIGN: center\"><span style=\"COLOR: #ff6600\"></span></p><p><strong><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/2009032016280780.jpg\" jquery17106551341347814712=\"25\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/2009032016280780.jpg\" width=\"400\" height=\"287\" jquery17106551341347814712=\"15\"/></a></strong></p><p><br/></p><p>　　<strong>材料�\�</strong>玉米�\�50c.c.、鸡�\�4g、母�\�30c.c.、洋香菜叶少�\�</p><p><strong>制作方法�\�</strong></p><p>1.鸡肉煮熟撕成细碎备用�\�</p><p>2.高汤或水煮滚后，放入玉米酱、鸡肉煮至沸腾熄火�\�</p><p>3.待略凉，食用时再加入母乳�\�</p><p><strong>营养分析�\�</strong>热量52.28kcal／蛋白质1.87g／脂�\�1.16g／醣�\�8.71g／维生素A0.33RE／维生素B10.04mg／维生素B20.028mg／维生素C2.17mg／钙11.44mg／磷29.4mg／铁0.92mg</p><p><span style=\"COLOR: #ff6600\"><strong>母乳鸡蓉稀�\�<br/></strong></span></p><p style=\"TEXT-ALIGN: center\"><span style=\"COLOR: #ff6600\"></span></p><p><strong><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/9090260125291989012_%E5%89%AF%E6%9C%AC.jpg\" jquery17106551341347814712=\"26\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/9090260125291989012_%E5%89%AF%E6%9C%AC.jpg\" width=\"400\" height=\"224\" jquery17106551341347814712=\"16\"/></a></strong></p><p><br/></p><p>　　<strong>材料�\�</strong>鸡肉3g、白�\�25g、红萝卜1g、母�\�20c.c.、芝麻海苔少�\�</p><p><strong>制作方式�\�</strong></p><p>1.鸡肉煮熟撕成细碎备用�\�</p><p>2.白饭和水煮成稠状，放入鸡肉和熟软的红萝卜，煮滚即可�\�</p><p>3.待略凉加入母乳和芝麻海苔�\�</p><p><strong>　营养分析�\�</strong>热量61.65kcal／蛋白质1.738g／脂�\�0.727g／醣�\�11.77g／钙7.58mg／钠5.76mg／磷21.96mg／铁0.106mg／VitaB10.0132mg／VitaB20.0113mg／烟碱素0.4265mg</p><p>        <span style=\"COLOR: #ff6600\"><strong>   \r\n[专家总结]�\�</strong></span>6个月以后必须好好的加辅食，奶的能量密度和营养素已经不能完全保证孩子生长发育。现在孩�\�9个月要上午、下午各吃一顿辅食，辅食的量和品种，可以循序渐进根据孩子消化能力调整。喂辅食的时间要基本固定，不能总变。吃辅食�\�2个小时要不给孩子吃任何东西，也不要吃奶，包括不要喝甜水，如果孩子渴了，可以用小勺喂几口白水，这样孩子会有明显的饥饿感，对辅食的亲和性就会增加�\�</p><p><br/></p>', '1402797688', '0', '1', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('59', '健康零食', '3', '1-3岁宝宝的健康零食', '', '59', '384', '<p><strong>导语�\�</strong>宝宝的饮食健康时刻牵动着爸爸妈妈们的心，1-3岁的宝贝已经可以自由的抱着小零食了，可是哪些零食对于宝宝们是健康有益的呢？一起跟随小编来看看吧�\�</p><p style=\"TEXT-ALIGN: center\"><br/></p><p><img alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/137041841.jpg\" width=\"400\" height=\"266\"/></p><p><br/></p><p>　　宝宝补充营养需要从不同的渠道，当然贪吃的他们除了正餐也闲不住嘴，以下这些零食可是非常有助于宝宝身体健康的�\�</p><p>　　<strong>1、补钙乳制品</strong></p><p>　　酸奶、奶酪。最佳的宝贝零食，富含钙、磷、镁、铜等矿物质、蛋白质、脂肪和维生素B1、B2，蛋白质经有益菌发酵更利于吸收，乳酸杆菌等健康菌群还能帮助调理宝贝的肠道，应为首选�\�</p><p>　　配方奶。可以作�\�2岁以内的宝贝午觉之后的加餐，营养和水分的补充同时完成，但是量不宜太多，以免影响正餐食量�\�</p><p>　　<strong>2、新鲜水果和蔬菜</strong></p><p>　　切成小块或小片的新鲜成熟胡萝卜、黄瓜、苹果、哈密瓜、草莓、西瓜等，富含糖分、维生素C、膳食纤维，在补充营养的同时，还可锻炼宝贝自己拿东西吃的技能，以及对蔬菜水果的兴趣，一举多得。但是，千万要洗净小手才能抓着吃！</p><p>　　自制果蔬沙拉。用番茄沙司或酸奶代替沙拉酱更加健康，也可以把什锦水果碎丁加入酸奶中，让酸奶的味道和营养都锦上添花！</p><p>　　黄瓜等味道淡的果蔬，蘸食番茄沙司、芝麻酱等食用，更易被宝贝接受�\�</p><p>　　<strong>3、麦香小面包</strong></p><p>　　2岁以内的宝贝，宜选用松软的切片吐司面包或奶香小餐包，切成手指大小的条状以便宝贝咀嚼；2岁以上的宝贝，可以选用杂粮面包或者全麦面包，以帮助他们摄入更多的膳食纤维和B族维生素�\�</p><p>　　<strong>4、健康小饮品</strong></p><p>　　豆浆、自制果蔬鲜榨汁、南瓜百合羹、牛奶玉米汁(需要煮熟过�\�)、绿豆沙、菊花水、山楂水等，都是优于瓶装饮料的健康饮品�\�</p><p>       <span style=\"COLOR: #ff6600\"><strong> 摇篮专家小贴�\�</strong></span></p><p>　<span style=\"COLOR: #ff6600\"><strong>　[专家]沈文�\�</strong></span>目前对于健康的零食没有统一的标准。以中国儿童零食指南来说，低脂、低糖、低盐的零食就是比较健康的零食。比如说：水煮的鸡蛋、水煮的玉米、红薯等等。这是《中国青少年零食指南》里建议�\�<span class=\"wp_keywordlink_affiliate\"><a title=\"查看健康零食中的全部文章\" href=\"http://www.grow2up.cn/tag/%e5%81%a5%e5%ba%b7%e9%9b%b6%e9%a3%9f\" target=\"_blank\">健康零食</a></span>。水煮蛋、水煮虾、无糖或低糖燕麦片、煮玉米、蒸、煮的红薯、土豆等无糖或低糖全麦面包、全麦饼干等；豆浆、烤黄豆、烤黑豆等；香蕉、西红柿、黄瓜、梨、桃、苹果、柑橘、西瓜、葡萄等；纯鲜牛奶、纯酸奶等花生米、核桃仁、大杏仁、松子、榛子等不加糖的鲜榨橙汁、西瓜汁、芹菜汁、胡萝卜汁等。常给宝宝吃酸奶、水果是很好的选择，建议一般吃零食的时间在饭后一个半小时左右。孩子半饿不饿的时候，适量给孩子零食。一般来说，一天不超过三次。最好是二次即可。至于饼干，饼干的品种非常多，多数为了保持饼干的货架期，以及饼干的美味，或多或少的会添加反式脂肪酸，根据这种情况可以酌情考虑给孩子添加饼干。个人建议可以给孩子吃一些苏打饼干。苏打饼干是经过发酵的饼干，能给孩子有一些维生素B族的有益补充。也可以给孩子选择一些含纤维比较高的饼干�\�</p><p style=\"TEXT-ALIGN: center\"><br/></p><p><br/></p>', '1402797964', '0', '0', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('60', '健康保健宝宝', '3', '齿终如一 宝宝护牙从刷牙开�\�', '', '59', '385', '<p></p><p><p>[<strong>摘要</strong>]俗语有云，万事开头难，宝宝学刷牙也是这样一个道理。教会他们养成一个需要坚持一生的好习惯，并非什么反掌之事。如何训练孩子养成正确刷牙的习惯？我们一起来看看吧！</p><p><br/></p><p style=\"text-align:center;\"><br/></p><p><a class=\"jzoom\" href=\"http://img1.gtimg.com/baby/pics/hv1/99/242/1620/105402309.jpg\" jquery1710476371257763619=\"16\"><img title=\"点击查看大图\" alt=\"齿终如一 宝宝护牙从刷牙开�\�\" src=\"http://img1.gtimg.com/baby/pics/hv1/99/242/1620/105402309.jpg\" jquery1710476371257763619=\"11\"/></a></p><p><br/></p><p style=\"TEXT-INDENT: 2em\">发育正常的小朋友，一般在两岁半左右长出所有的乳牙。在这个时候就应该训练他们爱护牙齿的意识，从小养成良好的刷牙习惯。有些家长忽视牙齿健康，总想省些功夫，等宝宝们大些才开始刷牙，而有些家长甚至让孩子含住奶瓶睡觉。广州市红十字会医院口腔科主任叶志佳介绍，曾经有一个三岁的小朋友，满口牙全是黑色的，牙齿基本都烂掉了，原来患儿的妈妈从来都是让孩子含着奶瓶睡觉，很少清洁口腔�\�</p><p><strong>如何�\�<span class=\"wp_keywordlink_affiliate\"><a title=\"查看宝宝刷牙中的全部文章\" href=\"http://www.grow2up.cn/tag/%e5%ae%9d%e5%ae%9d%e5%88%b7%e7%89%99\" target=\"_blank\">宝宝刷牙</a></span>�\�</strong></p><p><br/></p><p style=\"TEXT-INDENT: 2em\"><strong>一、牙齿清洁要从第一颗乳牙开�\�</strong></p><p style=\"TEXT-INDENT: 2em\">当小朋友在半岁左右萌出第一颗乳牙开始，父母就应该给小儿清洁牙齿了。家长可以用纱布、棉签蘸湿温水擦洗。而等孩子长大一些，就可以跟孩子说爱护牙齿的重要性，每天让孩子看自己刷牙。而到宝宝2岁左右，动作比较灵活了，就要学着自己刷牙。有了刷牙的耳濡目染，小儿基本上适应了刷牙。但从别人刷到自己学着刷需要一个过程�\�</p><p style=\"TEXT-INDENT: 2em\"><strong>二、准备可爱清新的刷牙用具</strong></p><p style=\"TEXT-INDENT: 2em\">小朋友都是贪新鲜的，喜欢花花绿绿，甜甜味道的东西。所以如果要让孩子养成刷牙习惯的话，就要先让他们爱上刷牙�\�</p><p style=\"TEXT-INDENT: 2em\">应该要如何挑选牙刷和牙膏呢？卡通软毛的儿童牙刷就最受小朋友欢迎了。牙刷使�\�3个月后就要更换。而牙膏方面，最好选用含水果甜味的儿童牙膏�\�3岁以下的幼儿不宜使用含氟牙膏。最好早晚牙膏选用不同的品牌，因为牙膏中也含有杀菌的成分，如果总是使用同一种牙膏，口腔中的细菌就会适应这种牙膏，不利于除菌�\�</p><p style=\"TEXT-INDENT: 2em\"><strong>三、坚持就是胜�\�</strong></p><p style=\"TEXT-INDENT: 2em\">刚开始学刷牙的时候，小朋友们可能会没有耐心，胡乱划两下应付了事，这个时候爸爸妈妈可以在孩子刷完后指出并纠正他不正确的姿势和方法。坚持刷一天两天并非什么难事，而坚持下去就不是那么容易了。有的小儿玩累了或困了，不刷牙就上床睡觉，这时应晓之以理，说服小儿刷牙后再睡觉。父母还可以编一些故事给小儿听如小熊刷牙的故事等，使小儿明白刷牙的好处及不刷牙的危害，从而养成自觉自愿刷牙的习惯。健康的小儿应该有一副健康的牙齿�\�</p><p style=\"TEXT-INDENT: 2em\"><strong>四、养成正确刷牙方�\�</strong></p><p style=\"TEXT-INDENT: 2em\">训练孩子刷牙，从一开始就应该灌输给他正确的刷牙方法，而不应该纵容他拉锯式或者圈圈式的乱刷法。这种错误的刷牙方法不但不能把牙齿刷干净，还容易导致牙齿最薄弱的地方–牙颈部损伤，造成牙齿的楔状缺陷，把牙齿刷出一条沟来，以后使用稍硬的牙刷刷牙触及到牙髓就会疼痛�\�</p><p style=\"TEXT-INDENT: 2em\">正确的方式应该是顺着牙缝的方向，从上而下、一个也不能少地竖刷。无论是上下还是内外，都要顺着牙根往牙尖刷。牙齿咬合面可以横刷，这样清洁才彻底。每次刷牙至少需�\�3分钟时间，另外，冬天最好用温水刷牙，一些本身有牙病的人，使用冷水刷牙容易刺激到牙髓，引起疼痛。建议早晚刷牙，进食后都应该漱口�\�</p><p><a class=\"share2sina\" title=\"分享到新浪微�\�\" href=\"http://v.t.sina.com.cn/share/share.php?url=http://www.grow2up.cn/3126028.html&ralateUid=&appkey=&title=[%E6%91%98%E8%A6%81]%E4%BF%97%E8%AF%AD%E6%9C%89%E4%BA%91%EF%BC%8C%E4%B8%87%E4%BA%8B%E5%BC%80%E5%A4%B4%E9%9A%BE%EF%BC%8C%E5%AE%9D%E5%AE%9D%E5%AD%A6%E5%88%B7%E7%89%99%E4%B9%9F%E6%98%AF%E8%BF%99%E6%A0%B7%E4%B8%80%E4%B8%AA%E9%81%93%E7%90%86%E3%80%82%E6%95%99%E4%BC%9A%E4%BB%96%E4%BB%AC%E5%85%BB%E6%88%90%E4%B8%80%E4%B8%AA%E9%9C%80%E8%A6%81%E5%9D%9A%E6%8C%81%E4%B8%80%E7%94%9F%E7%9A%84%E5%A5%BD%E4%B9%A0%E6%83%AF%EF%BC%8C%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E5%8F%8D%E6%8E%8C%E4%B9%8B%E4%BA%8B%E3%80%82%E5%A6%82%E4%BD%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%EF%BC%9F%E6%88%91%E4%BB%AC%E4%B8%80%E8%B5%B7%E6%9D%A5%E7%9C%8B%E7%9C%8B%E5%90%A7%EF%BC%81%E5%8F%91%E8%82%B2%E6%AD%A3%E5%B8%B8%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E4%B8%80%E8%88%AC%E5%9C%A8%E4%B8%A4%E5%B2%81%E5%8D%8A%E5%B7%A6%E5%8F%B3%E9%95%BF%E5%87%BA%E6%89%80%E6%9C%89%E7%9A%84%E4%B9%B3%E7%89%99%E3%80%82%E5%9C%A8%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E5%B0%B1%E5%BA%94%E8%AF%A5%E8%AE%AD%E7%BB%83%E4%BB%96%E4%BB%AC%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E6%84%8F%E8%AF%86%EF%BC%8C%E4%BB%8E%E5%B0%8F%E5%85%BB%E6%88%90%E8%89%AF%E5%A5%BD%E7%9A%84%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E3%80%82%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E5%BF%BD%E8%A7%86%E7%89%99%E9%BD%BF%E5%81%A5%E5%BA%B7%EF%BC%8C%E6%80%BB%E6%83%B3%E7%9C%81%E4%BA%9B%E5%8A%9F%E5%A4%AB%EF%BC%8C%E7%AD%89%E5%AE%9D%E5%AE%9D%E4%BB%AC%E5%A4%A7%E4%BA%9B%E6%89%8D%E5%BC%80%E5%A7%8B%E5%88%B7%E7%89%99%EF%BC%8C%E8%80%8C%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E7%94%9A%E8%87%B3%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E4%BD%8F%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%E3%80%82%E5%B9%BF%E5%B7%9E%E5%B8%82%E7%BA%A2%E5%8D%81%E5%AD%97%E4%BC%9A%E5%8C%BB%E9%99%A2%E5%8F%A3%E8%85%94%E7%A7%91%E4%B8%BB%E4%BB%BB%E5%8F%B6%E5%BF%97%E4%BD%B3%E4%BB%8B%E7%BB%8D%EF%BC%8C%E6%9B%BE%E7%BB%8F%E6%9C%89%E4%B8%80%E4%B8%AA%E4%B8%89%E5%B2%81%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E6%BB%A1%E5%8F%A3%E7%89%99%E5%85%A8%E6%98%AF%E9%BB%91%E8%89%B2%E7%9A%84%EF%BC%8C%E7%89%99%E9%BD%BF%E5%9F%BA%E6%9C%AC%E9%83%BD%E7%83%82%E6%8E%89%E4%BA%86%EF%BC%8C%E5%8E%9F%E6%9D%A5%E6%82%A3%E5%84%BF%E7%9A%84%E5%A6%88%E5%A6%88%E4%BB%8E%E6%9D%A5%E9%83%BD%E6%98%AF%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E7%9D%80%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%EF%BC%8C%E5%BE%88%E5%B0%91%E6%B8%85%E6%B4%81%E5%8F%A3%E8%85%94%E3%80%82%E5%A6%82%E4%BD%95%E6%95%99%E5%AE%9D%E5%AE%9D%E5%88%B7%E7%89%99%EF%BC%9F%E4%B8%80%E3%80%81%E7%89%99%E9%BD%BF%E6%B8%85%E6%B4%81%E8%A6%81%E4%BB%8E%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%E5%BD%93%E5%B0%8F%E6%9C%8B%E5%8F%8B%E5%9C%A8%E5%8D%8A%E5%B2%81%E5%B7%A6%E5%8F%B3%E8%90%8C%E5%87%BA%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%EF%BC%8C%E7%88%B6%E6%AF%8D%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%BB%99%E5%B0%8F%E5%84%BF%E6%B8%85%E6%B4%81%E7%89%99%E9%BD%BF%E4%BA%86%E3%80%82%E5%AE%B6%E9%95%BF%E5%8F%AF%E4%BB%A5%E7%94%A8%E7%BA%B1%E5%B8%83%E3%80%81%E6%A3%89%E7%AD%BE%E8%98%B8%E6%B9%BF%E6%B8%A9%E6%B0%B4%E6%93%A6%E6%B4%97%E3%80%82%E8%80%8C%E7%AD%89%E5%AD%A9%E5%AD%90%E9%95%BF%E5%A4%A7%E4%B8%80%E4%BA%9B%EF%BC%8C%E5%B0%B1%E5%8F%AF%E4%BB%A5%E8%B7%9F%E5%AD%A9%E5%AD%90%E8%AF%B4%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E9%87%8D%E8%A6%81%E6%80%A7%EF%BC%8C%E6%AF%8F%E5%A4%A9%E8%AE%A9%E5%AD%A9%E5%AD%90%E7%9C%8B%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E8%80%8C%E5%88%B0%E5%AE%9D%E5%AE%9D2%E5%B2%81%E5%B7%A6%E5%8F%B3%EF%BC%8C%E5%8A%A8%E4%BD%9C%E6%AF%94%E8%BE%83%E7%81%B5%E6%B4%BB%E4%BA%86%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%AD%A6%E7%9D%80%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E6%9C%89%E4%BA%86%E5%88%B7%E7%89%99%E7%9A%84%E8%80%B3%E6%BF%A1%E7%9B%AE%E6%9F%93%EF%BC%8C%E5%B0%8F%E5%84%BF%E5%9F%BA%E6%9C%AC%E4%B8%8A%E9%80%82%E5%BA%94%E4%BA%86%E5%88%B7%E7%89%99%E3%80%82%E4%BD%86%E4%BB%8E%E5%88%AB%E4%BA%BA%E5%88%B7%E5%88%B0%E8%87%AA%E5%B7%B1%E5%AD%A6%E7%9D%80%E5%88%B7%E9%9C%80%E8%A6%81%E4%B8%80%E4%B8%AA%E8%BF%87%E7%A8%8B%E3%80%82%E4%BA%8C%E3%80%81%E5%87%86%E5%A4%87%E5%8F%AF%E7%88%B1%E6%B8%85%E6%96%B0%E7%9A%84%E5%88%B7%E7%89%99%E7%94%A8%E5%85%B7%E5%B0%8F%E6%9C%8B%E5%8F%8B%E9%83%BD%E6%98%AF%E8%B4%AA%E6%96%B0%E9%B2%9C%E7%9A%84%EF%BC%8C%E5%96%9C%E6%AC%A2%E8%8A%B1%E8%8A%B1%E7%BB%BF%E7%BB%BF%EF%BC%8C%E7%94%9C%E7%94%9C%E5%91%B3%E9%81%93%E7%9A%84%E4%B8%9C%E8%A5%BF%E3%80%82%E6%89%80%E4%BB%A5%E5%A6%82%E6%9E%9C%E8%A6%81%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E7%9A%84%E8%AF%9D%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%85%88%E8%AE%A9%E4%BB%96%E4%BB%AC%E7%88%B1%E4%B8%8A%E5%88%B7%E7%89%99%E3%80%82%E5%BA%94%E8%AF%A5%E8%A6%81%E5%A6%82%E4%BD%95%E6%8C%91%E9%80%89%E7%89%99%E5%88%B7%E5%92%8C%E7%89%99%E8%86%8F%E5%91%A2%EF%BC%9F%E5%8D%A1%E9%80%9A%E8%BD%AF%E6%AF%9B%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E5%88%B7%E5%B0%B1%E6%9C%80%E5%8F%97%E5%B0%8F%E6%9C%8B%E5%8F%8B%E6%AC%A2%E8%BF%8E%E4%BA%86%E3%80%82%E7%89%99%E5%88%B7%E4%BD%BF%E7%94%A83%E4%B8%AA%E6%9C%88%E5%90%8E%E5%B0%B1%E8%A6%81%E6%9B%B4%E6%8D%A2%E3%80%82%E8%80%8C%E7%89%99%E8%86%8F%E6%96%B9%E9%9D%A2%EF%BC%8C%E6%9C%80%E5%A5%BD%E9%80%89%E7%94%A8%E5%90%AB%E6%B0%B4%E6%9E%9C%E7%94%9C%E5%91%B3%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E8%86%8F%EF%BC%8C3%E5%B2%81%E4%BB%A5%E4%B8%8B%E7%9A%84%E5%B9%BC%E5%84%BF%E4%B8%8D%E5%AE%9C%E4%BD%BF%E7%94%A8%E5%90%AB%E6%B0%9F%E7%89%99%E8%86%8F%E3%80%82%E6%9C%80%E5%A5%BD%E6%97%A9%E6%99%9A%E7%89%99%E8%86%8F%E9%80%89%E7%94%A8%E4%B8%8D%E5%90%8C%E7%9A%84%E5%93%81%E7%89%8C%EF%BC%8C%E5%9B%A0%E4%B8%BA%E7%89%99%E8%86%8F%E4%B8%AD%E4%B9%9F%E5%90%AB%E6%9C%89%E6%9D%80%E8%8F%8C%E7%9A%84%E6%88%90%E5%88%86%EF%BC%8C%E5%A6%82%E6%9E%9C%E6%80%BB%E6%98%AF%E4%BD%BF%E7%94%A8%E5%90%8C%E4%B8%80%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E5%8F%A3%E8%85%94%E4%B8%AD%E7%9A%84%E7%BB%86%E8%8F%8C%E5%B0%B1%E4%BC%9A%E9%80%82%E5%BA%94%E8%BF%99%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E4%B8%8D%E5%88%A9%E4%BA%8E%E9%99%A4%E8%8F%8C%E3%80%82%20%E4%B8%89%E3%80%81%E5%9D%9A%E6%8C%81%E5%B0%B1%E6%98%AF%E8%83%9C%E5%88%A9%E5%88%9A%E5%BC%80%E5%A7%8B%E5%AD%A6%E5%88%B7%E7%89%99%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E5%B0%8F%E6%9C%8B%E5%8F%8B%E4%BB%AC%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%B2%A1%E6%9C%89%E8%80%90%E5%BF%83%EF%BC%8C%E8%83%A1%E4%B9%B1%E5%88%92%E4%B8%A4%E4%B8%8B%E5%BA%94%E4%BB%98%E4%BA%86%E4%BA%8B%EF%BC%8C%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E7%88%B8%E7%88%B8%E5%A6%88%E5%A6%88%E5%8F%AF%E4%BB%A5%E5%9C%A8%E5%AD%A9%E5%AD%90%E5%88%B7%E5%AE%8C%E5%90%8E%E6%8C%87%E5%87%BA%E5%B9%B6%E7%BA%A0%E6%AD%A3%E4%BB%96%E4%B8%8D%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%A7%BF%E5%8A%BF%E5%92%8C%E6%96%B9%E6%B3%95%E3%80%82%E5%9D%9A%E6%8C%81%E5%88%B7%E4%B8%80%E5%A4%A9%E4%B8%A4%E5%A4%A9%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E9%9A%BE%E4%BA%8B%EF%BC%8C%E8%80%8C%E5%9D%9A%E6%8C%81%E4%B8%8B%E5%8E%BB%E5%B0%B1%E4%B8%8D%E6%98%AF%E9%82%A3%E4%B9%88%E5%AE%B9%E6%98%93%E4%BA%86%E3%80%82%E6%9C%89%E7%9A%84%E5%B0%8F%E5%84%BF%E7%8E%A9%E7%B4%AF%E4%BA%86%E6%88%96%E5%9B%B0%E4%BA%86%EF%BC%8C%E4%B8%8D%E5%88%B7%E7%89%99%E5%B0%B1%E4%B8%8A%E5%BA%8A%E7%9D%A1%E8%A7%89%EF%BC%8C%E8%BF%99%E6%97%B6%E5%BA%94%E6%99%93%E4%B9%8B%E4%BB%A5%E7%90%86%EF%BC%8C%E8%AF%B4%E6%9C%8D%E5%B0%8F%E5%84%BF%E5%88%B7%E7%89%99%E5%90%8E%E5%86%8D%E7%9D%A1%E8%A7%89%E3%80%82%E7%88%B6%E6%AF%8D%E8%BF%98%E5%8F%AF%E4%BB%A5%E7%BC%96%E4%B8%80%E4%BA%9B%E6%95%85%E4%BA%8B%E7%BB%99%E5%B0%8F%E5%84%BF%E5%90%AC%E5%A6%82%E5%B0%8F%E7%86%8A%E5%88%B7%E7%89%99%E7%9A%84%E6%95%85%E4%BA%8B%E7%AD%89%EF%BC%8C%E4%BD%BF%E5%B0%8F%E5%84%BF%E6%98%8E%E7%99%BD%E5%88%B7%E7%89%99%E7%9A%84%E5%A5%BD%E5%A4%84%E5%8F%8A%E4%B8%8D%E5%88%B7%E7%89%99%E7%9A%84%E5%8D%B1%E5%AE%B3%EF%BC%8C%E4%BB%8E%E8%80%8C%E5%85%BB%E6%88%90%E8%87%AA%E8%A7%89%E8%87%AA%E6%84%BF%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%E3%80%82%E5%81%A5%E5%BA%B7%E7%9A%84%E5%B0%8F%E5%84%BF%E5%BA%94%E8%AF%A5%E6%9C%89%E4%B8%80%E5%89%AF%E5%81%A5%E5%BA%B7%E7%9A%84%E7%89%99%E9%BD%BF%E3%80%82%E5%9B%9B%E3%80%81%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%88%B7%E7%89%99%EF%BC%8C%E4%BB%8E%E4%B8%80%E5%BC%80%E5%A7%8B%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%81%8C%E8%BE%93%E7%BB%99%E4%BB%96%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%EF%BC%8C%E8%80%8C%E4%B8%8D%E5%BA%94%E8%AF%A5%E7%BA%B5%E5%AE%B9%E4%BB%96%E6%8B%89%E9%94%AF%E5%BC%8F%E6%88%96%E8%80%85%E5%9C%88%E5%9C%88%E5%BC%8F%E7%9A%84%E4%B9%B1%E5%88%B7%E6%B3%95%E3%80%82%E8%BF%99%E7%A7%8D%E9%94%99%E8%AF%AF%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E4%B8%8D%E4%BD%86%E4%B8%8D%E8%83%BD%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%B9%B2%E5%87%80%EF%BC%8C%E8%BF%98%E5%AE%B9%E6%98%93%E5%AF%BC%E8%87%B4%E7%89%99%E9%BD%BF%E6%9C%80%E8%96%84%E5%BC%B1%E7%9A%84%E5%9C%B0%E6%96%B9%E2%80%93%E7%89%99%E9%A2%88%E9%83%A8%E6%8D%9F%E4%BC%A4%EF%BC%8C%E9%80%A0%E6%88%90%E7%89%99%E9%BD%BF%E7%9A%84%E6%A5%94%E7%8A%B6%E7%BC%BA%E9%99%B7%EF%BC%8C%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%87%BA%E4%B8%80%E6%9D%A1%E6%B2%9F%E6%9D%A5%EF%BC%8C%E4%BB%A5%E5%90%8E%E4%BD%BF%E7%94%A8%E7%A8%8D%E7%A1%AC%E7%9A%84%E7%89%99%E5%88%B7%E5%88%B7%E7%89%99%E8%A7%A6%E5%8F%8A%E5%88%B0%E7%89%99%E9%AB%93%E5%B0%B1%E4%BC%9A%E7%96%BC%E7%97%9B%E3%80%82%E6%AD%A3%E7%A1%AE%E7%9A%84%E6%96%B9%E5%BC%8F%E5%BA%94%E8%AF%A5%E6%98%AF%E9%A1%BA%E7%9D%80%E7%89%99%E7%BC%9D%E7%9A%84%E6%96%B9%E5%90%91%EF%BC%8C%E4%BB%8E%E4%B8%8A%E8%80%8C%E4%B8%8B%E3%80%81%E4%B8%80%E4%B8%AA%E4%B9%9F%E4%B8%8D%E8%83%BD%E5%B0%91%E5%9C%B0%E7%AB%96%E5%88%B7%E3%80%82%E6%97%A0%E8%AE%BA%E6%98%AF%E4%B8%8A%E4%B8%8B%E8%BF%98%E6%98%AF%E5%86%85%E5%A4%96%EF%BC%8C%E9%83%BD%E8%A6%81%E9%A1%BA%E7%9D%80%E7%89%99%E6%A0%B9%E5%BE%80%E7%89%99%E5%B0%96%E5%88%B7%E3%80%82%E7%89%99%E9%BD%BF%E5%92%AC%E5%90%88%E9%9D%A2%E5%8F%AF%E4%BB%A5%E6%A8%AA%E5%88%B7%EF%BC%8C%E8%BF%99%E6%A0%B7%E6%B8%85%E6%B4%81%E6%89%8D%E5%BD%BB%E5%BA%95%E3%80%82%E6%AF%8F%E6%AC%A1%E5%88%B7%E7%89%99%E8%87%B3%E5%B0%91%E9%9C%80%E8%A6%813%E5%88%86%E9%92%9F%E6%97%B6%E9%97%B4%EF%BC%8C%E5%8F%A6%E5%A4%96%EF%BC%8C%E5%86%AC%E5%A4%A9%E6%9C%80%E5%A5%BD%E7%94%A8%E6%B8%A9%E6%B0%B4%E5%88%B7%E7%89%99%EF%BC%8C%E4%B8%80%E4%BA%9B%E6%9C%AC%E8%BA%AB%E6%9C%89%E7%89%99%E7%97%85%E7%9A%84%E4%BA%BA%EF%BC%8C%E4%BD%BF%E7%94%A8%E5%86%B7%E6%B0%B4%E5%88%B7%E7%89%99%E5%AE%B9%E6%98%93%E5%88%BA%E6%BF%80%E5%88%B0%E7%89%99%E9%AB%93%EF%BC%8C%E5%BC%95%E8%B5%B7%E7%96%BC%E7%97%9B%E3%80%82%E5%BB%BA%E8%AE%AE%E6%97%A9%E6%99%9A%E5%88%B7%E7%89%99%EF%BC%8C%E8%BF%9B%E9%A3%9F%E5%90%8E%E9%83%BD%E5%BA%94%E8%AF%A5%E6%BC%B1%E5%8F%A3%E3%80%82%200\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2t\" title=\"分享到腾讯微�\�\" href=\"http://v.t.qq.com/share/share.php?url=http://www.grow2up.cn/3126028.html&title=[%E6%91%98%E8%A6%81]%E4%BF%97%E8%AF%AD%E6%9C%89%E4%BA%91%EF%BC%8C%E4%B8%87%E4%BA%8B%E5%BC%80%E5%A4%B4%E9%9A%BE%EF%BC%8C%E5%AE%9D%E5%AE%9D%E5%AD%A6%E5%88%B7%E7%89%99%E4%B9%9F%E6%98%AF%E8%BF%99%E6%A0%B7%E4%B8%80%E4%B8%AA%E9%81%93%E7%90%86%E3%80%82%E6%95%99%E4%BC%9A%E4%BB%96%E4%BB%AC%E5%85%BB%E6%88%90%E4%B8%80%E4%B8%AA%E9%9C%80%E8%A6%81%E5%9D%9A%E6%8C%81%E4%B8%80%E7%94%9F%E7%9A%84%E5%A5%BD%E4%B9%A0%E6%83%AF%EF%BC%8C%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E5%8F%8D%E6%8E%8C%E4%B9%8B%E4%BA%8B%E3%80%82%E5%A6%82%E4%BD%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%EF%BC%9F%E6%88%91%E4%BB%AC%E4%B8%80%E8%B5%B7%E6%9D%A5%E7%9C%8B%E7%9C%8B%E5%90%A7%EF%BC%81%E5%8F%91%E8%82%B2%E6%AD%A3%E5%B8%B8%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E4%B8%80%E8%88%AC%E5%9C%A8%E4%B8%A4%E5%B2%81%E5%8D%8A%E5%B7%A6%E5%8F%B3%E9%95%BF%E5%87%BA%E6%89%80%E6%9C%89%E7%9A%84%E4%B9%B3%E7%89%99%E3%80%82%E5%9C%A8%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E5%B0%B1%E5%BA%94%E8%AF%A5%E8%AE%AD%E7%BB%83%E4%BB%96%E4%BB%AC%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E6%84%8F%E8%AF%86%EF%BC%8C%E4%BB%8E%E5%B0%8F%E5%85%BB%E6%88%90%E8%89%AF%E5%A5%BD%E7%9A%84%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E3%80%82%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E5%BF%BD%E8%A7%86%E7%89%99%E9%BD%BF%E5%81%A5%E5%BA%B7%EF%BC%8C%E6%80%BB%E6%83%B3%E7%9C%81%E4%BA%9B%E5%8A%9F%E5%A4%AB%EF%BC%8C%E7%AD%89%E5%AE%9D%E5%AE%9D%E4%BB%AC%E5%A4%A7%E4%BA%9B%E6%89%8D%E5%BC%80%E5%A7%8B%E5%88%B7%E7%89%99%EF%BC%8C%E8%80%8C%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E7%94%9A%E8%87%B3%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E4%BD%8F%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%E3%80%82%E5%B9%BF%E5%B7%9E%E5%B8%82%E7%BA%A2%E5%8D%81%E5%AD%97%E4%BC%9A%E5%8C%BB%E9%99%A2%E5%8F%A3%E8%85%94%E7%A7%91%E4%B8%BB%E4%BB%BB%E5%8F%B6%E5%BF%97%E4%BD%B3%E4%BB%8B%E7%BB%8D%EF%BC%8C%E6%9B%BE%E7%BB%8F%E6%9C%89%E4%B8%80%E4%B8%AA%E4%B8%89%E5%B2%81%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E6%BB%A1%E5%8F%A3%E7%89%99%E5%85%A8%E6%98%AF%E9%BB%91%E8%89%B2%E7%9A%84%EF%BC%8C%E7%89%99%E9%BD%BF%E5%9F%BA%E6%9C%AC%E9%83%BD%E7%83%82%E6%8E%89%E4%BA%86%EF%BC%8C%E5%8E%9F%E6%9D%A5%E6%82%A3%E5%84%BF%E7%9A%84%E5%A6%88%E5%A6%88%E4%BB%8E%E6%9D%A5%E9%83%BD%E6%98%AF%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E7%9D%80%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%EF%BC%8C%E5%BE%88%E5%B0%91%E6%B8%85%E6%B4%81%E5%8F%A3%E8%85%94%E3%80%82%E5%A6%82%E4%BD%95%E6%95%99%E5%AE%9D%E5%AE%9D%E5%88%B7%E7%89%99%EF%BC%9F%E4%B8%80%E3%80%81%E7%89%99%E9%BD%BF%E6%B8%85%E6%B4%81%E8%A6%81%E4%BB%8E%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%E5%BD%93%E5%B0%8F%E6%9C%8B%E5%8F%8B%E5%9C%A8%E5%8D%8A%E5%B2%81%E5%B7%A6%E5%8F%B3%E8%90%8C%E5%87%BA%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%EF%BC%8C%E7%88%B6%E6%AF%8D%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%BB%99%E5%B0%8F%E5%84%BF%E6%B8%85%E6%B4%81%E7%89%99%E9%BD%BF%E4%BA%86%E3%80%82%E5%AE%B6%E9%95%BF%E5%8F%AF%E4%BB%A5%E7%94%A8%E7%BA%B1%E5%B8%83%E3%80%81%E6%A3%89%E7%AD%BE%E8%98%B8%E6%B9%BF%E6%B8%A9%E6%B0%B4%E6%93%A6%E6%B4%97%E3%80%82%E8%80%8C%E7%AD%89%E5%AD%A9%E5%AD%90%E9%95%BF%E5%A4%A7%E4%B8%80%E4%BA%9B%EF%BC%8C%E5%B0%B1%E5%8F%AF%E4%BB%A5%E8%B7%9F%E5%AD%A9%E5%AD%90%E8%AF%B4%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E9%87%8D%E8%A6%81%E6%80%A7%EF%BC%8C%E6%AF%8F%E5%A4%A9%E8%AE%A9%E5%AD%A9%E5%AD%90%E7%9C%8B%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E8%80%8C%E5%88%B0%E5%AE%9D%E5%AE%9D2%E5%B2%81%E5%B7%A6%E5%8F%B3%EF%BC%8C%E5%8A%A8%E4%BD%9C%E6%AF%94%E8%BE%83%E7%81%B5%E6%B4%BB%E4%BA%86%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%AD%A6%E7%9D%80%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E6%9C%89%E4%BA%86%E5%88%B7%E7%89%99%E7%9A%84%E8%80%B3%E6%BF%A1%E7%9B%AE%E6%9F%93%EF%BC%8C%E5%B0%8F%E5%84%BF%E5%9F%BA%E6%9C%AC%E4%B8%8A%E9%80%82%E5%BA%94%E4%BA%86%E5%88%B7%E7%89%99%E3%80%82%E4%BD%86%E4%BB%8E%E5%88%AB%E4%BA%BA%E5%88%B7%E5%88%B0%E8%87%AA%E5%B7%B1%E5%AD%A6%E7%9D%80%E5%88%B7%E9%9C%80%E8%A6%81%E4%B8%80%E4%B8%AA%E8%BF%87%E7%A8%8B%E3%80%82%E4%BA%8C%E3%80%81%E5%87%86%E5%A4%87%E5%8F%AF%E7%88%B1%E6%B8%85%E6%96%B0%E7%9A%84%E5%88%B7%E7%89%99%E7%94%A8%E5%85%B7%E5%B0%8F%E6%9C%8B%E5%8F%8B%E9%83%BD%E6%98%AF%E8%B4%AA%E6%96%B0%E9%B2%9C%E7%9A%84%EF%BC%8C%E5%96%9C%E6%AC%A2%E8%8A%B1%E8%8A%B1%E7%BB%BF%E7%BB%BF%EF%BC%8C%E7%94%9C%E7%94%9C%E5%91%B3%E9%81%93%E7%9A%84%E4%B8%9C%E8%A5%BF%E3%80%82%E6%89%80%E4%BB%A5%E5%A6%82%E6%9E%9C%E8%A6%81%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E7%9A%84%E8%AF%9D%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%85%88%E8%AE%A9%E4%BB%96%E4%BB%AC%E7%88%B1%E4%B8%8A%E5%88%B7%E7%89%99%E3%80%82%E5%BA%94%E8%AF%A5%E8%A6%81%E5%A6%82%E4%BD%95%E6%8C%91%E9%80%89%E7%89%99%E5%88%B7%E5%92%8C%E7%89%99%E8%86%8F%E5%91%A2%EF%BC%9F%E5%8D%A1%E9%80%9A%E8%BD%AF%E6%AF%9B%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E5%88%B7%E5%B0%B1%E6%9C%80%E5%8F%97%E5%B0%8F%E6%9C%8B%E5%8F%8B%E6%AC%A2%E8%BF%8E%E4%BA%86%E3%80%82%E7%89%99%E5%88%B7%E4%BD%BF%E7%94%A83%E4%B8%AA%E6%9C%88%E5%90%8E%E5%B0%B1%E8%A6%81%E6%9B%B4%E6%8D%A2%E3%80%82%E8%80%8C%E7%89%99%E8%86%8F%E6%96%B9%E9%9D%A2%EF%BC%8C%E6%9C%80%E5%A5%BD%E9%80%89%E7%94%A8%E5%90%AB%E6%B0%B4%E6%9E%9C%E7%94%9C%E5%91%B3%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E8%86%8F%EF%BC%8C3%E5%B2%81%E4%BB%A5%E4%B8%8B%E7%9A%84%E5%B9%BC%E5%84%BF%E4%B8%8D%E5%AE%9C%E4%BD%BF%E7%94%A8%E5%90%AB%E6%B0%9F%E7%89%99%E8%86%8F%E3%80%82%E6%9C%80%E5%A5%BD%E6%97%A9%E6%99%9A%E7%89%99%E8%86%8F%E9%80%89%E7%94%A8%E4%B8%8D%E5%90%8C%E7%9A%84%E5%93%81%E7%89%8C%EF%BC%8C%E5%9B%A0%E4%B8%BA%E7%89%99%E8%86%8F%E4%B8%AD%E4%B9%9F%E5%90%AB%E6%9C%89%E6%9D%80%E8%8F%8C%E7%9A%84%E6%88%90%E5%88%86%EF%BC%8C%E5%A6%82%E6%9E%9C%E6%80%BB%E6%98%AF%E4%BD%BF%E7%94%A8%E5%90%8C%E4%B8%80%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E5%8F%A3%E8%85%94%E4%B8%AD%E7%9A%84%E7%BB%86%E8%8F%8C%E5%B0%B1%E4%BC%9A%E9%80%82%E5%BA%94%E8%BF%99%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E4%B8%8D%E5%88%A9%E4%BA%8E%E9%99%A4%E8%8F%8C%E3%80%82%20%E4%B8%89%E3%80%81%E5%9D%9A%E6%8C%81%E5%B0%B1%E6%98%AF%E8%83%9C%E5%88%A9%E5%88%9A%E5%BC%80%E5%A7%8B%E5%AD%A6%E5%88%B7%E7%89%99%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E5%B0%8F%E6%9C%8B%E5%8F%8B%E4%BB%AC%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%B2%A1%E6%9C%89%E8%80%90%E5%BF%83%EF%BC%8C%E8%83%A1%E4%B9%B1%E5%88%92%E4%B8%A4%E4%B8%8B%E5%BA%94%E4%BB%98%E4%BA%86%E4%BA%8B%EF%BC%8C%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E7%88%B8%E7%88%B8%E5%A6%88%E5%A6%88%E5%8F%AF%E4%BB%A5%E5%9C%A8%E5%AD%A9%E5%AD%90%E5%88%B7%E5%AE%8C%E5%90%8E%E6%8C%87%E5%87%BA%E5%B9%B6%E7%BA%A0%E6%AD%A3%E4%BB%96%E4%B8%8D%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%A7%BF%E5%8A%BF%E5%92%8C%E6%96%B9%E6%B3%95%E3%80%82%E5%9D%9A%E6%8C%81%E5%88%B7%E4%B8%80%E5%A4%A9%E4%B8%A4%E5%A4%A9%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E9%9A%BE%E4%BA%8B%EF%BC%8C%E8%80%8C%E5%9D%9A%E6%8C%81%E4%B8%8B%E5%8E%BB%E5%B0%B1%E4%B8%8D%E6%98%AF%E9%82%A3%E4%B9%88%E5%AE%B9%E6%98%93%E4%BA%86%E3%80%82%E6%9C%89%E7%9A%84%E5%B0%8F%E5%84%BF%E7%8E%A9%E7%B4%AF%E4%BA%86%E6%88%96%E5%9B%B0%E4%BA%86%EF%BC%8C%E4%B8%8D%E5%88%B7%E7%89%99%E5%B0%B1%E4%B8%8A%E5%BA%8A%E7%9D%A1%E8%A7%89%EF%BC%8C%E8%BF%99%E6%97%B6%E5%BA%94%E6%99%93%E4%B9%8B%E4%BB%A5%E7%90%86%EF%BC%8C%E8%AF%B4%E6%9C%8D%E5%B0%8F%E5%84%BF%E5%88%B7%E7%89%99%E5%90%8E%E5%86%8D%E7%9D%A1%E8%A7%89%E3%80%82%E7%88%B6%E6%AF%8D%E8%BF%98%E5%8F%AF%E4%BB%A5%E7%BC%96%E4%B8%80%E4%BA%9B%E6%95%85%E4%BA%8B%E7%BB%99%E5%B0%8F%E5%84%BF%E5%90%AC%E5%A6%82%E5%B0%8F%E7%86%8A%E5%88%B7%E7%89%99%E7%9A%84%E6%95%85%E4%BA%8B%E7%AD%89%EF%BC%8C%E4%BD%BF%E5%B0%8F%E5%84%BF%E6%98%8E%E7%99%BD%E5%88%B7%E7%89%99%E7%9A%84%E5%A5%BD%E5%A4%84%E5%8F%8A%E4%B8%8D%E5%88%B7%E7%89%99%E7%9A%84%E5%8D%B1%E5%AE%B3%EF%BC%8C%E4%BB%8E%E8%80%8C%E5%85%BB%E6%88%90%E8%87%AA%E8%A7%89%E8%87%AA%E6%84%BF%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%E3%80%82%E5%81%A5%E5%BA%B7%E7%9A%84%E5%B0%8F%E5%84%BF%E5%BA%94%E8%AF%A5%E6%9C%89%E4%B8%80%E5%89%AF%E5%81%A5%E5%BA%B7%E7%9A%84%E7%89%99%E9%BD%BF%E3%80%82%E5%9B%9B%E3%80%81%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%88%B7%E7%89%99%EF%BC%8C%E4%BB%8E%E4%B8%80%E5%BC%80%E5%A7%8B%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%81%8C%E8%BE%93%E7%BB%99%E4%BB%96%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%EF%BC%8C%E8%80%8C%E4%B8%8D%E5%BA%94%E8%AF%A5%E7%BA%B5%E5%AE%B9%E4%BB%96%E6%8B%89%E9%94%AF%E5%BC%8F%E6%88%96%E8%80%85%E5%9C%88%E5%9C%88%E5%BC%8F%E7%9A%84%E4%B9%B1%E5%88%B7%E6%B3%95%E3%80%82%E8%BF%99%E7%A7%8D%E9%94%99%E8%AF%AF%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E4%B8%8D%E4%BD%86%E4%B8%8D%E8%83%BD%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%B9%B2%E5%87%80%EF%BC%8C%E8%BF%98%E5%AE%B9%E6%98%93%E5%AF%BC%E8%87%B4%E7%89%99%E9%BD%BF%E6%9C%80%E8%96%84%E5%BC%B1%E7%9A%84%E5%9C%B0%E6%96%B9%E2%80%93%E7%89%99%E9%A2%88%E9%83%A8%E6%8D%9F%E4%BC%A4%EF%BC%8C%E9%80%A0%E6%88%90%E7%89%99%E9%BD%BF%E7%9A%84%E6%A5%94%E7%8A%B6%E7%BC%BA%E9%99%B7%EF%BC%8C%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%87%BA%E4%B8%80%E6%9D%A1%E6%B2%9F%E6%9D%A5%EF%BC%8C%E4%BB%A5%E5%90%8E%E4%BD%BF%E7%94%A8%E7%A8%8D%E7%A1%AC%E7%9A%84%E7%89%99%E5%88%B7%E5%88%B7%E7%89%99%E8%A7%A6%E5%8F%8A%E5%88%B0%E7%89%99%E9%AB%93%E5%B0%B1%E4%BC%9A%E7%96%BC%E7%97%9B%E3%80%82%E6%AD%A3%E7%A1%AE%E7%9A%84%E6%96%B9%E5%BC%8F%E5%BA%94%E8%AF%A5%E6%98%AF%E9%A1%BA%E7%9D%80%E7%89%99%E7%BC%9D%E7%9A%84%E6%96%B9%E5%90%91%EF%BC%8C%E4%BB%8E%E4%B8%8A%E8%80%8C%E4%B8%8B%E3%80%81%E4%B8%80%E4%B8%AA%E4%B9%9F%E4%B8%8D%E8%83%BD%E5%B0%91%E5%9C%B0%E7%AB%96%E5%88%B7%E3%80%82%E6%97%A0%E8%AE%BA%E6%98%AF%E4%B8%8A%E4%B8%8B%E8%BF%98%E6%98%AF%E5%86%85%E5%A4%96%EF%BC%8C%E9%83%BD%E8%A6%81%E9%A1%BA%E7%9D%80%E7%89%99%E6%A0%B9%E5%BE%80%E7%89%99%E5%B0%96%E5%88%B7%E3%80%82%E7%89%99%E9%BD%BF%E5%92%AC%E5%90%88%E9%9D%A2%E5%8F%AF%E4%BB%A5%E6%A8%AA%E5%88%B7%EF%BC%8C%E8%BF%99%E6%A0%B7%E6%B8%85%E6%B4%81%E6%89%8D%E5%BD%BB%E5%BA%95%E3%80%82%E6%AF%8F%E6%AC%A1%E5%88%B7%E7%89%99%E8%87%B3%E5%B0%91%E9%9C%80%E8%A6%813%E5%88%86%E9%92%9F%E6%97%B6%E9%97%B4%EF%BC%8C%E5%8F%A6%E5%A4%96%EF%BC%8C%E5%86%AC%E5%A4%A9%E6%9C%80%E5%A5%BD%E7%94%A8%E6%B8%A9%E6%B0%B4%E5%88%B7%E7%89%99%EF%BC%8C%E4%B8%80%E4%BA%9B%E6%9C%AC%E8%BA%AB%E6%9C%89%E7%89%99%E7%97%85%E7%9A%84%E4%BA%BA%EF%BC%8C%E4%BD%BF%E7%94%A8%E5%86%B7%E6%B0%B4%E5%88%B7%E7%89%99%E5%AE%B9%E6%98%93%E5%88%BA%E6%BF%80%E5%88%B0%E7%89%99%E9%AB%93%EF%BC%8C%E5%BC%95%E8%B5%B7%E7%96%BC%E7%97%9B%E3%80%82%E5%BB%BA%E8%AE%AE%E6%97%A9%E6%99%9A%E5%88%B7%E7%89%99%EF%BC%8C%E8%BF%9B%E9%A3%9F%E5%90%8E%E9%83%BD%E5%BA%94%E8%AF%A5%E6%BC%B1%E5%8F%A3%E3%80%82%200\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2qzone\" title=\"分享到QQ空间\" href=\"http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http://www.grow2up.cn/3126028.html&title=[%E6%91%98%E8%A6%81]%E4%BF%97%E8%AF%AD%E6%9C%89%E4%BA%91%EF%BC%8C%E4%B8%87%E4%BA%8B%E5%BC%80%E5%A4%B4%E9%9A%BE%EF%BC%8C%E5%AE%9D%E5%AE%9D%E5%AD%A6%E5%88%B7%E7%89%99%E4%B9%9F%E6%98%AF%E8%BF%99%E6%A0%B7%E4%B8%80%E4%B8%AA%E9%81%93%E7%90%86%E3%80%82%E6%95%99%E4%BC%9A%E4%BB%96%E4%BB%AC%E5%85%BB%E6%88%90%E4%B8%80%E4%B8%AA%E9%9C%80%E8%A6%81%E5%9D%9A%E6%8C%81%E4%B8%80%E7%94%9F%E7%9A%84%E5%A5%BD%E4%B9%A0%E6%83%AF%EF%BC%8C%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E5%8F%8D%E6%8E%8C%E4%B9%8B%E4%BA%8B%E3%80%82%E5%A6%82%E4%BD%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%EF%BC%9F%E6%88%91%E4%BB%AC%E4%B8%80%E8%B5%B7%E6%9D%A5%E7%9C%8B%E7%9C%8B%E5%90%A7%EF%BC%81%E5%8F%91%E8%82%B2%E6%AD%A3%E5%B8%B8%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E4%B8%80%E8%88%AC%E5%9C%A8%E4%B8%A4%E5%B2%81%E5%8D%8A%E5%B7%A6%E5%8F%B3%E9%95%BF%E5%87%BA%E6%89%80%E6%9C%89%E7%9A%84%E4%B9%B3%E7%89%99%E3%80%82%E5%9C%A8%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E5%B0%B1%E5%BA%94%E8%AF%A5%E8%AE%AD%E7%BB%83%E4%BB%96%E4%BB%AC%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E6%84%8F%E8%AF%86%EF%BC%8C%E4%BB%8E%E5%B0%8F%E5%85%BB%E6%88%90%E8%89%AF%E5%A5%BD%E7%9A%84%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E3%80%82%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E5%BF%BD%E8%A7%86%E7%89%99%E9%BD%BF%E5%81%A5%E5%BA%B7%EF%BC%8C%E6%80%BB%E6%83%B3%E7%9C%81%E4%BA%9B%E5%8A%9F%E5%A4%AB%EF%BC%8C%E7%AD%89%E5%AE%9D%E5%AE%9D%E4%BB%AC%E5%A4%A7%E4%BA%9B%E6%89%8D%E5%BC%80%E5%A7%8B%E5%88%B7%E7%89%99%EF%BC%8C%E8%80%8C%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E7%94%9A%E8%87%B3%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E4%BD%8F%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%E3%80%82%E5%B9%BF%E5%B7%9E%E5%B8%82%E7%BA%A2%E5%8D%81%E5%AD%97%E4%BC%9A%E5%8C%BB%E9%99%A2%E5%8F%A3%E8%85%94%E7%A7%91%E4%B8%BB%E4%BB%BB%E5%8F%B6%E5%BF%97%E4%BD%B3%E4%BB%8B%E7%BB%8D%EF%BC%8C%E6%9B%BE%E7%BB%8F%E6%9C%89%E4%B8%80%E4%B8%AA%E4%B8%89%E5%B2%81%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E6%BB%A1%E5%8F%A3%E7%89%99%E5%85%A8%E6%98%AF%E9%BB%91%E8%89%B2%E7%9A%84%EF%BC%8C%E7%89%99%E9%BD%BF%E5%9F%BA%E6%9C%AC%E9%83%BD%E7%83%82%E6%8E%89%E4%BA%86%EF%BC%8C%E5%8E%9F%E6%9D%A5%E6%82%A3%E5%84%BF%E7%9A%84%E5%A6%88%E5%A6%88%E4%BB%8E%E6%9D%A5%E9%83%BD%E6%98%AF%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E7%9D%80%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%EF%BC%8C%E5%BE%88%E5%B0%91%E6%B8%85%E6%B4%81%E5%8F%A3%E8%85%94%E3%80%82%E5%A6%82%E4%BD%95%E6%95%99%E5%AE%9D%E5%AE%9D%E5%88%B7%E7%89%99%EF%BC%9F%E4%B8%80%E3%80%81%E7%89%99%E9%BD%BF%E6%B8%85%E6%B4%81%E8%A6%81%E4%BB%8E%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%E5%BD%93%E5%B0%8F%E6%9C%8B%E5%8F%8B%E5%9C%A8%E5%8D%8A%E5%B2%81%E5%B7%A6%E5%8F%B3%E8%90%8C%E5%87%BA%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%EF%BC%8C%E7%88%B6%E6%AF%8D%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%BB%99%E5%B0%8F%E5%84%BF%E6%B8%85%E6%B4%81%E7%89%99%E9%BD%BF%E4%BA%86%E3%80%82%E5%AE%B6%E9%95%BF%E5%8F%AF%E4%BB%A5%E7%94%A8%E7%BA%B1%E5%B8%83%E3%80%81%E6%A3%89%E7%AD%BE%E8%98%B8%E6%B9%BF%E6%B8%A9%E6%B0%B4%E6%93%A6%E6%B4%97%E3%80%82%E8%80%8C%E7%AD%89%E5%AD%A9%E5%AD%90%E9%95%BF%E5%A4%A7%E4%B8%80%E4%BA%9B%EF%BC%8C%E5%B0%B1%E5%8F%AF%E4%BB%A5%E8%B7%9F%E5%AD%A9%E5%AD%90%E8%AF%B4%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E9%87%8D%E8%A6%81%E6%80%A7%EF%BC%8C%E6%AF%8F%E5%A4%A9%E8%AE%A9%E5%AD%A9%E5%AD%90%E7%9C%8B%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E8%80%8C%E5%88%B0%E5%AE%9D%E5%AE%9D2%E5%B2%81%E5%B7%A6%E5%8F%B3%EF%BC%8C%E5%8A%A8%E4%BD%9C%E6%AF%94%E8%BE%83%E7%81%B5%E6%B4%BB%E4%BA%86%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%AD%A6%E7%9D%80%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E6%9C%89%E4%BA%86%E5%88%B7%E7%89%99%E7%9A%84%E8%80%B3%E6%BF%A1%E7%9B%AE%E6%9F%93%EF%BC%8C%E5%B0%8F%E5%84%BF%E5%9F%BA%E6%9C%AC%E4%B8%8A%E9%80%82%E5%BA%94%E4%BA%86%E5%88%B7%E7%89%99%E3%80%82%E4%BD%86%E4%BB%8E%E5%88%AB%E4%BA%BA%E5%88%B7%E5%88%B0%E8%87%AA%E5%B7%B1%E5%AD%A6%E7%9D%80%E5%88%B7%E9%9C%80%E8%A6%81%E4%B8%80%E4%B8%AA%E8%BF%87%E7%A8%8B%E3%80%82%E4%BA%8C%E3%80%81%E5%87%86%E5%A4%87%E5%8F%AF%E7%88%B1%E6%B8%85%E6%96%B0%E7%9A%84%E5%88%B7%E7%89%99%E7%94%A8%E5%85%B7%E5%B0%8F%E6%9C%8B%E5%8F%8B%E9%83%BD%E6%98%AF%E8%B4%AA%E6%96%B0%E9%B2%9C%E7%9A%84%EF%BC%8C%E5%96%9C%E6%AC%A2%E8%8A%B1%E8%8A%B1%E7%BB%BF%E7%BB%BF%EF%BC%8C%E7%94%9C%E7%94%9C%E5%91%B3%E9%81%93%E7%9A%84%E4%B8%9C%E8%A5%BF%E3%80%82%E6%89%80%E4%BB%A5%E5%A6%82%E6%9E%9C%E8%A6%81%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E7%9A%84%E8%AF%9D%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%85%88%E8%AE%A9%E4%BB%96%E4%BB%AC%E7%88%B1%E4%B8%8A%E5%88%B7%E7%89%99%E3%80%82%E5%BA%94%E8%AF%A5%E8%A6%81%E5%A6%82%E4%BD%95%E6%8C%91%E9%80%89%E7%89%99%E5%88%B7%E5%92%8C%E7%89%99%E8%86%8F%E5%91%A2%EF%BC%9F%E5%8D%A1%E9%80%9A%E8%BD%AF%E6%AF%9B%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E5%88%B7%E5%B0%B1%E6%9C%80%E5%8F%97%E5%B0%8F%E6%9C%8B%E5%8F%8B%E6%AC%A2%E8%BF%8E%E4%BA%86%E3%80%82%E7%89%99%E5%88%B7%E4%BD%BF%E7%94%A83%E4%B8%AA%E6%9C%88%E5%90%8E%E5%B0%B1%E8%A6%81%E6%9B%B4%E6%8D%A2%E3%80%82%E8%80%8C%E7%89%99%E8%86%8F%E6%96%B9%E9%9D%A2%EF%BC%8C%E6%9C%80%E5%A5%BD%E9%80%89%E7%94%A8%E5%90%AB%E6%B0%B4%E6%9E%9C%E7%94%9C%E5%91%B3%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E8%86%8F%EF%BC%8C3%E5%B2%81%E4%BB%A5%E4%B8%8B%E7%9A%84%E5%B9%BC%E5%84%BF%E4%B8%8D%E5%AE%9C%E4%BD%BF%E7%94%A8%E5%90%AB%E6%B0%9F%E7%89%99%E8%86%8F%E3%80%82%E6%9C%80%E5%A5%BD%E6%97%A9%E6%99%9A%E7%89%99%E8%86%8F%E9%80%89%E7%94%A8%E4%B8%8D%E5%90%8C%E7%9A%84%E5%93%81%E7%89%8C%EF%BC%8C%E5%9B%A0%E4%B8%BA%E7%89%99%E8%86%8F%E4%B8%AD%E4%B9%9F%E5%90%AB%E6%9C%89%E6%9D%80%E8%8F%8C%E7%9A%84%E6%88%90%E5%88%86%EF%BC%8C%E5%A6%82%E6%9E%9C%E6%80%BB%E6%98%AF%E4%BD%BF%E7%94%A8%E5%90%8C%E4%B8%80%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E5%8F%A3%E8%85%94%E4%B8%AD%E7%9A%84%E7%BB%86%E8%8F%8C%E5%B0%B1%E4%BC%9A%E9%80%82%E5%BA%94%E8%BF%99%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E4%B8%8D%E5%88%A9%E4%BA%8E%E9%99%A4%E8%8F%8C%E3%80%82%20%E4%B8%89%E3%80%81%E5%9D%9A%E6%8C%81%E5%B0%B1%E6%98%AF%E8%83%9C%E5%88%A9%E5%88%9A%E5%BC%80%E5%A7%8B%E5%AD%A6%E5%88%B7%E7%89%99%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E5%B0%8F%E6%9C%8B%E5%8F%8B%E4%BB%AC%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%B2%A1%E6%9C%89%E8%80%90%E5%BF%83%EF%BC%8C%E8%83%A1%E4%B9%B1%E5%88%92%E4%B8%A4%E4%B8%8B%E5%BA%94%E4%BB%98%E4%BA%86%E4%BA%8B%EF%BC%8C%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E7%88%B8%E7%88%B8%E5%A6%88%E5%A6%88%E5%8F%AF%E4%BB%A5%E5%9C%A8%E5%AD%A9%E5%AD%90%E5%88%B7%E5%AE%8C%E5%90%8E%E6%8C%87%E5%87%BA%E5%B9%B6%E7%BA%A0%E6%AD%A3%E4%BB%96%E4%B8%8D%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%A7%BF%E5%8A%BF%E5%92%8C%E6%96%B9%E6%B3%95%E3%80%82%E5%9D%9A%E6%8C%81%E5%88%B7%E4%B8%80%E5%A4%A9%E4%B8%A4%E5%A4%A9%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E9%9A%BE%E4%BA%8B%EF%BC%8C%E8%80%8C%E5%9D%9A%E6%8C%81%E4%B8%8B%E5%8E%BB%E5%B0%B1%E4%B8%8D%E6%98%AF%E9%82%A3%E4%B9%88%E5%AE%B9%E6%98%93%E4%BA%86%E3%80%82%E6%9C%89%E7%9A%84%E5%B0%8F%E5%84%BF%E7%8E%A9%E7%B4%AF%E4%BA%86%E6%88%96%E5%9B%B0%E4%BA%86%EF%BC%8C%E4%B8%8D%E5%88%B7%E7%89%99%E5%B0%B1%E4%B8%8A%E5%BA%8A%E7%9D%A1%E8%A7%89%EF%BC%8C%E8%BF%99%E6%97%B6%E5%BA%94%E6%99%93%E4%B9%8B%E4%BB%A5%E7%90%86%EF%BC%8C%E8%AF%B4%E6%9C%8D%E5%B0%8F%E5%84%BF%E5%88%B7%E7%89%99%E5%90%8E%E5%86%8D%E7%9D%A1%E8%A7%89%E3%80%82%E7%88%B6%E6%AF%8D%E8%BF%98%E5%8F%AF%E4%BB%A5%E7%BC%96%E4%B8%80%E4%BA%9B%E6%95%85%E4%BA%8B%E7%BB%99%E5%B0%8F%E5%84%BF%E5%90%AC%E5%A6%82%E5%B0%8F%E7%86%8A%E5%88%B7%E7%89%99%E7%9A%84%E6%95%85%E4%BA%8B%E7%AD%89%EF%BC%8C%E4%BD%BF%E5%B0%8F%E5%84%BF%E6%98%8E%E7%99%BD%E5%88%B7%E7%89%99%E7%9A%84%E5%A5%BD%E5%A4%84%E5%8F%8A%E4%B8%8D%E5%88%B7%E7%89%99%E7%9A%84%E5%8D%B1%E5%AE%B3%EF%BC%8C%E4%BB%8E%E8%80%8C%E5%85%BB%E6%88%90%E8%87%AA%E8%A7%89%E8%87%AA%E6%84%BF%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%E3%80%82%E5%81%A5%E5%BA%B7%E7%9A%84%E5%B0%8F%E5%84%BF%E5%BA%94%E8%AF%A5%E6%9C%89%E4%B8%80%E5%89%AF%E5%81%A5%E5%BA%B7%E7%9A%84%E7%89%99%E9%BD%BF%E3%80%82%E5%9B%9B%E3%80%81%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%88%B7%E7%89%99%EF%BC%8C%E4%BB%8E%E4%B8%80%E5%BC%80%E5%A7%8B%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%81%8C%E8%BE%93%E7%BB%99%E4%BB%96%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%EF%BC%8C%E8%80%8C%E4%B8%8D%E5%BA%94%E8%AF%A5%E7%BA%B5%E5%AE%B9%E4%BB%96%E6%8B%89%E9%94%AF%E5%BC%8F%E6%88%96%E8%80%85%E5%9C%88%E5%9C%88%E5%BC%8F%E7%9A%84%E4%B9%B1%E5%88%B7%E6%B3%95%E3%80%82%E8%BF%99%E7%A7%8D%E9%94%99%E8%AF%AF%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E4%B8%8D%E4%BD%86%E4%B8%8D%E8%83%BD%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%B9%B2%E5%87%80%EF%BC%8C%E8%BF%98%E5%AE%B9%E6%98%93%E5%AF%BC%E8%87%B4%E7%89%99%E9%BD%BF%E6%9C%80%E8%96%84%E5%BC%B1%E7%9A%84%E5%9C%B0%E6%96%B9%E2%80%93%E7%89%99%E9%A2%88%E9%83%A8%E6%8D%9F%E4%BC%A4%EF%BC%8C%E9%80%A0%E6%88%90%E7%89%99%E9%BD%BF%E7%9A%84%E6%A5%94%E7%8A%B6%E7%BC%BA%E9%99%B7%EF%BC%8C%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%87%BA%E4%B8%80%E6%9D%A1%E6%B2%9F%E6%9D%A5%EF%BC%8C%E4%BB%A5%E5%90%8E%E4%BD%BF%E7%94%A8%E7%A8%8D%E7%A1%AC%E7%9A%84%E7%89%99%E5%88%B7%E5%88%B7%E7%89%99%E8%A7%A6%E5%8F%8A%E5%88%B0%E7%89%99%E9%AB%93%E5%B0%B1%E4%BC%9A%E7%96%BC%E7%97%9B%E3%80%82%E6%AD%A3%E7%A1%AE%E7%9A%84%E6%96%B9%E5%BC%8F%E5%BA%94%E8%AF%A5%E6%98%AF%E9%A1%BA%E7%9D%80%E7%89%99%E7%BC%9D%E7%9A%84%E6%96%B9%E5%90%91%EF%BC%8C%E4%BB%8E%E4%B8%8A%E8%80%8C%E4%B8%8B%E3%80%81%E4%B8%80%E4%B8%AA%E4%B9%9F%E4%B8%8D%E8%83%BD%E5%B0%91%E5%9C%B0%E7%AB%96%E5%88%B7%E3%80%82%E6%97%A0%E8%AE%BA%E6%98%AF%E4%B8%8A%E4%B8%8B%E8%BF%98%E6%98%AF%E5%86%85%E5%A4%96%EF%BC%8C%E9%83%BD%E8%A6%81%E9%A1%BA%E7%9D%80%E7%89%99%E6%A0%B9%E5%BE%80%E7%89%99%E5%B0%96%E5%88%B7%E3%80%82%E7%89%99%E9%BD%BF%E5%92%AC%E5%90%88%E9%9D%A2%E5%8F%AF%E4%BB%A5%E6%A8%AA%E5%88%B7%EF%BC%8C%E8%BF%99%E6%A0%B7%E6%B8%85%E6%B4%81%E6%89%8D%E5%BD%BB%E5%BA%95%E3%80%82%E6%AF%8F%E6%AC%A1%E5%88%B7%E7%89%99%E8%87%B3%E5%B0%91%E9%9C%80%E8%A6%813%E5%88%86%E9%92%9F%E6%97%B6%E9%97%B4%EF%BC%8C%E5%8F%A6%E5%A4%96%EF%BC%8C%E5%86%AC%E5%A4%A9%E6%9C%80%E5%A5%BD%E7%94%A8%E6%B8%A9%E6%B0%B4%E5%88%B7%E7%89%99%EF%BC%8C%E4%B8%80%E4%BA%9B%E6%9C%AC%E8%BA%AB%E6%9C%89%E7%89%99%E7%97%85%E7%9A%84%E4%BA%BA%EF%BC%8C%E4%BD%BF%E7%94%A8%E5%86%B7%E6%B0%B4%E5%88%B7%E7%89%99%E5%AE%B9%E6%98%93%E5%88%BA%E6%BF%80%E5%88%B0%E7%89%99%E9%AB%93%EF%BC%8C%E5%BC%95%E8%B5%B7%E7%96%BC%E7%97%9B%E3%80%82%E5%BB%BA%E8%AE%AE%E6%97%A9%E6%99%9A%E5%88%B7%E7%89%99%EF%BC%8C%E8%BF%9B%E9%A3%9F%E5%90%8E%E9%83%BD%E5%BA%94%E8%AF%A5%E6%BC%B1%E5%8F%A3%E3%80%82%200\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2douban\" title=\"分享到豆�\�\" href=\"http://www.douban.com/recommend/?url=http://www.grow2up.cn/3126028.html&title=[%E6%91%98%E8%A6%81]%E4%BF%97%E8%AF%AD%E6%9C%89%E4%BA%91%EF%BC%8C%E4%B8%87%E4%BA%8B%E5%BC%80%E5%A4%B4%E9%9A%BE%EF%BC%8C%E5%AE%9D%E5%AE%9D%E5%AD%A6%E5%88%B7%E7%89%99%E4%B9%9F%E6%98%AF%E8%BF%99%E6%A0%B7%E4%B8%80%E4%B8%AA%E9%81%93%E7%90%86%E3%80%82%E6%95%99%E4%BC%9A%E4%BB%96%E4%BB%AC%E5%85%BB%E6%88%90%E4%B8%80%E4%B8%AA%E9%9C%80%E8%A6%81%E5%9D%9A%E6%8C%81%E4%B8%80%E7%94%9F%E7%9A%84%E5%A5%BD%E4%B9%A0%E6%83%AF%EF%BC%8C%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E5%8F%8D%E6%8E%8C%E4%B9%8B%E4%BA%8B%E3%80%82%E5%A6%82%E4%BD%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%EF%BC%9F%E6%88%91%E4%BB%AC%E4%B8%80%E8%B5%B7%E6%9D%A5%E7%9C%8B%E7%9C%8B%E5%90%A7%EF%BC%81%E5%8F%91%E8%82%B2%E6%AD%A3%E5%B8%B8%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E4%B8%80%E8%88%AC%E5%9C%A8%E4%B8%A4%E5%B2%81%E5%8D%8A%E5%B7%A6%E5%8F%B3%E9%95%BF%E5%87%BA%E6%89%80%E6%9C%89%E7%9A%84%E4%B9%B3%E7%89%99%E3%80%82%E5%9C%A8%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E5%B0%B1%E5%BA%94%E8%AF%A5%E8%AE%AD%E7%BB%83%E4%BB%96%E4%BB%AC%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E6%84%8F%E8%AF%86%EF%BC%8C%E4%BB%8E%E5%B0%8F%E5%85%BB%E6%88%90%E8%89%AF%E5%A5%BD%E7%9A%84%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E3%80%82%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E5%BF%BD%E8%A7%86%E7%89%99%E9%BD%BF%E5%81%A5%E5%BA%B7%EF%BC%8C%E6%80%BB%E6%83%B3%E7%9C%81%E4%BA%9B%E5%8A%9F%E5%A4%AB%EF%BC%8C%E7%AD%89%E5%AE%9D%E5%AE%9D%E4%BB%AC%E5%A4%A7%E4%BA%9B%E6%89%8D%E5%BC%80%E5%A7%8B%E5%88%B7%E7%89%99%EF%BC%8C%E8%80%8C%E6%9C%89%E4%BA%9B%E5%AE%B6%E9%95%BF%E7%94%9A%E8%87%B3%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E4%BD%8F%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%E3%80%82%E5%B9%BF%E5%B7%9E%E5%B8%82%E7%BA%A2%E5%8D%81%E5%AD%97%E4%BC%9A%E5%8C%BB%E9%99%A2%E5%8F%A3%E8%85%94%E7%A7%91%E4%B8%BB%E4%BB%BB%E5%8F%B6%E5%BF%97%E4%BD%B3%E4%BB%8B%E7%BB%8D%EF%BC%8C%E6%9B%BE%E7%BB%8F%E6%9C%89%E4%B8%80%E4%B8%AA%E4%B8%89%E5%B2%81%E7%9A%84%E5%B0%8F%E6%9C%8B%E5%8F%8B%EF%BC%8C%E6%BB%A1%E5%8F%A3%E7%89%99%E5%85%A8%E6%98%AF%E9%BB%91%E8%89%B2%E7%9A%84%EF%BC%8C%E7%89%99%E9%BD%BF%E5%9F%BA%E6%9C%AC%E9%83%BD%E7%83%82%E6%8E%89%E4%BA%86%EF%BC%8C%E5%8E%9F%E6%9D%A5%E6%82%A3%E5%84%BF%E7%9A%84%E5%A6%88%E5%A6%88%E4%BB%8E%E6%9D%A5%E9%83%BD%E6%98%AF%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%90%AB%E7%9D%80%E5%A5%B6%E7%93%B6%E7%9D%A1%E8%A7%89%EF%BC%8C%E5%BE%88%E5%B0%91%E6%B8%85%E6%B4%81%E5%8F%A3%E8%85%94%E3%80%82%E5%A6%82%E4%BD%95%E6%95%99%E5%AE%9D%E5%AE%9D%E5%88%B7%E7%89%99%EF%BC%9F%E4%B8%80%E3%80%81%E7%89%99%E9%BD%BF%E6%B8%85%E6%B4%81%E8%A6%81%E4%BB%8E%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%E5%BD%93%E5%B0%8F%E6%9C%8B%E5%8F%8B%E5%9C%A8%E5%8D%8A%E5%B2%81%E5%B7%A6%E5%8F%B3%E8%90%8C%E5%87%BA%E7%AC%AC%E4%B8%80%E9%A2%97%E4%B9%B3%E7%89%99%E5%BC%80%E5%A7%8B%EF%BC%8C%E7%88%B6%E6%AF%8D%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%BB%99%E5%B0%8F%E5%84%BF%E6%B8%85%E6%B4%81%E7%89%99%E9%BD%BF%E4%BA%86%E3%80%82%E5%AE%B6%E9%95%BF%E5%8F%AF%E4%BB%A5%E7%94%A8%E7%BA%B1%E5%B8%83%E3%80%81%E6%A3%89%E7%AD%BE%E8%98%B8%E6%B9%BF%E6%B8%A9%E6%B0%B4%E6%93%A6%E6%B4%97%E3%80%82%E8%80%8C%E7%AD%89%E5%AD%A9%E5%AD%90%E9%95%BF%E5%A4%A7%E4%B8%80%E4%BA%9B%EF%BC%8C%E5%B0%B1%E5%8F%AF%E4%BB%A5%E8%B7%9F%E5%AD%A9%E5%AD%90%E8%AF%B4%E7%88%B1%E6%8A%A4%E7%89%99%E9%BD%BF%E7%9A%84%E9%87%8D%E8%A6%81%E6%80%A7%EF%BC%8C%E6%AF%8F%E5%A4%A9%E8%AE%A9%E5%AD%A9%E5%AD%90%E7%9C%8B%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E8%80%8C%E5%88%B0%E5%AE%9D%E5%AE%9D2%E5%B2%81%E5%B7%A6%E5%8F%B3%EF%BC%8C%E5%8A%A8%E4%BD%9C%E6%AF%94%E8%BE%83%E7%81%B5%E6%B4%BB%E4%BA%86%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%AD%A6%E7%9D%80%E8%87%AA%E5%B7%B1%E5%88%B7%E7%89%99%E3%80%82%E6%9C%89%E4%BA%86%E5%88%B7%E7%89%99%E7%9A%84%E8%80%B3%E6%BF%A1%E7%9B%AE%E6%9F%93%EF%BC%8C%E5%B0%8F%E5%84%BF%E5%9F%BA%E6%9C%AC%E4%B8%8A%E9%80%82%E5%BA%94%E4%BA%86%E5%88%B7%E7%89%99%E3%80%82%E4%BD%86%E4%BB%8E%E5%88%AB%E4%BA%BA%E5%88%B7%E5%88%B0%E8%87%AA%E5%B7%B1%E5%AD%A6%E7%9D%80%E5%88%B7%E9%9C%80%E8%A6%81%E4%B8%80%E4%B8%AA%E8%BF%87%E7%A8%8B%E3%80%82%E4%BA%8C%E3%80%81%E5%87%86%E5%A4%87%E5%8F%AF%E7%88%B1%E6%B8%85%E6%96%B0%E7%9A%84%E5%88%B7%E7%89%99%E7%94%A8%E5%85%B7%E5%B0%8F%E6%9C%8B%E5%8F%8B%E9%83%BD%E6%98%AF%E8%B4%AA%E6%96%B0%E9%B2%9C%E7%9A%84%EF%BC%8C%E5%96%9C%E6%AC%A2%E8%8A%B1%E8%8A%B1%E7%BB%BF%E7%BB%BF%EF%BC%8C%E7%94%9C%E7%94%9C%E5%91%B3%E9%81%93%E7%9A%84%E4%B8%9C%E8%A5%BF%E3%80%82%E6%89%80%E4%BB%A5%E5%A6%82%E6%9E%9C%E8%A6%81%E8%AE%A9%E5%AD%A9%E5%AD%90%E5%85%BB%E6%88%90%E5%88%B7%E7%89%99%E4%B9%A0%E6%83%AF%E7%9A%84%E8%AF%9D%EF%BC%8C%E5%B0%B1%E8%A6%81%E5%85%88%E8%AE%A9%E4%BB%96%E4%BB%AC%E7%88%B1%E4%B8%8A%E5%88%B7%E7%89%99%E3%80%82%E5%BA%94%E8%AF%A5%E8%A6%81%E5%A6%82%E4%BD%95%E6%8C%91%E9%80%89%E7%89%99%E5%88%B7%E5%92%8C%E7%89%99%E8%86%8F%E5%91%A2%EF%BC%9F%E5%8D%A1%E9%80%9A%E8%BD%AF%E6%AF%9B%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E5%88%B7%E5%B0%B1%E6%9C%80%E5%8F%97%E5%B0%8F%E6%9C%8B%E5%8F%8B%E6%AC%A2%E8%BF%8E%E4%BA%86%E3%80%82%E7%89%99%E5%88%B7%E4%BD%BF%E7%94%A83%E4%B8%AA%E6%9C%88%E5%90%8E%E5%B0%B1%E8%A6%81%E6%9B%B4%E6%8D%A2%E3%80%82%E8%80%8C%E7%89%99%E8%86%8F%E6%96%B9%E9%9D%A2%EF%BC%8C%E6%9C%80%E5%A5%BD%E9%80%89%E7%94%A8%E5%90%AB%E6%B0%B4%E6%9E%9C%E7%94%9C%E5%91%B3%E7%9A%84%E5%84%BF%E7%AB%A5%E7%89%99%E8%86%8F%EF%BC%8C3%E5%B2%81%E4%BB%A5%E4%B8%8B%E7%9A%84%E5%B9%BC%E5%84%BF%E4%B8%8D%E5%AE%9C%E4%BD%BF%E7%94%A8%E5%90%AB%E6%B0%9F%E7%89%99%E8%86%8F%E3%80%82%E6%9C%80%E5%A5%BD%E6%97%A9%E6%99%9A%E7%89%99%E8%86%8F%E9%80%89%E7%94%A8%E4%B8%8D%E5%90%8C%E7%9A%84%E5%93%81%E7%89%8C%EF%BC%8C%E5%9B%A0%E4%B8%BA%E7%89%99%E8%86%8F%E4%B8%AD%E4%B9%9F%E5%90%AB%E6%9C%89%E6%9D%80%E8%8F%8C%E7%9A%84%E6%88%90%E5%88%86%EF%BC%8C%E5%A6%82%E6%9E%9C%E6%80%BB%E6%98%AF%E4%BD%BF%E7%94%A8%E5%90%8C%E4%B8%80%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E5%8F%A3%E8%85%94%E4%B8%AD%E7%9A%84%E7%BB%86%E8%8F%8C%E5%B0%B1%E4%BC%9A%E9%80%82%E5%BA%94%E8%BF%99%E7%A7%8D%E7%89%99%E8%86%8F%EF%BC%8C%E4%B8%8D%E5%88%A9%E4%BA%8E%E9%99%A4%E8%8F%8C%E3%80%82%20%E4%B8%89%E3%80%81%E5%9D%9A%E6%8C%81%E5%B0%B1%E6%98%AF%E8%83%9C%E5%88%A9%E5%88%9A%E5%BC%80%E5%A7%8B%E5%AD%A6%E5%88%B7%E7%89%99%E7%9A%84%E6%97%B6%E5%80%99%EF%BC%8C%E5%B0%8F%E6%9C%8B%E5%8F%8B%E4%BB%AC%E5%8F%AF%E8%83%BD%E4%BC%9A%E6%B2%A1%E6%9C%89%E8%80%90%E5%BF%83%EF%BC%8C%E8%83%A1%E4%B9%B1%E5%88%92%E4%B8%A4%E4%B8%8B%E5%BA%94%E4%BB%98%E4%BA%86%E4%BA%8B%EF%BC%8C%E8%BF%99%E4%B8%AA%E6%97%B6%E5%80%99%E7%88%B8%E7%88%B8%E5%A6%88%E5%A6%88%E5%8F%AF%E4%BB%A5%E5%9C%A8%E5%AD%A9%E5%AD%90%E5%88%B7%E5%AE%8C%E5%90%8E%E6%8C%87%E5%87%BA%E5%B9%B6%E7%BA%A0%E6%AD%A3%E4%BB%96%E4%B8%8D%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%A7%BF%E5%8A%BF%E5%92%8C%E6%96%B9%E6%B3%95%E3%80%82%E5%9D%9A%E6%8C%81%E5%88%B7%E4%B8%80%E5%A4%A9%E4%B8%A4%E5%A4%A9%E5%B9%B6%E9%9D%9E%E4%BB%80%E4%B9%88%E9%9A%BE%E4%BA%8B%EF%BC%8C%E8%80%8C%E5%9D%9A%E6%8C%81%E4%B8%8B%E5%8E%BB%E5%B0%B1%E4%B8%8D%E6%98%AF%E9%82%A3%E4%B9%88%E5%AE%B9%E6%98%93%E4%BA%86%E3%80%82%E6%9C%89%E7%9A%84%E5%B0%8F%E5%84%BF%E7%8E%A9%E7%B4%AF%E4%BA%86%E6%88%96%E5%9B%B0%E4%BA%86%EF%BC%8C%E4%B8%8D%E5%88%B7%E7%89%99%E5%B0%B1%E4%B8%8A%E5%BA%8A%E7%9D%A1%E8%A7%89%EF%BC%8C%E8%BF%99%E6%97%B6%E5%BA%94%E6%99%93%E4%B9%8B%E4%BB%A5%E7%90%86%EF%BC%8C%E8%AF%B4%E6%9C%8D%E5%B0%8F%E5%84%BF%E5%88%B7%E7%89%99%E5%90%8E%E5%86%8D%E7%9D%A1%E8%A7%89%E3%80%82%E7%88%B6%E6%AF%8D%E8%BF%98%E5%8F%AF%E4%BB%A5%E7%BC%96%E4%B8%80%E4%BA%9B%E6%95%85%E4%BA%8B%E7%BB%99%E5%B0%8F%E5%84%BF%E5%90%AC%E5%A6%82%E5%B0%8F%E7%86%8A%E5%88%B7%E7%89%99%E7%9A%84%E6%95%85%E4%BA%8B%E7%AD%89%EF%BC%8C%E4%BD%BF%E5%B0%8F%E5%84%BF%E6%98%8E%E7%99%BD%E5%88%B7%E7%89%99%E7%9A%84%E5%A5%BD%E5%A4%84%E5%8F%8A%E4%B8%8D%E5%88%B7%E7%89%99%E7%9A%84%E5%8D%B1%E5%AE%B3%EF%BC%8C%E4%BB%8E%E8%80%8C%E5%85%BB%E6%88%90%E8%87%AA%E8%A7%89%E8%87%AA%E6%84%BF%E5%88%B7%E7%89%99%E7%9A%84%E4%B9%A0%E6%83%AF%E3%80%82%E5%81%A5%E5%BA%B7%E7%9A%84%E5%B0%8F%E5%84%BF%E5%BA%94%E8%AF%A5%E6%9C%89%E4%B8%80%E5%89%AF%E5%81%A5%E5%BA%B7%E7%9A%84%E7%89%99%E9%BD%BF%E3%80%82%E5%9B%9B%E3%80%81%E5%85%BB%E6%88%90%E6%AD%A3%E7%A1%AE%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E8%AE%AD%E7%BB%83%E5%AD%A9%E5%AD%90%E5%88%B7%E7%89%99%EF%BC%8C%E4%BB%8E%E4%B8%80%E5%BC%80%E5%A7%8B%E5%B0%B1%E5%BA%94%E8%AF%A5%E7%81%8C%E8%BE%93%E7%BB%99%E4%BB%96%E6%AD%A3%E7%A1%AE%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%EF%BC%8C%E8%80%8C%E4%B8%8D%E5%BA%94%E8%AF%A5%E7%BA%B5%E5%AE%B9%E4%BB%96%E6%8B%89%E9%94%AF%E5%BC%8F%E6%88%96%E8%80%85%E5%9C%88%E5%9C%88%E5%BC%8F%E7%9A%84%E4%B9%B1%E5%88%B7%E6%B3%95%E3%80%82%E8%BF%99%E7%A7%8D%E9%94%99%E8%AF%AF%E7%9A%84%E5%88%B7%E7%89%99%E6%96%B9%E6%B3%95%E4%B8%8D%E4%BD%86%E4%B8%8D%E8%83%BD%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%B9%B2%E5%87%80%EF%BC%8C%E8%BF%98%E5%AE%B9%E6%98%93%E5%AF%BC%E8%87%B4%E7%89%99%E9%BD%BF%E6%9C%80%E8%96%84%E5%BC%B1%E7%9A%84%E5%9C%B0%E6%96%B9%E2%80%93%E7%89%99%E9%A2%88%E9%83%A8%E6%8D%9F%E4%BC%A4%EF%BC%8C%E9%80%A0%E6%88%90%E7%89%99%E9%BD%BF%E7%9A%84%E6%A5%94%E7%8A%B6%E7%BC%BA%E9%99%B7%EF%BC%8C%E6%8A%8A%E7%89%99%E9%BD%BF%E5%88%B7%E5%87%BA%E4%B8%80%E6%9D%A1%E6%B2%9F%E6%9D%A5%EF%BC%8C%E4%BB%A5%E5%90%8E%E4%BD%BF%E7%94%A8%E7%A8%8D%E7%A1%AC%E7%9A%84%E7%89%99%E5%88%B7%E5%88%B7%E7%89%99%E8%A7%A6%E5%8F%8A%E5%88%B0%E7%89%99%E9%AB%93%E5%B0%B1%E4%BC%9A%E7%96%BC%E7%97%9B%E3%80%82%E6%AD%A3%E7%A1%AE%E7%9A%84%E6%96%B9%E5%BC%8F%E5%BA%94%E8%AF%A5%E6%98%AF%E9%A1%BA%E7%9D%80%E7%89%99%E7%BC%9D%E7%9A%84%E6%96%B9%E5%90%91%EF%BC%8C%E4%BB%8E%E4%B8%8A%E8%80%8C%E4%B8%8B%E3%80%81%E4%B8%80%E4%B8%AA%E4%B9%9F%E4%B8%8D%E8%83%BD%E5%B0%91%E5%9C%B0%E7%AB%96%E5%88%B7%E3%80%82%E6%97%A0%E8%AE%BA%E6%98%AF%E4%B8%8A%E4%B8%8B%E8%BF%98%E6%98%AF%E5%86%85%E5%A4%96%EF%BC%8C%E9%83%BD%E8%A6%81%E9%A1%BA%E7%9D%80%E7%89%99%E6%A0%B9%E5%BE%80%E7%89%99%E5%B0%96%E5%88%B7%E3%80%82%E7%89%99%E9%BD%BF%E5%92%AC%E5%90%88%E9%9D%A2%E5%8F%AF%E4%BB%A5%E6%A8%AA%E5%88%B7%EF%BC%8C%E8%BF%99%E6%A0%B7%E6%B8%85%E6%B4%81%E6%89%8D%E5%BD%BB%E5%BA%95%E3%80%82%E6%AF%8F%E6%AC%A1%E5%88%B7%E7%89%99%E8%87%B3%E5%B0%91%E9%9C%80%E8%A6%813%E5%88%86%E9%92%9F%E6%97%B6%E9%97%B4%EF%BC%8C%E5%8F%A6%E5%A4%96%EF%BC%8C%E5%86%AC%E5%A4%A9%E6%9C%80%E5%A5%BD%E7%94%A8%E6%B8%A9%E6%B0%B4%E5%88%B7%E7%89%99%EF%BC%8C%E4%B8%80%E4%BA%9B%E6%9C%AC%E8%BA%AB%E6%9C%89%E7%89%99%E7%97%85%E7%9A%84%E4%BA%BA%EF%BC%8C%E4%BD%BF%E7%94%A8%E5%86%B7%E6%B0%B4%E5%88%B7%E7%89%99%E5%AE%B9%E6%98%93%E5%88%BA%E6%BF%80%E5%88%B0%E7%89%99%E9%AB%93%EF%BC%8C%E5%BC%95%E8%B5%B7%E7%96%BC%E7%97%9B%E3%80%82%E5%BB%BA%E8%AE%AE%E6%97%A9%E6%99%9A%E5%88%B7%E7%89%99%EF%BC%8C%E8%BF%9B%E9%A3%9F%E5%90%8E%E9%83%BD%E5%BA%94%E8%AF%A5%E6%BC%B1%E5%8F%A3%E3%80%82%200\" rel=\"nofollow\" target=\"_blank\"></a></p><p><a class=\"jiathis_button_qzone\" title=\"分享到QQ空间\"><span class=\"jiathis_txt jtico jtico_qzone\"></span></a><a class=\"jiathis_button_tsina\" title=\"分享到新浪微�\�\"><span class=\"jiathis_txt jtico jtico_tsina\"></span></a><a class=\"jiathis_button_tqq\" title=\"分享到腾讯微�\�\"><span class=\"jiathis_txt jtico jtico_tqq\"></span></a><a class=\"jiathis_button_renren\" title=\"分享到人人网\"><span class=\"jiathis_txt jtico jtico_renren\"></span></a><a class=\"jiathis_button_kaixin001\" title=\"分享到开心网\"><span class=\"jiathis_txt jtico jtico_kaixin001\"></span></a><a hidefocus=\"\" class=\"jiathis jiathis_txt jtico jtico_jiathis\" href=\"http://www.jiathis.com/share/\" target=\"_blank\"></a><a class=\"jiathis_counter_style\">0</a></p></p><p></p><p><a class=\"zoomclose\" title=\"关闭\" jquery1710476371257763619=\"13\"></a><a class=\"zoomprevious\" title=\"上一张（或按键盘←键�\�\" href=\"http://www.grow2up.cn/3126028.html#previous\" jquery1710476371257763619=\"14\"></a><a class=\"zoomnext\" title=\"（或按键盘→键）\" href=\"http://www.grow2up.cn/3126028.html#next\" jquery1710476371257763619=\"15\"></a></p><p><br/></p>', '1402800612', '0', '0', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('61', '亲子游戏', '3', '夏天如何陪伴宝宝安全玩水', '', '60', '387', '<p>炎炎夏日，对于幼儿来说没有什么比玩水更舒服的事情了；然而玩水也存在着种种不安全因素。如何陪伴宝宝安全地玩水？小编为妈妈们支上几招�\�</p><p><strong>预警1：注重水�\�</strong></p><p>为了能和宝宝一起游泳，有些父母会把宝宝带到成人泳池玩耍，这是非常不适当的。因为成人泳池人比较多，细菌会大量滋生，影响宝宝的健康。而且，成人泳池的消毒系统和循环系统都与婴幼儿泳池不同，氯气消毒的成人泳池会损害宝宝的鼻腔、口腔、外生殖器等部位的皮肤、黏膜，易导致体质过敏，严重者甚至会引发哮喘和心脏病。安全措施：�\�3岁以下的宝宝不要去成人泳池，最好去专业的婴幼儿游泳池。？</p><p>宝宝出水后，要披上干净的浴巾，使用过的浴巾一定要清洗消毒，减少细菌感染�\�</p><p>游完泳后应让宝宝用淡盐水漱口，保证盐水在喉咙里停留一段时间再吐掉，可以保护宝宝上呼吸道免受病毒、细菌侵袭�\�</p><p>游泳后要用干净的棉签或酒精棉帮宝宝清理耳朵积水，以免细菌在里面滋生，引起外耳炎。回家后要好好刷牙，以减少消毒液中次氯酸和高氯酸对宝宝牙齿的损害。用清水彻底洗澡和冲洗头发，并重点清洗腋窝、生殖器官等容易藏匿细菌的部位�\�</p><p><strong>预警2：选对用品</strong></p><p>宝宝在水中玩耍，浮板、浮力圈、救生圈、泳衣、泳帽、眼镜、戏水玩具等用品自然必不可少，妈妈在选择婴幼儿游泳用品时应选择安全、合格的产品�\�</p><p>安全措施：选择符合医疗器械标准的游泳用品，表面光滑、做工精细，不会对宝宝的皮肤造成伤害�\�</p><p>游泳圈厚度应大于或等�\�0.25毫米；色彩应鲜艳，且与水形成鲜明的对比；气嘴应有单向阀门，气嘴上应有一个永久附着的气塞，气塞和气嘴的密封性能要好，无漏气现象；阀门上的气塞不能脱落，应加以保护，防止意外松开，单向阀通常适合于充气玩具；外观表面涂层接合应牢固，无明显的漏底�\�</p><p>宝宝应在父母监护下使用游泳圈。使用前，最好先把游泳圈充气，放进水里片刻，看是否有小气泡冒出。宝宝在水中游泳时不能佩戴硬物，避免碰伤、扎破气囊�\�</p><p><strong>预警3：全程监�\�</strong></p><p>由于父母疏于监护而造成婴幼儿溺亡的事件时有发生。即使是2.5厘米深的水也足以让宝宝在不到30秒的时间内溺水。因此，父母应时刻留心各种危险情况，保证宝宝在水中的安全�\�</p><p>安全措施：宝宝游泳时，妈妈应全程监护，与宝宝的距离保持在一臂之内。不要抓住泳圈来移动泳池中的宝宝，而是握住宝宝的手让宝宝在水中移动。妈妈要随时留心宝宝的举动，避免宝宝在游得高兴时双腿向前蹬泳池壁，造成身体后仰而落水�\�</p><p>宝宝下水前，应做好泳前操，戴上泳圈，适应水温并下水。在游泳过程中可以给宝宝做一些按摩，帮助宝宝动动。？3岁以下的宝宝不适宜高强度的游泳训练，千万不要让他们钻到水面以下，以免大量呛水，这会稀释宝宝血液中的成分，引发失眠、恶心和惊厥等不适症状�\�</p><p><strong>意外情况应急处�\�</strong></p><p>1.忌空腹游泳宝宝空腹游泳，肠胃空虚，体能不足，游泳体能消耗高，易造成虚脱；也不能过饱，刚吃饱时肠胃及内脏供血量不足，不利于食物的消化，甚至引起肠胃不适、恶心、呕吐。应选在吃饱�\�1小时进行，游泳时间不宜太长，最好控制在20�\�30分钟内�\�</p><p>2.水温控制宝宝游泳的水温宜控制�\�36℃�\�38℃，室温�\�28℃左右，以免宝宝着凉。游泳完毕后要迅速擦干宝宝身上的水迹，注意保温。如果宝宝开始打冷战或头晕脑胀，应立即把宝宝抱上岸，用浴巾擦干，穿上衣服。全身保温，并适当喝些淡糖盐水�\�</p><p>3.应对腿部抽筋一旦宝宝腿抽筋，应立即让宝宝离开泳池，热敷抽筋的部位，并轻轻地加以按摩�\�</p><p>4.应对眼睛痒痛宝宝如果眼睛痒痛，可能是由于水不洁净引起。上岸后应马上用清洁的淡盐水冲洗眼睛，然后用氯霉素或红霉素眼药水点眼，临睡前最好再做一下热敷，以免发展成结膜炎�\�</p><p>5.应对耳朵进水一旦宝宝耳朵里灌水或鼻子呛水，父母应让宝宝的头歪向耳朵进水的一侧，用力拉住耳垂，用消毒棉签送入耳道内将水吸出，或请救生员协助处理�\�</p><p><strong>TIPS：当宝宝有以下特殊情况时不宜下水</strong></p><p>宝宝生病、打预防针、哭闹、感染、感冒、发烧、拉肚子、局部发湿疹或非常严重的不可游泳。早产儿以及脚易抽筋、身体异常者、免疫系统有问题、呼吸道感染（具传染性）的宝宝不适合游泳�\�</p><p><br/></p>', '1402801157', '0', '2', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('62', '健康宝贝', '3', '如何给小儿服用维生素D', '', '59', '388', '<p><span class=\"wp_keywordlink_affiliate\"><a title=\"查看维生素D中的全部文章\" href=\"http://www.grow2up.cn/tag/%e7%bb%b4%e7%94%9f%e7%b4%a0d\" target=\"_blank\">维生素D</a></span>是预防和治疗佝偻病的药物�\�<span class=\"wp_keywordlink_affiliate\"><a title=\"查看维生素D中的全部文章\" href=\"http://www.grow2up.cn/tag/%e7%bb%b4%e7%94%9f%e7%b4%a0d\" target=\"_blank\">维生素D</a></span>包括维生素D2和D3，是动植物在生存期间受到日光紫外线照射后，由无活性的维生素D前体变成有活性的维生素D。维生素D2和D3的作用和用途完全相同�\�</p><p>　　目前常用的口服维生素D制剂有：<br/>　　1、浓缩鱼肝油滴剂：每毫升含维生素A50000单位，维生素D5000单位�\�<br/>　　2、普通鱼肝油丸：每粒含维生素A3000单位，维生素D300单位�\�<br/>　　3、浓缩鱼肝油丸：每粒含维生素A10000单位，维生素1000单位�\�<br/>　　4、维生素D2丸：每粒含维生素D210000单位�\�<br/>　　5、维生素D3片：每片含维生素D310000单位�\�<br/>　　6、伊可欣胶囊�\�0-1岁制剂：每粒含维生素A1500单位，维生素D500单位�\�</p><p>　　1岁以上制剂：每粒含维生素A2000单位，维生素D700单位。另外还有注射剂：维生素D240万单�\�/毫升，维生素D330万单�\�/毫升�\�60万单�\�/毫升�\�</p><p>　　那么，怎样选用不同的制剂呢？应根据小儿的情况及使用目的不同选用不同的制剂�\�</p><p>　　预防佝偻病：新生儿期2周后，每日服用维生素D400单位，早产儿及双胎儿其用量在�\�3月内应加倍，即每�\�800单位，以后改为每�\�400单位�\�2岁以后生长速度减慢，户外活动增多，食物多样化，一般不易发生佝偻病，故不需加服维生素D。对长期使用抗癫痫药如苯妥英那、苯巴比妥等药的患者，应每日补充维生素D2000单位。这是由于这类抗癫痫药可加速维生素D在肝脏的灭活，从而导致维生素D缺乏。由于预防时所用剂量较小，选用鱼肝油滴剂或鱼肝油丸比较方便�\�</p><p>　　另外，为预防婴儿发生佝偻病，应做好宣传普及工作，从孕期抓起。孕妇及乳母注意饮食调配，多吃富含维生素D及钙磷的食物，应多晒太阳，孕�\�4�\�5月后应加服钙片及维生素D400单位�\�</p><p>　　治疗佝偻病：对已有维生素D缺乏性佝偻病的小儿，应根据病情所处的阶段使用治疗剂量的维生素D，需选择单纯维生素D制剂。鱼肝油含有维生素A和D，不适用于治疗佝偻病，因为要达到治疗用量的维生素D时，因同时含有的维生素A量过大，可导致维生素A中毒�\�</p><p>　　1、普通疗法：初期佝偻病，每日口服维生素D5000�\�10000单位；激期佝偻病，每日口服维生素D1万－2万单位。均持续1月后改为预防用量。恢复期一般用预防剂量�\�</p><p>　　2、突击疗法：大剂量维生素D突击疗法，一般只用于严重佝偻病有并发症及不能口服的患儿。肌注维生素D2或D330万单�\�1次，间隔1月后改服预防剂量。但一般佝偻病不提倡使用，以防引起维生素D中毒�\�</p><p>　　应该强调，由于我国膳食结构的影响，从食物中摄取的钙不足，因此，除母乳喂养儿外，在服用维生素D的同时要同时服用钙剂。目前市场上钙剂品种很多，其钙元素的含量亦相差很大，如碳酸钙的含钙量�\�40％，氯化钙的含钙量为27％，而葡萄糖酸钙的含钙量只有9％。选用钙剂时宜选易溶解、含钙元素高及使用方便的剂型�\�</p><p><br/></p>', '1402801448', '0', '0', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('63', '健康完全营养饮食', '3', '塑造宝宝超强大脑的好食�\�', '', '59', '389', '<p><strong>导语�\�</strong><span class=\"wp_keywordlink_affiliate\"><a title=\"查看宝宝大脑中的全部文章\" href=\"http://www.grow2up.cn/tag/%e5%ae%9d%e5%ae%9d%e5%a4%a7%e8%84%91\" target=\"_blank\">宝宝大脑</a></span>发育的关键时期，妈妈们一定要保证宝贝的营养全面，通过多种营养成分的补充可以使脑神经细胞活跃，思考及记忆力增强，为宝宝的智能发展奠定良好的基础。然而面对诸多营养丰富的食物，究竟哪些能够“营养”宝宝的大脑�\�?</p><hr/><p>　　<span style=\"-COLOR: #ff9900\"><strong>脂质</strong></span></p><p>　　对于宝宝的大脑发育来说，脂质是第一重要的营养素。因为人的大脑约�\�60%是由脂质组成的，是形成脑细胞和脑神经纤维必不可少的营养成分�\�</p><p>　　脂质是不饱和脂肪酸，包含卵磷脂、胆固醇、糖脂、神经磷脂等，其中以卵磷脂含量最多，需求量也最大。脂质可维持神经细胞的正常生理活动，并参与大脑思维与记忆等智力活动，对脑细胞和神经的发育起着极为重要的作用�\�</p><p style=\"TEXT-ALIGN: center\"><br/></p><p><a class=\"jzoom\" href=\"http://f.yaolanimage.cn/cms/image/131970963.jpg\" jquery17102797780577834525=\"20\"><img title=\"点击查看大图\" alt=\"\" src=\"http://f.yaolanimage.cn/cms/image/131970963.jpg\" width=\"400\" height=\"300\" jquery17102797780577834525=\"11\"/></a></p><p>　　<strong>推荐食物</strong></p><p>　　各种坚果及果实类，如核桃、芝麻、松子、葵花子、南瓜子、西瓜子、杏仁、花生、芒果、金针菜�\�</p><p>　　各种鱼类，特别是牡蛎、海螺、乌贼、章鱼、虾等含量更高�\�</p><p>　　各种肉类，如牛肉、猪肉、羊肉、鸡肉、鸭肉、鹌鹑肉及野兔肉等。  �\�</p>', '1402801739', '0', '0', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('64', '健康保健', '3', '孩子睡前哭闹 听哭声来找原�\�', '', '59', '390', '<p class=\"titdd-Article\">[<strong>摘要</strong>]一岁之内的孩子要是临睡之前哭闹是最让新手妈担心的事，因为小孩子不会说话和表达情绪，妈妈就会很担心是不是孩子伤到哪了。其实，遇到这种情况，要仔细观察孩子的各种情况去找到孩子哭的原因�\�</p><p style=\"text-align: center; \"><a href=\"http://joint4.xicp.net/game/yijia/index.htm\" target=\"_blank\" title=\"小青蛙过河游�\�\" style=\"color: rgb(0, 176, 240); text-decoration: underline; \"><span style=\"color: rgb(0, 176, 240); \">小青蛙过河游�\�</span></a><br/></p><p style=\"text-align:center;\"><strong><br/></strong></p><p><strong><a class=\"jzoom\" href=\"http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" jquery17105313068498565563=\"16\"><img title=\"点击查看大图\" alt=\"孩子睡前哭闹 听哭声来找原�\�\" src=\"http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" jquery17105313068498565563=\"11\"/></a></strong></p><p><strong><a class=\"share2sina\" title=\"分享到新浪微�\�\" href=\"http://v.t.sina.com.cn/share/share.php?url=http://www.grow2up.cn/2026027.html&ralateUid=&appkey=&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&pic=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2t\" title=\"分享到腾讯微�\�\" href=\"http://v.t.qq.com/share/share.php?url=http://www.grow2up.cn/2026027.html&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&appkey=&pic=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2qzone\" title=\"分享到QQ空间\" href=\"http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http://www.grow2up.cn/2026027.html&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&pics=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2douban\" title=\"分享到豆�\�\" href=\"http://www.douban.com/recommend/?url=http://www.grow2up.cn/2026027.html&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&pics=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a></strong></p><p><strong><br/></strong></p><p><br/></p><p style=\"TEXT-INDENT: 2em\"><strong>孩子哭声解读�\�</strong></p><p style=\"TEXT-INDENT: 2em\">孩子虽然不会说话，但是他们是通过哭声去诉说自己的要求。妈妈就要在平常的时候注意观察宝宝哭声的不同。当宝宝哭声非常大，洪亮有力时，其实他想说的是“妈妈，我饿了，我想睡觉”时，这个时候妈妈就要赶紧给孩子喂奶，同时让周围的环境安静下来，孩子也会在吃饱之后慢慢的进入梦乡�\�</p><p style=\"TEXT-INDENT: 2em\">当孩子哭声短促又急切时，可能是想要传达的信息是“有东西弄疼我”“我的身体好不舒服”“我身体某个部位很疼”，这个时候妈妈就要通过抚摸法去安抚孩子，轻轻抚摸一下孩子的肚子或者背。有的孩子的胎毛可能比较长比较硬，当孩子躺在床上太长时间了，这些胎毛就会刺痛孩子嫩嫩的背部导致孩子哭闹不止。当妈妈不停的抚摸孩子的背部时，孩子就会感觉很舒服，哭声就会停止�\�</p><p style=\"TEXT-INDENT: 2em\">当孩子的吃饱了睡足了但还是不停的哭闹，而这个时候的哭声可能是低沉，哭声连贯。这个时候孩子可能只是想说“我好热，我想抱”，除了哭声低沉外，孩子手心很热额头不停的出汗，同时还不停的蹬脚，妈妈们就要根据实际情况，开窗通风，降低室内温度或者给孩子换一些薄薄的衣服或盖被。有的孩子哭闹不止就是想要大人抱，想要跟大人有肌肤上面的接触。当大人一抱时，孩子自然而然的就停止的哭闹�\�</p><p style=\"TEXT-INDENT: 2em\"><strong>检查孩子哭闹法</strong></p><p style=\"TEXT-INDENT: 2em\">有一些新生儿因为生下来比较弱，哭声小，这就导致一些新手妈妈很难通过判断孩子的哭声来判断孩子到底是饿了还是累了，像这种情况，妈妈们还可以通过以下方法去找到孩子哭闹的原因：首先打开包包的衣服看是否有尿或者便便了。然后看宝宝是否饿了。看宝宝睡的是否舒服，被子底下是否有小玩具等东西影响睡眠，或者衣服绑紧了 \r\n让宝宝不舒服�\�</p><p style=\"TEXT-INDENT: 2em\">看看室内温度，太冷或者太�\� 被子太重，衣服穿的太�\� 都会影响宝宝的睡眠质�\� \r\n，宝宝不会说话，只能通过哭声表达不适； 缺乏安全感，突然到一个陌生的环境里，妈妈不在身边 孩子天生的敏感会让小孩啼哭不止。妈妈要多陪在孩子身�\� \r\n给孩子熟悉的气息�\� 错误的生活习惯。孩子白天睡觉，晚上哭闹�\� 这边白天要减少孩子的睡眠时间。多带孩子做一些简单的运动，让孩子产生疲劳。晚上自然睡的香香； \r\n若孩子半夜哭闹不停，应轻轻抱住孩子，不要用力摇晃孩子的头�\� 会造成孩子头部积液。给孩子唱首吹眠歌。让妈妈的温馨的气息围绕孩子 给孩子安全感�\�  </p><p><br/></p>', '1402802207', '0', '14', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('65', '教育', '3', '只要三招 有效教育任性宝�\�', '', '61', '391', '<p class=\"titdd-Article\">一岁之内的孩子要是临睡之前哭闹是最让新手妈担心的事，因为小孩子不会说话和表达情绪，妈妈就会很担心是不是孩子伤到哪了。其实，遇到这种情况，要仔细观察孩子的各种情况去找到孩子哭的原因�\�</p><p><strong><a class=\"jzoom\" href=\"http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" jquery17105313068498565563=\"16\"><img title=\"点击查看大图\" alt=\"孩子睡前哭闹 听哭声来找原�\�\" src=\"http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" jquery17105313068498565563=\"11\"/></a></strong></p><p><strong><a class=\"share2sina\" title=\"分享到新浪微�\�\" href=\"http://v.t.sina.com.cn/share/share.php?url=http://www.grow2up.cn/2026027.html&ralateUid=&appkey=&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&pic=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2t\" title=\"分享到腾讯微�\�\" href=\"http://v.t.qq.com/share/share.php?url=http://www.grow2up.cn/2026027.html&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&appkey=&pic=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2qzone\" title=\"分享到QQ空间\" href=\"http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=http://www.grow2up.cn/2026027.html&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&pics=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a><a class=\"share2douban\" title=\"分享到豆�\�\" href=\"http://www.douban.com/recommend/?url=http://www.grow2up.cn/2026027.html&title=%E5%AD%A9%E5%AD%90%E7%9D%A1%E5%89%8D%E5%93%AD%E9%97%B9%20%E5%90%AC%E5%93%AD%E5%A3%B0%E6%9D%A5%E6%89%BE%E5%8E%9F%E5%9B%A0&pics=http://img1.gtimg.com/baby/pics/hv1/150/204/1620/105392670.png\" rel=\"nofollow\" target=\"_blank\"></a></strong></p><p><strong><br/></strong></p><p></p><p style=\"TEXT-INDENT: 2em\"><strong>孩子哭声解读�\�</strong></p><p style=\"TEXT-INDENT: 2em\">孩子虽然不会说话，但是他们是通过哭声去诉说自己的要求。妈妈就要在平常的时候注意观察宝宝哭声的不同。当宝宝哭声非常大，洪亮有力时，其实他想说的是“妈妈，我饿了，我想睡觉”时，这个时候妈妈就要赶紧给孩子喂奶，同时让周围的环境安静下来，孩子也会在吃饱之后慢慢的进入梦乡�\�</p><p style=\"TEXT-INDENT: 2em\">当孩子哭声短促又急切时，可能是想要传达的信息是“有东西弄疼我”“我的身体好不舒服”“我身体某个部位很疼”，这个时候妈妈就要通过抚摸法去安抚孩子，轻轻抚摸一下孩子的肚子或者背。有的孩子的胎毛可能比较长比较硬，当孩子躺在床上太长时间了，这些胎毛就会刺痛孩子嫩嫩的背部导致孩子哭闹不止。当妈妈不停的抚摸孩子的背部时，孩子就会感觉很舒服，哭声就会停止�\�</p><p style=\"TEXT-INDENT: 2em\">当孩子的吃饱了睡足了但还是不停的哭闹，而这个时候的哭声可能是低沉，哭声连贯。这个时候孩子可能只是想说“我好热，我想抱”，除了哭声低沉外，孩子手心很热额头不停的出汗，同时还不停的蹬脚，妈妈们就要根据实际情况，开窗通风，降低室内温度或者给孩子换一些薄薄的衣服或盖被。有的孩子哭闹不止就是想要大人抱，想要跟大人有肌肤上面的接触。当大人一抱时，孩子自然而然的就停止的哭闹�\�</p><p style=\"TEXT-INDENT: 2em\"><strong>检查孩子哭闹法</strong></p><p style=\"TEXT-INDENT: 2em\">有一些新生儿因为生下来比较弱，哭声小，这就导致一些新手妈妈很难通过判断孩子的哭声来判断孩子到底是饿了还是累了，像这种情况，妈妈们还可以通过以下方法去找到孩子哭闹的原因：首先打开包包的衣服看是否有尿或者便便了。然后看宝宝是否饿了。看宝宝睡的是否舒服，被子底下是否有小玩具等东西影响睡眠，或者衣服绑紧了 \r\n让宝宝不舒服�\�</p><p style=\"TEXT-INDENT: 2em\">看看室内温度，太冷或者太�\� 被子太重，衣服穿的太�\� 都会影响宝宝的睡眠质�\� \r\n，宝宝不会说话，只能通过哭声表达不适； 缺乏安全感，突然到一个陌生的环境里，妈妈不在身边 孩子天生的敏感会让小孩啼哭不止。妈妈要多陪在孩子身�\� \r\n给孩子熟悉的气息�\� 错误的生活习惯。孩子白天睡觉，晚上哭闹�\� 这边白天要减少孩子的睡眠时间。多带孩子做一些简单的运动，让孩子产生疲劳。晚上自然睡的香香； \r\n若孩子半夜哭闹不停，应轻轻抱住孩子，不要用力摇晃孩子的头�\� 会造成孩子头部积液。给孩子唱首吹眠歌。让妈妈的温馨的气息围绕孩子 给孩子安全感�\�  </p><p><br/></p>', '1402802788', '0', '7', 'gh_ccbc7c79380e', '');
INSERT INTO `wp_custom_reply_news` VALUES ('67', '健康保健', '3', '小孩子误服药物家长急救原则', '', '59', '392', '<p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\"><img src=\"/Uploads/Editor/-1/2014-06-15/539d436664973.jpg\" title=\"pnsexp453775.jpg\"/></p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">小孩子本身抵抗力没有成年人强，一旦发生吃错药的情况，又往往叙述不清，是家长最着急的事情�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">一旦家长发现孩子真的误服了药物，一定切莫惊慌失措，更不要指责打骂孩子，否则孩子哭闹，更不利于说清真象，还会拖延时间。这个时候，家长要特别牢记四个处理原则：迅速排出，减少吸收，及时解毒，对症治疗�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">家长首先要尽早发现孩子吃错药的反常行为，如孩子误服安眠药或含有镇静剂的降压药，会表现出无精打采、昏昏欲睡，一旦发现此类异常，要马上检查大人用的药物是否被孩子动过。其次，家长要尽快弄清孩子误服了什么药物，服药时间大约有多久和误服的剂量有多少，及时地掌握情况�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">确认孩子吃错了药，在送医院抢救之前，应先做初步处理。催吐和更进一步的洗胃是两种主要的应急措施。催吐可用手指刺激咽部，使药物被呕吐出来，胃部内容物少者，不容易呕吐，要让其喝水，而且催吐不能套用土办法，让其喝盐水等带辛辣的汤水。一般体重一公斤给喝10~15毫升。成年者喝水后可用手指刺激舌根部引发呕吐。对于小孩，可以将孩子腹部顶在救护者的膝盖上，让头部放低。这时再将手指伸入孩子喉咙口，轻押舌根部，反复进行，直至呕吐为止。如果让孩子躺着呕吐的话，要侧卧，防止呕吐物堵塞喉咙，吐后残留在口中的呕吐物要即时清除掉�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\"><strong>鉴于误服药物不同，我们也要相应采取不同的应对措施�\�</strong></p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服一般性药物，剂量较少：如普通中成药或维生素等，可让孩子多饮凉开水，使药物稀释并及时从尿中排出�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服有毒性，或副作用大的药物，且剂量较大</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">如误服避孕药、安眠药等，则应及时送往医院治疗，切忌延误时�\�.如果情况紧急，来不及送医院，家长就必须迅速催吐，然后再喝大量茶水、肥皂水反复呕吐洗胃。催吐和洗胃后，让孩子喝几杯牛奶�\�3�\�5枚生鸡蛋清，以养胃解毒�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服了癣药水、止痒药水、驱蚊药水等外用药品</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">应立即让小孩尽量多喝浓茶水，因茶叶中含有鞣酸，具有沉淀及解毒作用�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服了有机磷农药中毒</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">呼出的气体中有一种大蒜味，可让其喝下肥皂水反复催吐解毒。同时立即送医院急救�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服腐蚀性较强药�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">具有腐蚀性的药物可引起胃穿孔，在将病人送往医院的这段时间内，要由有医疗常识的人采取相应的急救措施�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">如误服来苏儿或石碳酸</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">不宜采用催吐法。可以让孩子喝大量鸡蛋清、牛奶、稠米汤、豆浆或植物油等，上述食物可附着在食管和胃黏膜上，从而减轻消毒药水对人体的伤害�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服碘酒�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">则应饮用米汤、面汤等含淀粉的液体�\�</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">误服药物不明</p><p style=\"margin-top: 0px; margin-bottom: 20px; padding: 0px; width: 630px; line-height: 1.8em;\">可用木炭或馒头烧成炭研碎加浓茶水灌服，以吸附毒物起解毒作用�\�</p><p><br/></p>', '1402815374', '0', '0', 'gh_ccbc7c79380e', '');

-- -----------------------------
-- Table structure for `wp_custom_reply_text`
-- -----------------------------
DROP TABLE IF EXISTS `wp_custom_reply_text`;
CREATE TABLE `wp_custom_reply_text` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(255) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词类型',
  `content` text NOT NULL COMMENT '回复内容',
  `view_count` int(10) unsigned DEFAULT '0' COMMENT '浏览数',
  `sort` int(10) unsigned DEFAULT '0' COMMENT '排序号',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_diy`
-- -----------------------------
DROP TABLE IF EXISTS `wp_diy`;
CREATE TABLE `wp_diy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `url` varchar(255) NOT NULL COMMENT '访问网址',
  `is_close` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否关闭',
  `need_login` tinyint(2) NOT NULL DEFAULT '0' COMMENT '游客访问',
  `layout` text NOT NULL COMMENT '页面参数',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  `module` varchar(255) NOT NULL DEFAULT 'Diy' COMMENT '模块名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_document`
-- -----------------------------
DROP TABLE IF EXISTS `wp_document`;
CREATE TABLE `wp_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`type`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';


-- -----------------------------
-- Table structure for `wp_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `wp_document_article`;
CREATE TABLE `wp_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `wp_document_article`
-- -----------------------------
INSERT INTO `wp_document_article` VALUES ('1', '0', '<h1>\r\n	OneThink1.0正式版发�\�&nbsp;\r\n</h1>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流�\�&nbsp;</strong> \r\n</p>\r\n<h2>\r\n	主要特性：\r\n</h2>\r\n<p>\r\n	1. 基于ThinkPHP最�\�3.2版本�\�\r\n</p>\r\n<p>\r\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发�\�&nbsp;\r\n</p>\r\n<p>\r\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能�\�\r\n</p>\r\n<p>\r\n	4. 开源免费：OneThink遵循Apache2开源协�\�,免费提供使用�\�&nbsp;\r\n</p>\r\n<p>\r\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据�\�\r\n</p>\r\n<p>\r\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0�\�\r\n</p>\r\n<p>\r\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心�\�\r\n</p>\r\n<p>\r\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行�\�&nbsp;\r\n</p>\r\n<p>\r\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺�\�&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发�\�&nbsp;</strong> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<h2>\r\n	后台主要功能�\�\r\n</h2>\r\n<p>\r\n	1. 用户Passport系统\r\n</p>\r\n<p>\r\n	2. 配置管理系统&nbsp;\r\n</p>\r\n<p>\r\n	3. 权限控制系统\r\n</p>\r\n<p>\r\n	4. 后台建模系统&nbsp;\r\n</p>\r\n<p>\r\n	5. 多级分类系统&nbsp;\r\n</p>\r\n<p>\r\n	6. 用户行为系统&nbsp;\r\n</p>\r\n<p>\r\n	7. 钩子和插件系�\�\r\n</p>\r\n<p>\r\n	8. 系统日志系统&nbsp;\r\n</p>\r\n<p>\r\n	9. 数据备份和还�\�\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	&nbsp;[ 官方下载�\�&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink开发团�\� 2013</strong> \r\n</p>', '', '0');

-- -----------------------------
-- Table structure for `wp_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `wp_document_download`;
CREATE TABLE `wp_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `wp_exam`
-- -----------------------------
DROP TABLE IF EXISTS `wp_exam`;
CREATE TABLE `wp_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词类型',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `finish_tip` text NOT NULL COMMENT '结束语',
  `start_time` int(10) NOT NULL COMMENT '考试开始时间',
  `end_time` int(10) NOT NULL COMMENT '考试结束时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_exam_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_exam_answer`;
CREATE TABLE `wp_exam_answer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `answer` text NOT NULL COMMENT '回答内容',
  `openid` varchar(255) NOT NULL COMMENT 'OpenId',
  `uid` int(10) DEFAULT NULL COMMENT '用户UID',
  `question_id` int(10) unsigned NOT NULL COMMENT 'question_id',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `exam_id` int(10) unsigned NOT NULL COMMENT 'exam_id',
  `score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '得分',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=240 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_exam_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_exam_question`;
CREATE TABLE `wp_exam_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '题目标题',
  `intro` text NOT NULL COMMENT '题目描述',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `is_must` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否必填',
  `extra` text NOT NULL COMMENT '参数',
  `type` char(50) NOT NULL DEFAULT 'radio' COMMENT '题目类型',
  `exam_id` int(10) unsigned NOT NULL COMMENT 'exam_id',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  `score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分值',
  `answer` varchar(255) NOT NULL COMMENT '标准答案',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_extensions`
-- -----------------------------
DROP TABLE IF EXISTS `wp_extensions`;
CREATE TABLE `wp_extensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword_type` tinyint(2) DEFAULT '0' COMMENT '关键词类型',
  `api_token` varchar(255) NOT NULL COMMENT 'Token',
  `cTime` int(10) NOT NULL COMMENT '创建时间',
  `api_url` varchar(255) NOT NULL COMMENT '第三方URL',
  `output_format` tinyint(1) DEFAULT '0' COMMENT '数据输出格式',
  `keyword_filter` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词过滤',
  `keyword` varchar(255) NOT NULL COMMENT '关键词',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_file`
-- -----------------------------
DROP TABLE IF EXISTS `wp_file`;
CREATE TABLE `wp_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `wp_follow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_follow`;
CREATE TABLE `wp_follow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `token` varchar(255) NOT NULL COMMENT '公众号',
  `openid` varchar(255) NOT NULL COMMENT 'OpenId',
  `nickname` varchar(255) NOT NULL COMMENT '昵称',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `city` varchar(100) NOT NULL COMMENT '城市',
  `province` varchar(100) NOT NULL COMMENT '省份',
  `country` varchar(100) NOT NULL COMMENT '国家',
  `language` varchar(50) NOT NULL DEFAULT 'zh_CN' COMMENT '语言',
  `headimgurl` varchar(255) NOT NULL COMMENT '头像',
  `subscribe_time` int(10) NOT NULL COMMENT '关注时间',
  `mobile` varchar(30) NOT NULL COMMENT '手机号',
  `status` tinyint(1) DEFAULT '1' COMMENT '用户状态',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '财富值',
  `experience` int(10) NOT NULL DEFAULT '0' COMMENT '经验值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=380 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_follow`
-- -----------------------------
INSERT INTO `wp_follow` VALUES ('363', 'gh_ccbc7c79380e', 'oTsZWuNOJAnjoXJStasWFY4VKNoI', 'lipeng', '1', '', '', '', 'zh_CN', '', '1402890238', '15027158270', '3', '0', '0');
INSERT INTO `wp_follow` VALUES ('364', 'gh_ccbc7c79380e', 'oTsZWuGuBk4HnIujifJU2HliIXRU', '', '0', '', '', '', 'zh_CN', '', '1402483917', '', '1', '-10', '-10');
INSERT INTO `wp_follow` VALUES ('365', 'gh_ccbc7c79380e', 'oTsZWuGIHftATRBxGwZugNAqHv8s', '', '0', '', '', '', 'zh_CN', '', '1402794485', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('366', 'gh_ccbc7c79380e', 'oTsZWuJbkoTqSEMqfT_aZhANLxzc', '', '0', '', '', '', 'zh_CN', '', '1402541279', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('367', 'gh_ccbc7c79380e', 'oTsZWuJJRYcUbIEMw8gzbjRndC38', '', '0', '', '', '', 'zh_CN', '', '1402573687', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('368', 'gh_ccbc7c79380e', 'oTsZWuNrKNbNIXHkRo2oVrR3it4A', '', '0', '', '', '', 'zh_CN', '', '1402573982', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('369', 'gh_ccbc7c79380e', 'oTsZWuPSlInJ4qGDAkMmJmMeZp7I', '', '0', '', '', '', 'zh_CN', '', '1402575087', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('370', 'gh_ccbc7c79380e', 'oTsZWuO8Ot-eM4mXBWCqgyrUuyrY', '', '0', '', '', '', 'zh_CN', '', '1402621302', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('373', 'gh_ccbc7c79380e', 'oTsZWuPrtyT5GxIcMpfuHIe8GEmU', '', '0', '', '', '', 'zh_CN', '', '1402641428', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('374', 'gh_ccbc7c79380e', 'oTsZWuL1V3a8-64hyvBAVwlWHACs', '', '0', '', '', '', 'zh_CN', '', '1402729425', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('375', 'gh_ccbc7c79380e', 'oTsZWuEXOLwTo0dYNRrePYkGf2PA', '', '0', '', '', '', 'zh_CN', '', '1402729988', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('377', 'gh_ccbc7c79380e', 'oTsZWuOzNLvJDBzj8MJ46znKyLbU', '', '0', '', '', '', 'zh_CN', '', '1402822939', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('378', 'gh_ccbc7c79380e', 'oTsZWuLBlcRHK-6QTiJeB9XIbU8o', '', '0', '', '', '', 'zh_CN', '', '1402828770', '', '1', '0', '0');
INSERT INTO `wp_follow` VALUES ('379', 'gh_ccbc7c79380e', 'oTsZWuFBUMzLNp4ASWPQWojAF_ZY', '', '0', '', '', '', 'zh_CN', '', '1402886651', '', '1', '0', '0');

-- -----------------------------
-- Table structure for `wp_forms`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forms`;
CREATE TABLE `wp_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词类型',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `password` varchar(255) NOT NULL COMMENT '表单密码',
  `finish_tip` text NOT NULL COMMENT '用户提交后提示内容',
  `can_edit` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否允许编辑',
  `content` text NOT NULL COMMENT '详细介绍',
  `jump_url` varchar(255) NOT NULL COMMENT '提交后跳转的地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_forms_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forms_attribute`;
CREATE TABLE `wp_forms_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `name` varchar(100) NOT NULL COMMENT '字段名',
  `title` varchar(255) NOT NULL COMMENT '字段标题',
  `type` char(50) NOT NULL DEFAULT 'string' COMMENT '字段类型',
  `extra` text NOT NULL COMMENT '参数',
  `value` varchar(255) NOT NULL COMMENT '默认值',
  `remark` varchar(255) NOT NULL COMMENT '字段备注',
  `is_must` tinyint(2) NOT NULL COMMENT '是否必填',
  `validate_rule` varchar(255) NOT NULL COMMENT '正则验证',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  `error_info` varchar(255) NOT NULL COMMENT '出错提示',
  `forms_id` int(10) unsigned NOT NULL COMMENT '表单ID',
  `is_show` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_forms_value`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forms_value`;
CREATE TABLE `wp_forms_value` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(10) DEFAULT NULL COMMENT '用户ID',
  `openid` varchar(255) NOT NULL COMMENT 'OpenId',
  `forms_id` int(10) unsigned NOT NULL COMMENT '表单ID',
  `value` text NOT NULL COMMENT '表单值',
  `cTime` int(10) NOT NULL COMMENT '增加时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_forum`
-- -----------------------------
DROP TABLE IF EXISTS `wp_forum`;
CREATE TABLE `wp_forum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) DEFAULT '0' COMMENT '用户ID',
  `content` text COMMENT '内容',
  `cTime` int(10) DEFAULT NULL COMMENT '发布时间',
  `attach` varchar(255) DEFAULT NULL COMMENT '附件',
  `is_top` int(10) DEFAULT '0' COMMENT '置顶',
  `cid` tinyint(4) DEFAULT NULL COMMENT '分类',
  `view_count` int(11) unsigned DEFAULT '0' COMMENT '浏览数',
  `reply_count` int(11) unsigned DEFAULT '0' COMMENT '回复数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `wp_hooks`;
CREATE TABLE `wp_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `搜索索引` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_hooks`
-- -----------------------------
INSERT INTO `wp_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代�\�', '1', '0', '');
INSERT INTO `wp_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop,BaiduStatistics');
INSERT INTO `wp_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单�\� 扩展内容钩子', '1', '0', 'Attachment');
INSERT INTO `wp_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment');
INSERT INTO `wp_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `wp_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment');
INSERT INTO `wp_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩�\�', '1', '0', 'Editor');
INSERT INTO `wp_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `wp_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `wp_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子�\�', '1', '1380163518', 'Editor');
INSERT INTO `wp_hooks` VALUES ('16', 'app_begin', '应用开�\�', '2', '1384481614', '');
INSERT INTO `wp_hooks` VALUES ('17', 'weixin', '微信插件必须加载的钩�\�', '1', '1388810858', 'Vote,Chat,Wecome,UserCenter,HelloWorld,Robot,Suggestions,Extensions,Card,WeiSite,Hitegg,Leaflets,Xydzp,CustomReply,Forms,Survey,Exam,Test,Diy,Shop,CustomMenu,Coupon,Scratch,Juhe,Tongji,MicroCatering');
INSERT INTO `wp_hooks` VALUES ('18', 'cascade', '级联菜单', '1', '1398694587', 'Cascade');
INSERT INTO `wp_hooks` VALUES ('19', 'page_diy', '万能页面的钩�\�', '1', '1399040364', 'Diy');

-- -----------------------------
-- Table structure for `wp_keyword`
-- -----------------------------
DROP TABLE IF EXISTS `wp_keyword`;
CREATE TABLE `wp_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `token` varchar(100) NOT NULL COMMENT 'Token',
  `addon` varchar(255) NOT NULL COMMENT '关键词所属插件',
  `aim_id` int(10) unsigned NOT NULL COMMENT '插件表里的ID值',
  `cTime` int(10) NOT NULL COMMENT '创建时间',
  `keyword_length` int(10) unsigned DEFAULT '0' COMMENT '关键词长度',
  `keyword_type` tinyint(2) DEFAULT '0' COMMENT '匹配类型',
  `extra_text` text COMMENT '文本扩展',
  `extra_int` int(10) DEFAULT NULL COMMENT '数字扩展',
  `request_count` int(10) NOT NULL DEFAULT '0' COMMENT '请求数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyword_token` (`keyword`,`token`)
) ENGINE=MyISAM AUTO_INCREMENT=490 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_keyword`
-- -----------------------------
INSERT INTO `wp_keyword` VALUES ('458', 'test', '539811ab60f21', 'WeiSite', '51', '1402481227', '4', '1', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('459', 'test', 'gh_ccbc7c79380e', 'WeiSite', '52', '1402483947', '4', '1', 'custom_reply_news', '0', '3');
INSERT INTO `wp_keyword` VALUES ('462', 'hello', 'gh_ccbc7c79380e', 'CustomReply', '53', '1402544699', '5', '0', 'custom_reply_news', '0', '2');
INSERT INTO `wp_keyword` VALUES ('463', '1', 'gh_ccbc7c79380e', 'Exam', '9', '1402579559', '1', '0', '', '0', '0');
INSERT INTO `wp_keyword` VALUES ('464', '首页', 'gh_ccbc7c79380e', 'CustomReply', '54', '1402625530', '6', '3', 'custom_reply_news', '0', '5');
INSERT INTO `wp_keyword` VALUES ('470', '学前教育', 'gh_ccbc7c79380e', 'WeiSite', '55', '1402667317', '12', '3', 'custom_reply_news', '0', '8');
INSERT INTO `wp_keyword` VALUES ('469', '网站', 'gh_ccbc7c79380e', 'CustomReply', '55', '1402664193', '6', '0', 'custom_reply_news', '0', '1');
INSERT INTO `wp_keyword` VALUES ('489', '饮食帮助�\�', 'gh_ccbc7c79380e', 'WeiSite', '57', '1402881498', '15', '3', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('488', '母乳存留也能做宝宝辅�\�', 'gh_ccbc7c79380e', 'WeiSite', '58', '1402881448', '33', '3', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('487', '健康零食', 'gh_ccbc7c79380e', 'WeiSite', '59', '1402881427', '12', '3', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('474', '健康保健宝宝', 'gh_ccbc7c79380e', 'WeiSite', '60', '1402800612', '18', '3', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('475', '亲子游戏', 'gh_ccbc7c79380e', 'WeiSite', '61', '1402801157', '12', '3', 'custom_reply_news', '0', '5');
INSERT INTO `wp_keyword` VALUES ('477', '健康宝贝', 'gh_ccbc7c79380e', 'WeiSite', '62', '1402801475', '12', '3', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('486', '健康完全营养饮食', 'gh_ccbc7c79380e', 'WeiSite', '63', '1402881353', '24', '3', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('479', '健康保健', 'gh_ccbc7c79380e', 'WeiSite', '56', '1402801761', '12', '3', 'custom_reply_news', '0', '10');
INSERT INTO `wp_keyword` VALUES ('481', '教育', 'gh_ccbc7c79380e', 'WeiSite', '65', '1402802788', '6', '3', 'custom_reply_news', '0', '6');
INSERT INTO `wp_keyword` VALUES ('483', '微信', 'gh_ccbc7c79380e', 'CustomReply', '66', '1402812699', '6', '0', 'custom_reply_news', '0', '0');
INSERT INTO `wp_keyword` VALUES ('485', 'ttest', 'gh_ccbc7c79380e', 'CustomReply', '69', '1402821763', '5', '0', 'custom_reply_news', '0', '0');

-- -----------------------------
-- Table structure for `wp_member`
-- -----------------------------
DROP TABLE IF EXISTS `wp_member`;
CREATE TABLE `wp_member` (
  `uid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `nickname` varchar(100) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `public_count` smallint(4) DEFAULT NULL,
  `extra_field` text,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `wp_member`
-- -----------------------------
INSERT INTO `wp_member` VALUES ('1', 'joint4', '0', '0000-00-00', '', '0', '35', '0', '1402479145', '454301311', '1402892369', '1', '', '');
INSERT INTO `wp_member` VALUES ('371', 'xxkxxk831', '0', '0000-00-00', '', '0', '3', '454333053', '1402639285', '454301311', '1402795674', '1', '', '');

-- -----------------------------
-- Table structure for `wp_member_public`
-- -----------------------------
DROP TABLE IF EXISTS `wp_member_public`;
CREATE TABLE `wp_member_public` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(10) DEFAULT NULL COMMENT '用户ID',
  `public_name` varchar(50) NOT NULL COMMENT '公众号名称',
  `public_id` varchar(100) NOT NULL COMMENT '公众号原始id',
  `wechat` varchar(100) NOT NULL COMMENT '微信号',
  `interface_url` varchar(255) NOT NULL COMMENT '接口地址',
  `headface_url` varchar(255) NOT NULL COMMENT '公众号头像',
  `area` varchar(50) NOT NULL COMMENT '地区',
  `addon_config` text NOT NULL COMMENT '插件配置',
  `addon_status` text NOT NULL COMMENT '插件状态',
  `token` varchar(100) NOT NULL COMMENT 'Token',
  `is_use` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否为当前公众号',
  `type` char(10) NOT NULL DEFAULT '0' COMMENT '公众号类型',
  `appid` varchar(255) NOT NULL COMMENT 'AppId',
  `secret` varchar(255) NOT NULL COMMENT 'Secret',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_member_public`
-- -----------------------------
INSERT INTO `wp_member_public` VALUES ('106', '363', '酷珠儿童成长学堂', 'gh_ccbc7c79380e', 'czxt001', '', '365', '', '{\"WeiSite\":{\"title\":\"\\u70b9\\u51fb\\u8fdb\\u5165\\u9996\\u9875\",\"cover\":\"365\",\"info\":\"123\",\"background\":\"\",\"code\":\"\",\"template_index\":\"StyleV1\",\"template_footer\":\"V1\",\"template_lists\":\"V4\",\"template_detail\":\"V1\",\"cover_url\":\"http:\\/\\/joint4.xicp.net\\/Uploads\\/Picture\\/2014-06-11\\/539822745fab7.jpg\"},\"Wecome\":{\"type\":\"1\",\"title\":\"\\u6b22\\u8fce\\u6765\\u5230\\u9177\\u73e0\\u513f\\u7ae5\\u6210\\u957f\\u5b66\\u5802\\u7684\\u5fae\\u5b98\\u7f51\",\"description\":\"\\u6b22\\u8fce\\u6765\\u5230\\u9177\\u73e0\\u513f\\u7ae5\\u6210\\u957f\\u5b66\\u5802\\uff01\\r\\n\",\"pic_url\":\"http:\\/\\/joint4.xicp.net\\/Uploads\\/Editor\\/-1\\/\\/2014-06-13\\/539a4de73c556.gif\",\"url\":\"[website]\"},\"UserCenter\":{\"need_bind\":\"0\",\"bind_start\":\"0\",\"jumpurl\":\"\"},\"Leaflets\":{\"title\":\"\\u9177\\u73e0\\u5b98\\u65b9\\u5fae\\u4fe1\\u516c\\u4f17\\u53f7\",\"img\":\"368\",\"info\":\"\\u4eba\\u751f\\u90fd\\u8981\\u7ecf\\u5386\\u5b9d\\u5b9d\\uff0c\\u513f\\u7ae5\\uff0c\\u5c11\\u5e74\\u8fd9\\u51e0\\u4e2a\\u9636\\u6bb5\\uff0c\\u5728\\u6210\\u957f\\u7684\\u8fc7\\u7a0b\\u4e2d\\u4f1a\\u78b0\\u5230\\u5f88\\u591a\\u4e8b\\u60c5\\uff0c\\u8863\\u98df\\u4f4f\\u884c\\uff0c\\u6709\\u7684\\u5c0f\\u5b69\\u4e0d\\u7231\\u5b66\\u4e60\\uff0c\\u4e0d\\u542c\\u8bdd\\u7b49\\u7b49\\uff0c\\u5c0f\\u592a\\u9633\\u6210\\u957f\\u5b66\\u5802\\u4f1a\\u6559\\u5bb6\\u957f\\u600e\\u6837\\u53bb\\u6559\\u5bfc\\u548c\\u5f15\\u5bfc\\u5b69\\u5b50\\u53bb\\u9002\\u5e94\\u4ee5\\u540e\\u7684\\u751f\\u6d3b\\u3002\",\"copyright\":\"\\u00a92001-2013 WeiPHP\\u5b98\\u65b9\\u5fae\\u4fe1\\u516c\\u4f17\\u53f7\\u7248\\u6743\\u6240\\u6709\"},\"Card\":{\"background\":\"1\",\"bg\":\"\",\"title\":\"\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97VIP\\u4f1a\\u5458\\u5361\",\"length\":\"80001\",\"instruction\":\"1\\u3001\\u606d\\u559c\\u60a8\\u6210\\u4e3a\\u9177\\u73e0\\u513f\\u7ae5\\u6210\\u957f\\u5b66\\u5802VIP\\u4f1a\\u5458;\\r\\n2\\u3001\\u7ed3\\u8d26\\u65f6\\u8bf7\\u51fa\\u793a\\u6b64\\u5361\\uff0c\\u51ed\\u6b64\\u5361\\u53ef\\u4eab\\u53d7\\u4f1a\\u5458\\u4f18\\u60e0;\\r\\n3\\u3001\\u6b64\\u5361\\u6700\\u7ec8\\u89e3\\u91ca\\u6743\\u5f52\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97\\u6240\\u6709\",\"address\":\"\",\"phone\":\"\",\"url\":\"\",\"background_custom\":\"\"}}', '{\"Extensions\":1}', 'gh_ccbc7c79380e', '0', '0', 'wx5dcf60f7da5f7d29', '4198d273a7af651ff6b0b224dd89fda6', '0');
INSERT INTO `wp_member_public` VALUES ('107', '363', '', '', '', '', '', '', '{\"UserCenter\":{\"need_bind\":\"1\",\"bind_start\":\"0\",\"jumpurl\":\"\"},\"WeiSite\":{\"title\":\"\\u70b9\\u51fb\\u8fdb\\u5165\\u9996\\u9875\",\"cover\":\"\",\"info\":\"\",\"background\":\"\",\"code\":\"\",\"template_index\":\"ColorV2\",\"template_footer\":\"V1\",\"template_lists\":\"V4\",\"template_detail\":\"V1\",\"cover_url\":\"\"}}', '', '539811ab60f21', '0', '0', '', '', '0');
INSERT INTO `wp_member_public` VALUES ('108', '1', '酷珠儿童成长学堂', 'gh_ccbc7c79380e', 'czxt001', '', '365', '', '{\"WeiSite\":{\"title\":\"\\u70b9\\u51fb\\u8fdb\\u5165\\u9996\\u9875\",\"cover\":\"365\",\"info\":\"123\",\"background\":\"\",\"code\":\"\",\"template_index\":\"StyleV1\",\"template_footer\":\"V1\",\"template_lists\":\"V4\",\"template_detail\":\"V1\",\"cover_url\":\"http:\\/\\/joint4.xicp.net\\/Uploads\\/Picture\\/2014-06-11\\/539822745fab7.jpg\"},\"Wecome\":{\"type\":\"1\",\"title\":\"\\u6b22\\u8fce\\u6765\\u5230\\u9177\\u73e0\\u513f\\u7ae5\\u6210\\u957f\\u5b66\\u5802\\u7684\\u5fae\\u5b98\\u7f51\",\"description\":\"\\u6b22\\u8fce\\u6765\\u5230\\u9177\\u73e0\\u513f\\u7ae5\\u6210\\u957f\\u5b66\\u5802\\uff01\\r\\n\",\"pic_url\":\"http:\\/\\/joint4.xicp.net\\/Uploads\\/Editor\\/-1\\/\\/2014-06-13\\/539a4de73c556.gif\",\"url\":\"[website]\"},\"UserCenter\":{\"need_bind\":\"0\",\"bind_start\":\"0\",\"jumpurl\":\"\"},\"Leaflets\":{\"title\":\"\\u9177\\u73e0\\u5b98\\u65b9\\u5fae\\u4fe1\\u516c\\u4f17\\u53f7\",\"img\":\"368\",\"info\":\"\\u4eba\\u751f\\u90fd\\u8981\\u7ecf\\u5386\\u5b9d\\u5b9d\\uff0c\\u513f\\u7ae5\\uff0c\\u5c11\\u5e74\\u8fd9\\u51e0\\u4e2a\\u9636\\u6bb5\\uff0c\\u5728\\u6210\\u957f\\u7684\\u8fc7\\u7a0b\\u4e2d\\u4f1a\\u78b0\\u5230\\u5f88\\u591a\\u4e8b\\u60c5\\uff0c\\u8863\\u98df\\u4f4f\\u884c\\uff0c\\u6709\\u7684\\u5c0f\\u5b69\\u4e0d\\u7231\\u5b66\\u4e60\\uff0c\\u4e0d\\u542c\\u8bdd\\u7b49\\u7b49\\uff0c\\u5c0f\\u592a\\u9633\\u6210\\u957f\\u5b66\\u5802\\u4f1a\\u6559\\u5bb6\\u957f\\u600e\\u6837\\u53bb\\u6559\\u5bfc\\u548c\\u5f15\\u5bfc\\u5b69\\u5b50\\u53bb\\u9002\\u5e94\\u4ee5\\u540e\\u7684\\u751f\\u6d3b\\u3002\",\"copyright\":\"\\u00a92001-2013 WeiPHP\\u5b98\\u65b9\\u5fae\\u4fe1\\u516c\\u4f17\\u53f7\\u7248\\u6743\\u6240\\u6709\"},\"Card\":{\"background\":\"1\",\"bg\":\"\",\"title\":\"\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97VIP\\u4f1a\\u5458\\u5361\",\"length\":\"80001\",\"instruction\":\"1\\u3001\\u606d\\u559c\\u60a8\\u6210\\u4e3a\\u9177\\u73e0\\u513f\\u7ae5\\u6210\\u957f\\u5b66\\u5802VIP\\u4f1a\\u5458;\\r\\n2\\u3001\\u7ed3\\u8d26\\u65f6\\u8bf7\\u51fa\\u793a\\u6b64\\u5361\\uff0c\\u51ed\\u6b64\\u5361\\u53ef\\u4eab\\u53d7\\u4f1a\\u5458\\u4f18\\u60e0;\\r\\n3\\u3001\\u6b64\\u5361\\u6700\\u7ec8\\u89e3\\u91ca\\u6743\\u5f52\\u65f6\\u5c1a\\u7f8e\\u5bb9\\u7f8e\\u53d1\\u5e97\\u6240\\u6709\",\"address\":\"\",\"phone\":\"\",\"url\":\"\",\"background_custom\":\"\"}}', '{\"Extensions\":1}', 'gh_ccbc7c79380e', '0', '0', '', '', '0');

-- -----------------------------
-- Table structure for `wp_member_public_group`
-- -----------------------------
DROP TABLE IF EXISTS `wp_member_public_group`;
CREATE TABLE `wp_member_public_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(50) NOT NULL COMMENT '等级名',
  `addon_status` text NOT NULL COMMENT '插件权限',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_member_public_group`
-- -----------------------------
INSERT INTO `wp_member_public_group` VALUES ('5', '等级1', '');

-- -----------------------------
-- Table structure for `wp_member_public_link`
-- -----------------------------
DROP TABLE IF EXISTS `wp_member_public_link`;
CREATE TABLE `wp_member_public_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(10) DEFAULT NULL COMMENT '管理员UID',
  `mp_id` int(10) unsigned NOT NULL COMMENT '公众号ID',
  `is_creator` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否为创建者',
  `addon_status` text NOT NULL COMMENT '插件权限',
  `is_use` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否为当前管理的公众号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `um` (`uid`,`mp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_member_public_link`
-- -----------------------------
INSERT INTO `wp_member_public_link` VALUES ('114', '363', '106', '1', '', '1');
INSERT INTO `wp_member_public_link` VALUES ('115', '1', '108', '1', '', '1');

-- -----------------------------
-- Table structure for `wp_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wp_menu`;
CREATE TABLE `wp_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_menu`
-- -----------------------------
INSERT INTO `wp_menu` VALUES ('1', '首页', '0', '0', 'Index/index', '1', '', '', '1');
INSERT INTO `wp_menu` VALUES ('2', '内容', '0', '2', 'Article/mydocument', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0');
INSERT INTO `wp_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('6', '改变状�\�', '3', '0', 'article/setStatus', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('13', '回收�\�', '2', '0', 'article/recycle', '1', '', '内容', '0');
INSERT INTO `wp_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('16', '用户', '0', '2', 'User/index', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0');
INSERT INTO `wp_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0');
INSERT INTO `wp_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0');
INSERT INTO `wp_menu` VALUES ('23', '变更行为状�\�', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0');
INSERT INTO `wp_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0');
INSERT INTO `wp_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0');
INSERT INTO `wp_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '1', '', '用户管理', '0');
INSERT INTO `wp_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0');
INSERT INTO `wp_menu` VALUES ('33', '保存用户�\�', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组�\�\"保存\"按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0');
INSERT INTO `wp_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表�\�\"授权\"时的\"保存\"按钮�\�\"成员授权\"里右上角�\�\"添加\"按钮)', '', '0');
INSERT INTO `wp_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面�\�\"保存\"按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面�\�\"保存\"按钮', '', '0');
INSERT INTO `wp_menu` VALUES ('43', '插件管理', '0', '7', 'Addons/weixin', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0');
INSERT INTO `wp_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0');
INSERT INTO `wp_menu` VALUES ('46', '检测创�\�', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('48', '快速生成插�\�', '44', '0', 'Addons/build', '0', '开始生成插件结�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0');
INSERT INTO `wp_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0');
INSERT INTO `wp_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0');
INSERT INTO `wp_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0');
INSERT INTO `wp_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0');
INSERT INTO `wp_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0');
INSERT INTO `wp_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('57', '钩子管理', '43', '3', 'Addons/hooks', '0', '', '扩展', '0');
INSERT INTO `wp_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('59', '新增', '58', '0', 'model/add', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('61', '改变状�\�', '58', '0', 'model/setStatus', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('63', '属性管�\�', '68', '0', 'Attribute/index', '1', '网站属性配置�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('66', '改变状�\�', '63', '0', 'Attribute/setStatus', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('68', '系统', '0', '1', 'Config/group', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0');
INSERT INTO `wp_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0');
INSERT INTO `wp_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0');
INSERT INTO `wp_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '1', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '1', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0');
INSERT INTO `wp_menu` VALUES ('86', '备份数据�\�', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0');
INSERT INTO `wp_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('88', '优化�\�', '86', '0', 'Database/optimize', '0', '优化数据�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('89', '修复�\�', '86', '0', 'Database/repair', '0', '修复数据�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('90', '还原数据�\�', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0');
INSERT INTO `wp_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢�\�', '', '0');
INSERT INTO `wp_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0');
INSERT INTO `wp_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `wp_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0');
INSERT INTO `wp_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0');
INSERT INTO `wp_menu` VALUES ('124', '微信插件', '43', '0', 'admin/addons/weixin', '0', '', '扩展', '0');
INSERT INTO `wp_menu` VALUES ('126', '公众号等�\�', '16', '0', 'admin/PublicGroup/PublicGroup', '0', '', '公众号管�\�', '0');
INSERT INTO `wp_menu` VALUES ('127', '公众号管�\�', '16', '1', 'admin/PublicGroup/PublicAdmin', '0', '', '公众号管�\�', '0');
INSERT INTO `wp_menu` VALUES ('128', '在线升级', '68', '5', 'admin/update/index', '0', '', '系统设置', '0');
INSERT INTO `wp_menu` VALUES ('129', '清除缓存', '68', '10', 'admin/Update/delcache', '0', '', '系统设置', '0');

-- -----------------------------
-- Table structure for `wp_ml_microcatering_discount_type`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_discount_type`;
CREATE TABLE `wp_ml_microcatering_discount_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ismain` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否为主要',
  `name` varchar(255) NOT NULL COMMENT '优惠分类名称',
  `state` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `dishesdatas` text NOT NULL COMMENT '菜品id和优惠价格序列化数据',
  `paixu` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `setid` int(10) NOT NULL COMMENT '餐厅id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_ml_microcatering_dishes`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_dishes`;
CREATE TABLE `wp_ml_microcatering_dishes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `paixu` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `state` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `review_count` int(10) NOT NULL DEFAULT '0' COMMENT '评论数量',
  `icon` int(10) unsigned NOT NULL COMMENT ' 菜品封面 ',
  `dishes_num` varchar(255) NOT NULL COMMENT '菜品编号',
  `price` varchar(255) NOT NULL COMMENT '价格',
  `introduction` text NOT NULL COMMENT '菜品简介',
  `name` varchar(255) NOT NULL COMMENT '菜品名称',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `youhuiid` int(10) NOT NULL DEFAULT '0' COMMENT '优惠id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_ml_microcatering_dishes_type`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_dishes_type`;
CREATE TABLE `wp_ml_microcatering_dishes_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `paixu` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `pic` int(10) unsigned NOT NULL COMMENT '菜系图片',
  `name` varchar(255) NOT NULL COMMENT '菜系名称',
  `state` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `setid` int(10) NOT NULL COMMENT '关联的餐厅id',
  `dishesdatas` text NOT NULL COMMENT '菜品集合',
  `introduction` text NOT NULL COMMENT '简介',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wp_ml_microcatering_dishes_type`
-- -----------------------------
INSERT INTO `wp_ml_microcatering_dishes_type` VALUES ('91', '0', '372', '川菜', '0', '4', 'N;', '<p>麻辣是特�\�</p>', 'gh_3ee44a31f642');
INSERT INTO `wp_ml_microcatering_dishes_type` VALUES ('92', '0', '375', '粤菜55', '0', '4', 'a:1:{i:0;s:2:\"13\";}', '<p>清炖</p>', 'gh_3ee44a31f642');
INSERT INTO `wp_ml_microcatering_dishes_type` VALUES ('93', '0', '372', '川菜', '0', '5', 'N;', '<p>麻辣是特�\�</p>', 'gh_3ee44a31f642');
INSERT INTO `wp_ml_microcatering_dishes_type` VALUES ('94', '0', '375', '粤菜22', '0', '5', 'a:1:{i:0;s:2:\"13\";}', '<p>清炖</p>', 'gh_3ee44a31f642');

-- -----------------------------
-- Table structure for `wp_ml_microcatering_order`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_order`;
CREATE TABLE `wp_ml_microcatering_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tablemanage_id` int(10) NOT NULL COMMENT '关联的餐位编号',
  `endtime` varchar(255) NOT NULL COMMENT '过期时间',
  `zftype` char(50) NOT NULL DEFAULT '0' COMMENT '支付方式',
  `price` varchar(255) NOT NULL COMMENT '点餐原总价',
  `yhprice` varchar(255) NOT NULL COMMENT '优惠后的总价',
  `openid` varchar(255) NOT NULL COMMENT '关联的微信用户id',
  `dishes_count_datas` text NOT NULL COMMENT '点餐的菜品数量序列化数据',
  `set_id` int(10) NOT NULL COMMENT '关联的餐厅id',
  `statekz` char(50) NOT NULL DEFAULT '0' COMMENT '状态扩展',
  `dcnum` varchar(255) NOT NULL COMMENT '点餐单号',
  `state` char(50) NOT NULL DEFAULT '0' COMMENT '状态',
  `diningtypes` char(50) NOT NULL DEFAULT '0' COMMENT '点餐类型',
  `beizhu` text NOT NULL COMMENT '备注',
  `cpcount` int(10) NOT NULL DEFAULT '0' COMMENT '菜品总数量',
  `ctime` varchar(255) NOT NULL COMMENT '创建时间',
  `jctime` varchar(255) NOT NULL COMMENT '就餐时间',
  `contactid` int(10) NOT NULL COMMENT '关联的联系id',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wp_ml_microcatering_order`
-- -----------------------------
INSERT INTO `wp_ml_microcatering_order` VALUES ('14', '5', '14-06-09 18:02:29', '0', '', '68', 'owYXBjtoBtTAx_4hxSptaUTCawUQ', 'a:1:{i:13;a:12:{s:2:\"id\";s:2:\"13\";s:5:\"token\";s:15:\"gh_3ee44a31f642\";s:4:\"name\";s:9:\"油辣�\�\";s:10:\"dishes_num\";s:3:\"001\";s:4:\"icon\";s:3:\"372\";s:12:\"introduction\";s:16:\"<p>非常�\�</p>\";s:5:\"price\";s:2:\"17\";s:12:\"review_count\";s:1:\"0\";s:5:\"paixu\";s:1:\"0\";s:5:\"state\";s:1:\"0\";s:8:\"youhuiid\";s:1:\"0\";s:3:\"num\";i:4;}}', '4', '0', '2014060253531019', '0', '1', '', '4', '14-06-02 18:02:29', '2014-06-02 7:00:00', '2', 'gh_3ee44a31f642');
INSERT INTO `wp_ml_microcatering_order` VALUES ('15', '0', '14-06-15 13:27:06', '0', '', '238', '-1', 'a:1:{i:13;a:12:{s:2:\"id\";s:2:\"13\";s:5:\"token\";s:15:\"gh_3ee44a31f642\";s:4:\"name\";s:9:\"油辣�\�\";s:10:\"dishes_num\";s:3:\"001\";s:4:\"icon\";s:3:\"372\";s:12:\"introduction\";s:16:\"<p>非常�\�</p>\";s:5:\"price\";s:2:\"17\";s:12:\"review_count\";s:1:\"0\";s:5:\"paixu\";s:1:\"0\";s:5:\"state\";s:1:\"0\";s:8:\"youhuiid\";s:1:\"0\";s:3:\"num\";i:14;}}', '4', '6', '2014060897515151', '0', '1', '', '14', '14-06-08 13:27:06', '2014-06-08 3:00:00', '3', 'gh_3ee44a31f642');
INSERT INTO `wp_ml_microcatering_order` VALUES ('16', '5', '14-06-15 14:54:46', '0', '', '153', '-1', 'a:1:{i:13;a:12:{s:2:\"id\";s:2:\"13\";s:5:\"token\";s:15:\"gh_3ee44a31f642\";s:4:\"name\";s:9:\"油辣�\�\";s:10:\"dishes_num\";s:3:\"001\";s:4:\"icon\";s:3:\"372\";s:12:\"introduction\";s:16:\"<p>非常�\�</p>\";s:5:\"price\";s:2:\"17\";s:12:\"review_count\";s:1:\"0\";s:5:\"paixu\";s:1:\"0\";s:5:\"state\";s:1:\"0\";s:8:\"youhuiid\";s:1:\"0\";s:3:\"num\";i:9;}}', '4', '0', '2014060854484856', '0', '0', '', '9', '14-06-08 14:54:46', '2014-06-08 1:00:00', '3', 'gh_3ee44a31f642');
INSERT INTO `wp_ml_microcatering_order` VALUES ('17', '5', '14-06-15 15:21:12', '0', '', '153', '-1', 'a:1:{i:13;a:12:{s:2:\"id\";s:2:\"13\";s:5:\"token\";s:15:\"gh_3ee44a31f642\";s:4:\"name\";s:9:\"油辣�\�\";s:10:\"dishes_num\";s:3:\"001\";s:4:\"icon\";s:3:\"372\";s:12:\"introduction\";s:16:\"<p>非常�\�</p>\";s:5:\"price\";s:2:\"17\";s:12:\"review_count\";s:1:\"0\";s:5:\"paixu\";s:1:\"0\";s:5:\"state\";s:1:\"0\";s:8:\"youhuiid\";s:1:\"0\";s:3:\"num\";i:9;}}', '4', '2', '2014060856505410', '1', '0', '', '9', '14-06-08 15:21:12', '2014-06-08 1:00:00', '3', 'gh_3ee44a31f642');

-- -----------------------------
-- Table structure for `wp_ml_microcatering_order_temp`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_order_temp`;
CREATE TABLE `wp_ml_microcatering_order_temp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `setid` int(10) NOT NULL COMMENT '餐厅id',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `openid` varchar(255) NOT NULL COMMENT '用户id',
  `cpid` int(10) NOT NULL COMMENT '菜品id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_ml_microcatering_review`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_review`;
CREATE TABLE `wp_ml_microcatering_review` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `plcontent` text NOT NULL COMMENT '评论内容',
  `pltime` int(10) NOT NULL COMMENT '评论时间',
  `hftime` int(10) NOT NULL COMMENT '回复时间',
  `hfcontent` text NOT NULL COMMENT '回复内容',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '评论类型',
  `openid` varchar(255) NOT NULL COMMENT '关联的用户id',
  `set_id` int(10) NOT NULL COMMENT '关联的餐厅id',
  `dishes_id` int(10) NOT NULL COMMENT '关联的菜品id或者关联的桌台id',
  `pingji` int(10) NOT NULL DEFAULT '3' COMMENT '菜品评级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_ml_microcatering_scheduledtask`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_scheduledtask`;
CREATE TABLE `wp_ml_microcatering_scheduledtask` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `fenz` varchar(255) NOT NULL DEFAULT '*' COMMENT '每分',
  `xiaos` varchar(255) NOT NULL DEFAULT '*' COMMENT '每时',
  `yue` varchar(255) NOT NULL DEFAULT '*' COMMENT '每月',
  `day` varchar(255) NOT NULL DEFAULT '*' COMMENT '每日',
  `zhou` varchar(255) NOT NULL DEFAULT '*' COMMENT '每周',
  `starttime_endtime` text NOT NULL COMMENT '开始和结束时间的序列化数据',
  `state` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `upruntime` int(10) NOT NULL COMMENT '上次执行时间',
  `downruntime` int(10) NOT NULL COMMENT '下次任务执行时间',
  `title` text NOT NULL COMMENT '任务名称',
  `type` int(10) NOT NULL DEFAULT '0' COMMENT '任务类型',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_ml_microcatering_set`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_set`;
CREATE TABLE `wp_ml_microcatering_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `token` varchar(255) NOT NULL COMMENT ' Token ',
  `keyword` varchar(255) NOT NULL COMMENT ' 关键词 ',
  `intro` text NOT NULL COMMENT '封面简介',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `kfname` varchar(255) NOT NULL COMMENT '客服名称',
  `TemplateIndex` varchar(255) NOT NULL DEFAULT 'default' COMMENT '模板编号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_ml_microcatering_tablemanage`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_tablemanage`;
CREATE TABLE `wp_ml_microcatering_tablemanage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ztnum` varchar(255) NOT NULL COMMENT '桌台编号',
  `setid` int(10) NOT NULL COMMENT '餐厅id',
  `paixu` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `ztdes` text NOT NULL COMMENT '餐位简介',
  `state` char(50) NOT NULL DEFAULT '0' COMMENT '状态',
  `yongccount` int(10) NOT NULL COMMENT '用餐人数',
  `zttype` varchar(255) NOT NULL DEFAULT '0' COMMENT '餐位类型',
  `ztname` varchar(255) NOT NULL COMMENT '餐位或包间名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wp_ml_microcatering_tablemanage`
-- -----------------------------
INSERT INTO `wp_ml_microcatering_tablemanage` VALUES ('5', '01', '4', '0', 'gh_3ee44a31f642', '<p>只有这个</p>', '0', '6', '1', '国色甜香');

-- -----------------------------
-- Table structure for `wp_ml_microcatering_users`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_users`;
CREATE TABLE `wp_ml_microcatering_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `address` varchar(555) NOT NULL COMMENT '联系地址',
  `truename` varchar(255) NOT NULL COMMENT '用户名称',
  `tel` varchar(255) NOT NULL COMMENT '联系电话',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `openid` varchar(255) NOT NULL COMMENT '微信id',
  `isdefault` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否默认',
  `set_id` int(10) NOT NULL COMMENT '餐厅id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wp_ml_microcatering_users`
-- -----------------------------
INSERT INTO `wp_ml_microcatering_users` VALUES ('1', '123', '张三', '13400000000', 'gh_3ee44a31f642', '-1', '0', '2');
INSERT INTO `wp_ml_microcatering_users` VALUES ('2', '特三个月', '张三', '13438109388', 'gh_3ee44a31f642', 'owYXBjtoBtTAx_4hxSptaUTCawUQ', '0', '4');
INSERT INTO `wp_ml_microcatering_users` VALUES ('3', '123', '333', '13400000000', 'gh_3ee44a31f642', '-1', '0', '4');

-- -----------------------------
-- Table structure for `wp_ml_microcatering_yuyuemanage`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ml_microcatering_yuyuemanage`;
CREATE TABLE `wp_ml_microcatering_yuyuemanage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `yycount` int(10) NOT NULL COMMENT '预约人数',
  `sex` int(10) NOT NULL DEFAULT '0' COMMENT '预约人性别',
  `usermobile` varchar(255) NOT NULL COMMENT '预约人电话',
  `username` varchar(255) NOT NULL COMMENT '预约人姓名',
  `openid` varchar(255) NOT NULL COMMENT '关联微信用户id',
  `tablemanage_id` int(10) NOT NULL COMMENT '桌台编号',
  `set_id` int(10) NOT NULL COMMENT '关联的餐厅编号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `wp_model`
-- -----------------------------
DROP TABLE IF EXISTS `wp_model`;
CREATE TABLE `wp_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `wp_model`
-- -----------------------------
INSERT INTO `wp_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"uid\",\"name\",\"title\",\"category_id\",\"description\",\"root\",\"pid\",\"model_id\",\"type\",\"position\",\"link_id\",\"cover_id\",\"display\",\"deadline\",\"attach\",\"view\",\"comment\",\"extend\",\"level\",\"create_time\",\"update_time\",\"status\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:标题:article/index?cate_id=[category_id]&pid=[id]\r\ntype|get_document_type:类型\r\nlevel:优先�\�\r\nupdate_time|time_format:最后更�\�\r\nstatus_text:状�\�\r\nview:浏览\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":{\"1\":\"content\"}}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题:article/edit?cate_id=[category_id]&id=[id]\r\ncontent:内容', '0', '', '', '1383891243', '1388921230', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('6', 'vote', '投票', '0', '', '1', '{\"1\":[\"keyword\",\"title\",\"description\",\"picurl\",\"type\",\"start_date\",\"end_date\"]}', '1:基础', '', '', '', '', 'id:投票ID\r\nkeyword:关键�\�\r\ntitle:投票标题\r\ntype|get_name_by_status:类型\r\nis_img|get_name_by_status:状�\�\r\nvote_count:投票�\�\r\nids:操作:show&id=[id]|预览,[EDIT]&id=[id]|编辑,[DELETE]|删除', '20', 'title', 'description', '1388930292', '1401017026', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":{\"1\":\"content\",\"2\":\"file_id\",\"3\":\"size\",\"6\":\"download\"},\"2\":{\"2\":\"parse\",\"11\":\"template\"}}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('5', 'keyword', '关键词表', '0', '', '1', '{\"1\":[\"keyword\",\"addon\",\"aim_id\",\"cTime\"]}', '1:基础', '', '', '', '', 'id:编号\r\nkeyword:关键�\�\r\naddon:所属插�\�\r\naim_id:插件数据ID\r\ncTime|time_format:增加时间\r\nrequest_count|intval:请求�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'keyword', '', '1388815871', '1388929956', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('7', 'vote_option', '投票选项', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1388933346', '1388933346', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('8', 'vote_log', '投票记录', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1388934136', '1388934136', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('11', 'member_public', '公众号管�\�', '0', '', '1', '{\"1\":[\"public_name\",\"public_id\",\"wechat\",\"headface_url\",\"type\",\"appid\",\"secret\"]}', '1:基础', '', '', '', '', 'id:公众号ID\r\npublic_name:公众号名�\�\r\ngroup_id|get_public_group_name:等级\r\nheadface_url:公众号头�\�\r\ntoken:Token\r\nuid:管理�\�\r\nis_use|get_name_by_status:当前公众�\�\r\nids:操作:[EDIT]|编辑,[DELETE]|删除,changPublic&id=[id]|切换为当前公众号,help&public_id=[id]#weixin_set|接口配置', '20', 'public_name', '', '1391575109', '1398931552', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('30', 'card_member', '会员卡成�\�', '0', '', '1', '{\"1\":[\"username\",\"phone\"]}', '1:基础', '', '', '', '', 'number:卡号\r\nusername:姓名\r\nphone:手机�\�\r\ncTime|time_format:加入时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'username', '', '1395482804', '1395484751', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('13', 'member_public_group', '公众号等�\�', '0', '', '1', '{\"1\":[\"title\",\"addon_status\"]}', '1:基础', '', '', '', '', 'id:等级ID\r\ntitle:等级�\�\r\naddon_status:授权的插�\�\r\npublic_count:公众号数\r\nid:操作:editPublicGroup&id=[id]|编辑,delPublicGroup&id=[id]|删除', '10', 'title', '', '1393724788', '1393730663', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('14', 'update_version', '系统版本升级', '0', '', '1', '{\"1\":[\"version\",\"title\",\"description\",\"create_date\",\"package\"]}', '1:基础', '', '', '', '', 'version:版本�\�\r\ntitle:升级包名\r\ndescription:描述\r\ncreate_date|time_format:创建时间\r\ndownload_count:下载统计�\�\r\nid:操作:[EDIT]&id=[id]|编辑,[DELETE]&id=[id]|删除', '10', '', '', '1393770420', '1393771807', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('22', 'extensions', '融合第三�\�', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"keyword_filter\",\"output_format\",\"api_url\",\"api_token\"]}', '1:基础', '', '', '', '', 'keyword:关键�\�\r\nkeyword_filter|get_name_by_status:关键词过�\�\r\noutput_format|get_name_by_status:数据输出格式\r\napi_url:第三方地址\r\napi_token:Token\r\ncTime|time_format:增加时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'keyword', '', '1393911774', '1394721892', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('16', 'forum', '论坛�\�', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1394033250', '1394033250', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('17', 'store', '插件商店', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1394033250', '1394033250', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('18', 'suggestions', '建议意见', '0', '', '1', '{\"1\":[\"content\",\"nickname\",\"mobile\"]}', '1:基础', '', '', '', '', 'nickname:昵称\r\ncontent:内容\r\nmobile:联系方式\r\ncTime|time_format:创建时间\r\nid:操作:[EDIT]&id=[id]|编辑,[DELETE]&id=[id]|删除', '10', 'content', '', '1393234169', '1400687145', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('85', 'custom_menu', '自定义菜�\�', '0', '', '1', '', '1:基础', '', '', '', '', 'title:菜单�\�\r\nkeyword:关联关键�\�\r\nurl:关联URL\r\nsort:排序�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1394518309', '1394720290', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('31', 'card_notice', '会员卡通知', '0', '', '1', '{\"1\":[\"title\",\"content\"]}', '1:基础', '', '', '', '', 'title:标题\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1395485156', '1395485486', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('33', 'weisite_category', '微官网分�\�', '0', '', '1', '{\"1\":[\"title\",\"icon\",\"url\",\"is_show\",\"sort\"]}', '1:基础', '', '', '', '', 'title:15%分类标题\r\nicon:15%分类图片\r\nurl:40%外链\r\nsort:10%排序�\�\r\nis_show|get_name_by_status:10%显示\r\nid:10%操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1395987942', '1399901779', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('34', 'weisite_cms', '文章管理', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cate_id\",\"cover\",\"content\"]}', '1:基础', '', '', '', '', 'keyword:关键�\�\r\nkeyword_type|get_name_by_status:关键词类�\�\r\ntitle:标题\r\ncate_id:所属分�\�\r\nsort:排序�\�\r\nview_count:浏览�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1396510673', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('35', 'weisite_slideshow', '幻灯�\�', '0', '', '1', '{\"1\":[\"title\",\"img\",\"url\",\"is_show\",\"sort\"]}', '1:基础', '', '', '', '', 'title:标题\r\nimg:图片\r\nurl:链接地址\r\nis_show|get_name_by_status:显示\r\nsort:排序\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396098264', '1396099200', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('36', 'weisite_footer', '底部导航', '0', '', '1', '{\"1\":[\"pid\",\"title\",\"url\",\"sort\"]}', '1:基础', '', '', '', '', 'title:菜单�\�\r\nicon:图标\r\nurl:关联URL\r\nsort:排序�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1394518309', '1396507698', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('62', 'custom_reply_text', '文本回复', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"content\",\"sort\"]}', '1:基础', '', '', '', '', 'id:ID\r\nkeyword:关键�\�\r\nkeyword_type|get_name_by_status:关键词类�\�\r\nsort:排序�\�\r\nview_count:浏览�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'keyword', '', '1396578172', '1401017369', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('64', 'custom_reply_news', '图文回复', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cate_id\",\"cover\",\"content\",\"sort\",\"jump_url\"]}', '1:基础', '', '', '', '', 'id:5%ID\r\nkeyword:10%关键�\�\r\nkeyword_type|get_name_by_status:20%关键词类�\�\r\ntitle:30%标题\r\ncate_id:10%所属分�\�\r\nsort:7%排序�\�\r\nview_count:8%浏览�\�\r\nid:10%操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1402657526', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('65', 'custom_reply_mult', '多图文配�\�', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1396602475', '1396602475', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('69', 'forms', '通用表单', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"title\",\"intro\",\"cover\",\"can_edit\",\"finish_tip\",\"jump_url\",\"content\"]}', '1:基础', '', '', '', '', 'id:通用表单ID\r\nkeyword:关键�\�\r\nkeyword_type|get_name_by_status:关键词类�\�\r\ntitle:标题\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,forms_attribute&id=[id]|字段管理,forms_value&id=[id]|数据管理,preview&id=[id]|预览', '10', 'title', '', '1396061373', '1401017094', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('70', 'forms_attribute', '表单字段', '0', '', '1', '{\"1\":[\"name\",\"title\",\"type\",\"extra\",\"value\",\"remark\",\"is_must\",\"validate_rule\",\"error_info\",\"sort\"]}', '1:基础', '', '', '', '', 'title:字段标题\r\nname:字段�\�\r\ntype|get_name_by_status:字段类型\r\nid:操作:[EDIT]&forms_id=[forms_id]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1396710959', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('71', 'forms_value', '通用表单数据', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1396687959', '1396687959', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('73', 'survey', '调研问卷', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"title\",\"cover\",\"intro\",\"finish_tip\"]}', '1:基础', '', '', '', '', 'id:微调研ID\r\nkeyword:关键�\�\r\nkeyword_type|get_name_by_status:关键词类�\�\r\ntitle:标题\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,survey_question&id=[id]|问题管理,survey_answer&id=[id]|数据管理,preview&id=[id]|预览', '10', 'title', '', '1396061373', '1401017145', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('74', 'survey_question', '调研问题', '0', '', '1', '{\"1\":[\"title\",\"type\",\"extra\",\"intro\",\"is_must\",\"sort\"]}', '1:基础', '', '', '', '', 'title:标题\r\ntype|get_name_by_status:问题类型\r\nis_must|get_name_by_status:是否必填\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1396955090', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('75', 'survey_answer', '调研回答', '0', '', '1', '', '1:基础', '', '', '', '', 'openid:OpenId\r\ntruename:姓名\r\nmobile:手机�\�\r\ncTime|time_format:发布时间\r\nid:操作:detail?uid=[uid]&survey_id=[survey_id]|回答内容', '10', 'title', '', '1396061373', '1397011511', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('76', 'exam', '考试试卷', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"title\",\"cover\",\"intro\",\"start_time\",\"end_time\",\"finish_tip\"]}', '1:基础', '', '', '', '', 'id:微考试ID\r\nkeyword:关键�\�\r\nkeyword_type|get_name_by_status:关键词类�\�\r\ntitle:试卷标题\r\nstart_time|time_format:开始时�\�\r\nend_time|time_format:结束时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,exam_question&id=[id]|题目管理,exam_answer&id=[id]|考生成绩,preview&id=[id]|试卷预览', '10', 'title', '', '1396061373', '1401017190', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('77', 'exam_question', '考试题目', '0', '', '1', '{\"1\":[\"title\",\"type\",\"extra\",\"intro\",\"is_must\",\"sort\"]}', '1:基础', '', '', '', '', 'title:标题\r\ntype|get_name_by_status:题目类型\r\nscore:分�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1397035409', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('78', 'exam_answer', '考试回答', '0', '', '1', '', '1:基础', '', '', '', '', 'openid:OpenId\r\ntruename:姓名\r\nmobile:手机�\�\r\nscore:成绩\r\ncTime|time_format:考试时间\r\nid:操作:detail?uid=[uid]&exam_id=[exam_id]|答题详情', '10', 'title', '', '1396061373', '1397036455', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('79', 'test', '测试问卷', '0', '', '1', '{\"1\":[\"keyword\",\"keyword_type\",\"title\",\"cover\",\"intro\",\"finish_tip\"]}', '1:基础', '', '', '', '', 'id:微测试ID\r\nkeyword:关键�\�\r\nkeyword_type|get_name_by_status:关键词类�\�\r\ntitle:问卷标题\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,test_question&id=[id]|题目管理,test_answer&id=[id]|用户记录,preview&id=[id]|问卷预览', '10', 'title', '', '1396061373', '1401017218', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('80', 'test_question', '测试题目', '0', '', '1', '{\"1\":[\"title\",\"extra\",\"intro\",\"sort\"]}', '1:基础', '', '', '', '', 'id:问题编号\r\ntitle:标题\r\nextra:参数\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1397145854', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('81', 'test_answer', '测试回答', '0', '', '1', '', '1:基础', '', '', '', '', 'openid:OpenId\r\ntruename:姓名\r\nmobile:手机�\�\r\nscore:得分\r\ncTime|time_format:测试时间\r\nid:操作:detail?uid=[uid]&test_id=[test_id]|答题详情', '10', 'title', '', '1396061373', '1397145984', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('82', 'diy', '万能页面', '0', '', '1', '{\"1\":[\"keyword\",\"title\",\"cover\",\"intro\",\"is_close\",\"need_login\"]}', '1:基础', '', '', '', '', 'keyword:关键�\�\r\ntitle:标题\r\nis_close|get_name_by_status:是否关闭\r\nneed_login|get_name_by_status:游客访问\r\nview_count:浏览�\�\r\nid:操作:[EDIT]|编辑,del&id=[id]&_addons=Diy&_controller=Diy|删除,diy&id=[id]&target=_blank&_addons=Diy&_controller=Diy|排版,preview&id=[id]&target=_blank&_addons=Diy&_controller=Diy|预览,show&id=[id]&target=_blank&_addons=Diy&_controller=Diy&token=[token]|访问地址', '10', 'title', '', '1396061373', '1399105105', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('83', 'shop_product', '微商店商�\�', '0', '', '1', '{\"1\":[\"title\",\"cover\",\"intro\",\"cate_id\",\"market_price\",\"discount_price\",\"buy_url\",\"ad_url\",\"content\",\"param\",\"img_1\",\"img_2\",\"img_3\",\"img_4\",\"img_5\"]}', '1:基础', '', '', '', '', 'id:商品ID\r\ncover|get_img_html:图片\r\ntitle:商品名称\r\ncate_id|getCommonCategoryTitle:分类\r\nmarket_price:市场�\�\r\ndiscount_price:市场�\�\r\nview_count:浏览�\�\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1398741409', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('84', 'common_category', '通用分类', '0', '', '1', '{\"1\":[\"pid\",\"title\",\"icon\",\"intro\",\"sort\",\"is_show\"]}', '1:基础', '', '', '', '', 'id:分类ID\r\ntitle:分类标题\r\nicon|get_img_html:分类图片\r\nsort:排序�\�\r\nis_show|get_name_by_status:显示\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1397529095', '1398597378', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('86', 'shop_footer', '底部导航', '0', '', '1', '{\"1\":[\"pid\",\"title\",\"url\",\"sort\"]}', '1:基础', '', '', '', '', 'title:菜单�\�\r\nicon:图标\r\nurl:关联URL\r\nsort:排序�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1394518309', '1396507698', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('87', 'credit_config', '积分配置', '0', '', '1', '{\"1\":[\"title\",\"name\",\"experience\",\"score\"]}', '1:基础', '', '', '', '', 'title:积分描述\r\nname:积分标识\r\nexperience:经验�\�\r\nscore:财富�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1396061373', '1398564809', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('88', 'credit_data', '用户积分记录', '0', '', '1', '{\"1\":[\"credit_name\",\"uid\",\"experience\",\"score\"]}', '1:基础', '', '', '', '', 'uid:用户\r\ncredit_name:积分标识\r\nexperience:经验�\�\r\nscore:财富�\�\r\ncTime|time_format:记录时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'uid', '', '1398564291', '1400117739', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('89', 'follow', '粉丝管理', '0', '', '1', '{\"1\":[\"nickname\",\"sex\",\"headimgurl\",\"city\",\"province\",\"country\",\"language\"]}', '1:基础', '', '', '', '', 'id:粉丝编号\r\nopenid:OpenId\r\nnickname:昵称\r\nsex|get_name_by_status:性别\r\nsubscribe_time|time_format:关注时间\r\nids:操作:[EDIT]|编辑', '10', 'nickname', '', '1398845737', '1398846740', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('90', 'member_public_link', '公众号与管理员的关联关系', '0', '', '1', '{\"1\":[\"uid\",\"addon_status\"]}', '1:基础', '', '', '', '', 'uid|get_nickname:管理�\�\r\naddon_status:授权的插�\�\r\nids:操作:[EDIT]|编辑,[DELETE]|删除', '10', '', '', '1398933192', '1398947067', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('91', 'coupon', '优惠�\�', '0', '', '1', '{\"1\":[\"keyword\",\"title\",\"intro\",\"cover\",\"use_tips\",\"start_time\",\"end_time\",\"end_img\",\"end_tips\",\"num\",\"max_num\",\"follower_condtion\",\"credit_conditon\",\"credit_bug\",\"addon_condition\"]}', '1:基础', '', '', '', '', 'id:优惠券ID\r\nkeyword:关键�\�\r\ntitle:标题\r\ncollect_count:获取人数\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,lists?target_id=[id]&target=_blank&_controller=Sn|成员管理,preview?id=[id]&target=_blank|预览', '10', 'title', '', '1396061373', '1401017265', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('92', 'sn_code', 'SN�\�', '0', '', '1', '{\"1\":[\"prize_title\"]}', '1:基础', '', '', '', '', 'sn:SN�\�\r\nuid|get_nickname:昵称\r\nprize_title:奖项\r\ncTime|time_format:创建时间\r\nis_use|get_name_by_status:是否已使�\�\r\nuse_time|time_format:使用时间\r\nid:操作:[DELETE]|删除,set_use?id=[id]|改变使用状�\�', '10', 'sn', '', '1399272054', '1401013099', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('93', 'scratch', '刮刮�\�', '0', '', '1', '{\"1\":[\"keyword\",\"title\",\"intro\",\"cover\",\"use_tips\",\"start_time\",\"end_time\",\"end_tips\",\"end_img\",\"predict_num\",\"max_num\",\"follower_condtion\",\"credit_conditon\",\"credit_bug\",\"addon_condition\"]}', '1:基础', '', '', '', '', 'id:刮刮卡ID\r\nkeyword:关键�\�\r\ntitle:标题\r\ncollect_count:获取人数\r\ncTime|time_format:发布时间\r\nid:操作:[EDIT]|编辑,[DELETE]|删除,lists?target_id=[id]&target=_blank&_controller=Sn|中奖管理,lists?target_id=[id]&target=_blank&_controller=Prize|奖品管理,preview?id=[id]&target=_blank|预览', '10', 'title', '', '1396061373', '1401017298', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('94', 'prize', '奖项设置', '0', '', '1', '{\"1\":[\"title\",\"name\",\"num\",\"img\",\"sort\"]}', '1:基础', '', '', '', '', 'title:奖项标题\r\nname:奖项\r\nnum:名额数量\r\nimg|get_img_html:奖品图片\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1399348610', '1399702991', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('95', 'addon_category', '插件分类', '0', '', '1', '{\"1\":[\"icon\",\"title\",\"sort\"]}', '1:基础', '', '', '', '', 'icon|get_img_html:分类图标\r\ntitle:分类�\�\r\nsort:排序�\�\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1400047655', '1400048130', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('96', 'tongji', '运营统计', '0', '', '1', '{\"1\":[\"month\",\"day\",\"content\"]}', '1:基础', '', '', '', '', 'day:日期', '10', 'day', '', '1401371050', '1401371409', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('97', 'ml_microcatering_set', '微餐�\�-餐厅设置', '0', '', '1', '{\"1\":[\"keyword\",\"title\",\"cover\",\"intro\",\"kfname\"]}', '1:基础', '', '', '', '', 'id:编号\r\nkeyword:关键�\�\r\ntitle:标题\r\nid:操作:show&id=[id]|预览,listsedit&id=[id]|编辑,listsdel&id=[id]|删除', '10', 'title', 'intro', '1401103928', '1401378396', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('98', 'ml_microcatering_dishes', '微餐�\�-菜品�\�', '0', '', '1', '{\"1\":[\"dishes_num\",\"name\",\"price\",\"icon\",\"introduction\",\"order\",\"state\"]}', '1:基础', '', '', '', '', 'id:编号\r\npaixu:排序�\�\r\nicon:15%菜品图片\r\nname:菜品名称\r\nstate|get_name_by_status:状�\�\r\nid:操作:[EDIT]&id=[id]|编辑,[DELETE]|删除', '10', 'name', 'dishes_num', '1401110349', '1401541884', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('99', 'ml_microcatering_scheduledtask', '微餐�\�-计划任务列表', '0', '', '1', '{\"1\":[\"title\",\"state\",\"type\",\"zhou\",\"yue\",\"day\",\"xiaos\",\"fenz\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:任务名称\r\nupruntime:上次执行时间\r\ndownruntime:下次执行时间', '10', 'title', '', '1401112371', '1401207461', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('100', 'ml_microcatering_tablemanage', '微餐�\�-桌台（餐位）管理', '0', '', '1', '{\"1\":[\"ztnum\",\"ztname\",\"zttype\",\"ztdes\",\"yongccount\",\"state\",\"paixu\"]}', '1:基础', '', '', '', '', 'id:编号\r\nztnum:餐位编号\r\npaixu:排序�\�\r\nztname:餐位名称\r\nzttype|get_name_by_status:餐位类型\r\nyongccount:用餐人数\r\nstate|get_name_by_status:状�\�\r\nid:操作:[EDIT]&id=[id]|编辑,[DELETE]|删除', '10', 'ztname', 'ztnum', '1401112860', '1401541512', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('101', 'ml_microcatering_yuyuemanage', '微餐�\�-电话预约管理', '0', '', '1', '{\"1\":[\"username\",\"usermobile\",\"sex\",\"yycount\"]}', '1:基础', '', '', '', '', 'id:编号\r\nusername:预约人姓�\�\r\nusermobile:预约人电�\�\r\nsex:性别\r\nyycount:预约人数', '10', 'username', '', '1401113104', '1401698416', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('102', 'ml_microcatering_dishes_type', '微餐�\�-菜系分类', '0', '', '1', '{\"1\":[\"name\",\"pic\",\"introduction\",\"state\",\"paixu\"]}', '1:基础', '', '', '', '', 'id:编号\r\npaixu:排序�\�\r\npic:15%菜系图片\r\nname:菜系名称\r\nstate|get_name_by_status:状�\�\r\nid:操作:[EDIT]&id=[id]&ctid=[setid]|编辑,[DELETE]|删除', '10', 'name', 'introduction', '1401113818', '1401973013', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('103', 'ml_microcatering_review', '微餐�\�-评论', '0', '', '1', '{\"1\":[\"pltime\",\"plcontent\",\"hfcontent\",\"hftime\"]}', '1:基础', '', '', '', '', 'id:编号\r\nopenid:评论用户id\r\npltime:评论时间', '10', '', '', '1401114177', '1401206740', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('104', 'ml_microcatering_order', '微餐�\�-点餐管理', '0', '', '1', '{\"1\":[\"beizhu\",\"jctime\"]}', '1:基础', '', '', '', '', 'id:编号\r\ndcnum:订单编号\r\nopenid:用户id\r\nctime:下单时间\r\njctime:就餐时间\r\nyhprice:优惠后总价\r\ncpcount:菜品数量\r\nstate|get_name_by_status:状�\�\r\nstatekz|get_name_by_status:附加状�\�\r\nbeizhu:备注\r\nid:操作:lookcp&ctid=[set_id]&id=[id]|查看详细,[EDIT]&id=[id]|修改订单状�\�', '10', '', '', '1401115120', '1402217924', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('105', 'ml_microcatering_discount_type', '微餐�\�-优惠分类', '0', '', '1', '{\"1\":[\"state\",\"name\",\"paixu\"]}', '1:基础', '', '', '', '', 'id:编号\r\npaixu:排序�\�\r\nname:菜系名称\r\nstate|get_name_by_status:状�\�\r\nismain|get_name_by_status:是否主要\r\nid:操作:setzhuyao&id=[id]&ctid=[setid]|设置为主�\�,[EDIT]&id=[id]]&ctid=[setid]|编辑,[DELETE]|删除', '10', 'name', '', '1401119532', '1401973037', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('106', 'ml_microcatering_order_temp', '微餐�\�-订单临时�\�', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1401610576', '1401610576', '1', 'MyISAM');
INSERT INTO `wp_model` VALUES ('107', 'ml_microcatering_users', '微餐�\�-联系信息', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1401694105', '1401694105', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `wp_picture`
-- -----------------------------
DROP TABLE IF EXISTS `wp_picture`;
CREATE TABLE `wp_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=407 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_picture`
-- -----------------------------
INSERT INTO `wp_picture` VALUES ('365', '/Uploads/Picture/2014-06-11/539822745fab7.jpg', '', '8b8ede63f083cfd4143d87d77397c3fa', '0057edd03ab440894d524d19a797c8a671ec8dac', '1', '1402479220');
INSERT INTO `wp_picture` VALUES ('366', '/Uploads/Editor/-1/2014-06-11/539825cfce8c5.jpg', '', 'f1526f818ac66ca562f7507a94f08f41', '88f9863f0c71093b77bba730376fd4c8729f562a', '1', '1402480079');
INSERT INTO `wp_picture` VALUES ('367', '/Uploads/Picture/2014-06-11/5398260ddcd7a.jpg', '', 'd58205f94e5f94e7eace42a3c6082d36', 'a3290f5c462957d172b17a13f5b34c8850343645', '1', '1402480141');
INSERT INTO `wp_picture` VALUES ('368', '/Uploads/Picture/2014-06-12/539902ce67725.jpg', '', 'c3fd5d3eccb6a4318b363551c97505b7', '18755871a64f7789a2f641397109581ab054001c', '1', '1402536654');
INSERT INTO `wp_picture` VALUES ('369', '/Uploads/Editor/-1/2014-06-12/539904738ffef.jpg', '', 'c3972144a33470585e7e1fa59ae4f525', 'bf1badca6642eb8533d2f63c56d7d1a4ebabd225', '1', '1402537075');
INSERT INTO `wp_picture` VALUES ('370', '/Uploads/Editor/-1/2014-06-12/539908c9eb2f4.gif', '', '92eb5eb21c7c3b0ca609db3f60260138', '568b7385ff81cfc8d513de68301a7a136a2b4489', '1', '1402538185');
INSERT INTO `wp_picture` VALUES ('371', '/Uploads/Editor/-1/2014-06-13/539a4de73c556.gif', '', '13e9d3872a7e4e544ac1a3babd27db6e', 'c98f391be5d198a084f5376e3ec853bbc966d009', '1', '1402621415');
INSERT INTO `wp_picture` VALUES ('372', '/Uploads/Picture/2014-06-13/539a694d934bc.jpg', '', '6b2a7906fb4c10cc647948269b822f04', '0ea4e6a18b43fc0e35743bf884cd8472914ffb7b', '1', '1402628429');
INSERT INTO `wp_picture` VALUES ('373', '/Uploads/Picture/2014-06-13/539a6970a7512.jpg', '', '39d34f6f49f4340f6d12f5b103893502', 'ded7e40fbd9196fe4f0d8796c27ce5ce3b728566', '1', '1402628464');
INSERT INTO `wp_picture` VALUES ('374', '/Uploads/Picture/2014-06-13/539a698658c32.jpg', '', 'a3ff9be858cdee12e0d41a83a1f8ed4d', '176b5c9a714494969c94b76e670f1431fd818aaa', '1', '1402628486');
INSERT INTO `wp_picture` VALUES ('375', '/Uploads/Picture/2014-06-13/539a6996f2121.jpg', '', '1a160df0990d6756f450b5aa21c34729', '4165d942ad1e6da0c5013b5483cd08fe44e429f2', '1', '1402628502');
INSERT INTO `wp_picture` VALUES ('376', '/Uploads/Picture/2014-06-13/539af3493371e.jpg', '', '0ac228b1726e0a9781967dee85f454cf', '82bbcadfd18b5fc8c07688a0cba6b0204e22eaaa', '1', '1402663751');
INSERT INTO `wp_picture` VALUES ('377', '/Uploads/Picture/2014-06-13/539af42e65084.jpg', '', '90c7cd525e8d8cd08dbea86f39288910', 'f3eae18b73c421365088622aad1056c9fb9efe60', '1', '1402663981');
INSERT INTO `wp_picture` VALUES ('378', '/Uploads/Editor/-1/2014-06-13/539af450c5f2b.jpg', '', '76e71a9780a7f85847e9cbce85bd1131', '261869916b589bee28f320b5a8155dd8e950f92a', '1', '1402664016');
INSERT INTO `wp_picture` VALUES ('379', '/Uploads/Editor/-1/2014-06-13/539af71862440.jpg', '', '960ed553b98d948d23a64df7bf14174b', '6b1b73a5ea40ecf3f9611b1551e5d4f3d00d39ae', '1', '1402664727');
INSERT INTO `wp_picture` VALUES ('380', '/Uploads/Picture/2014-06-13/539b00689f087.jpg', '', 'a83eeb4fa706679e4f6c2fd8e3b4ff15', 'a1befb1d4efaddcb603961dad0ee52142db75650', '1', '1402667112');
INSERT INTO `wp_picture` VALUES ('381', '/Uploads/Picture/2014-06-15/539cfc7c0ba21.jpg', '', '9242573d6b2359bfd0056768afb74190', 'b5a6900063bc2ae7aef172959074f38066e3007e', '1', '1402797179');
INSERT INTO `wp_picture` VALUES ('382', '/Uploads/Editor/-1/2014-06-15/539cfcb0e3372.jpg', '', '2bfe90e7e2bbd2fc0940ec5bb0b71c01', '7793da114a7c9db4c765c86ca8cf79be6fb5ae48', '1', '1402797232');
INSERT INTO `wp_picture` VALUES ('383', '/Uploads/Picture/2014-06-15/539cfe3ceed96.jpg', '', 'a5d46f4f8d7479e9d6528f7d3bf1692b', '157b83525113494099d2f81d641dd83ad3c75fdd', '1', '1402797628');
INSERT INTO `wp_picture` VALUES ('384', '/Uploads/Picture/2014-06-15/539cff5b96529.jpg', '', '7da6df11f6e385deb87e4481c58af01e', '3b2e5c3df76cd2497caf3651cabae643a7b38bef', '1', '1402797915');
INSERT INTO `wp_picture` VALUES ('385', '/Uploads/Picture/2014-06-15/539d070f69977.jpg', '', 'de0124abff3de179a9e44a0706fe41ad', 'ae4ba900e05aec68adb6765d6199d3bb509e7ec2', '1', '1402799887');
INSERT INTO `wp_picture` VALUES ('386', '/Uploads/Picture/2014-06-15/539d072cf2f7a.jpg', '', 'a13ab8ec887b764258615390526802e7', '683aa0ea0f4ccc995bed161b1ae915ea92333621', '1', '1402799916');
INSERT INTO `wp_picture` VALUES ('387', '/Uploads/Picture/2014-06-15/539d0bd16b769.jpg', '', 'e567db57d19c0e58d2e688c8e18a1800', '3cbf072883beaf268f0d2f27346544074daea213', '1', '1402801105');
INSERT INTO `wp_picture` VALUES ('388', '/Uploads/Picture/2014-06-15/539d0cfa55f97.jpg', '', '6e898054772b509fa002753f50e0cf1e', '82e1a1148c80c2b5692f003386f231907b238aa7', '1', '1402801402');
INSERT INTO `wp_picture` VALUES ('389', '/Uploads/Picture/2014-06-15/539d0e0939495.jpg', '', '4ddbe12e9c2ecbdd8829293fca52bd69', '3b679e2ae0d7b8f4e1071633a0a31d1ee157a3b0', '1', '1402801673');
INSERT INTO `wp_picture` VALUES ('390', '/Uploads/Picture/2014-06-15/539d0f8e3eb7f.jpg', '', '728a0b5f0539fe4f9e2b3394a5a66794', '2bc55731f450e2f5ef8997dce69d513492ebf9fb', '1', '1402802062');
INSERT INTO `wp_picture` VALUES ('391', '/Uploads/Picture/2014-06-15/539d12455695d.jpg', '', 'c7d8ea7954f0690fec46720390c2c037', '8cfd525d6c368f39ebfd2ed6eb3c3e0eb1006a9e', '1', '1402802757');
INSERT INTO `wp_picture` VALUES ('392', '/Uploads/Picture/2014-06-15/539d4353dcb19.jpg', '', 'e1b0b5a0094822ac0b5593377b68fa48', '07802e100af5c09b493c9c245d62ad3b25338e36', '1', '1402815315');
INSERT INTO `wp_picture` VALUES ('393', '/Uploads/Editor/-1/2014-06-15/539d436664973.jpg', '', '641eb41507716a3b078f20051e24103d', '59ffbdfceef5236a500d925439a9803a02007734', '1', '1402815333');
INSERT INTO `wp_picture` VALUES ('394', '/Uploads/Editor/-1/2014-06-15/539d49a155054.gif', '', '14adbed511378f202e1237c1135516a3', 'c85ec55d913eb7b6623a2ef48fe3cc291861ac4d', '1', '1402816928');
INSERT INTO `wp_picture` VALUES ('395', '/Uploads/Picture/2014-06-16/539e4982407f9.jpg', '', 'f1df8190ac617a81b222c5969cca0692', 'ed2a199a8e4b3694956301a8a16ec144f8e1881a', '1', '1402882434');
INSERT INTO `wp_picture` VALUES ('396', '/Uploads/Picture/2014-06-16/539e4af20472b.jpg', '', '78d06f5461ca5fc7e5e77c4e16a8fceb', '108f31a3feee20e53f0349e6f6f8025832929a1e', '1', '1402882801');
INSERT INTO `wp_picture` VALUES ('397', '/Uploads/Picture/2014-06-16/539e4b9241479.jpg', '', '8d18c54a972c1361033825b3b3ecfd18', 'cf9fdbe88f5803aec5cfdae705333d722e04cc88', '1', '1402882962');
INSERT INTO `wp_picture` VALUES ('398', '/Uploads/Picture/2014-06-16/539e528450964.jpg', '', '8469f4e47f3cb4df7f2b6171789091b6', '03e4bbd27def835cbb2f029b02de730a4a8bd182', '1', '1402884740');
INSERT INTO `wp_picture` VALUES ('399', '/Uploads/Picture/2014-06-16/539e52d336585.jpg', '', 'ebd36f8a51ca22d6f093460f80f2af0d', '74a736221bb096ed64876332fcf3860bcba9847a', '1', '1402884819');
INSERT INTO `wp_picture` VALUES ('400', '/Uploads/Picture/2014-06-16/539e54c75485a.jpg', '', 'f4b6e520a72dfaa8e887005c5f5a4fa8', '7f009c87477fa682d393867dcaf647f6756325f5', '1', '1402885319');
INSERT INTO `wp_picture` VALUES ('401', '/Uploads/Picture/2014-06-16/539e56b67c654.jpg', '', '1b8e071632749cff2f630065c1921235', 'eb0ef26d178befd474f26f52d055761ce198b241', '1', '1402885814');
INSERT INTO `wp_picture` VALUES ('402', '/Uploads/Picture/2014-06-16/539e56ba5bbc1.jpg', '', 'fa47aae5ff29ee11d33c2db6ecf2ea94', 'e844a8e0cf069acc793cd35241f5da1043433230', '1', '1402885818');
INSERT INTO `wp_picture` VALUES ('403', '/Uploads/Picture/2014-06-16/539e584575070.jpg', '', '882117eef7c90372f23f7d079b440de1', 'e01937580c1494e59cb6f1d640558ca90f23693d', '1', '1402886213');
INSERT INTO `wp_picture` VALUES ('404', '/Uploads/Picture/2014-06-16/539e59f8d243e.jpg', '', '64d17cd1ecf421d3fd23d65e18a3fef0', '16b71fb2a38a6f15fe1d1b6b6e6aa2db8b44fcb8', '1', '1402886648');
INSERT INTO `wp_picture` VALUES ('405', '/Uploads/Picture/2014-06-16/539e5cf35df5c.jpg', '', 'f3d4de0c78a2a478333f067a8e30a7d3', '6b7da7cbb21c07112843ae26d99da730a147e760', '1', '1402887411');
INSERT INTO `wp_picture` VALUES ('406', '/Uploads/Picture/2014-06-16/539e615693f98.jpg', '', 'b86fd23ecd03d060c2ed388c92791b45', '74e3ba78ad1245bb424accdd58ff99ee42132b2e', '1', '1402888534');

-- -----------------------------
-- Table structure for `wp_prize`
-- -----------------------------
DROP TABLE IF EXISTS `wp_prize`;
CREATE TABLE `wp_prize` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addon` varchar(255) NOT NULL DEFAULT 'Scratch' COMMENT '来源插件',
  `target_id` int(10) unsigned NOT NULL COMMENT '来源ID',
  `title` varchar(255) NOT NULL COMMENT '奖项标题',
  `name` varchar(255) NOT NULL COMMENT '奖项',
  `num` int(10) unsigned NOT NULL COMMENT '名额数量',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  `img` int(10) unsigned NOT NULL COMMENT '奖品图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_scratch`
-- -----------------------------
DROP TABLE IF EXISTS `wp_scratch`;
CREATE TABLE `wp_scratch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `use_tips` varchar(255) NOT NULL COMMENT '使用说明',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `end_time` int(10) NOT NULL COMMENT '结束时间',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `start_time` int(10) NOT NULL COMMENT '开始时间',
  `end_tips` text NOT NULL COMMENT '过期说明',
  `predict_num` int(10) unsigned NOT NULL COMMENT '预计参与人数',
  `max_num` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '每人最多允许抽奖次数',
  `follower_condtion` char(50) NOT NULL DEFAULT '1' COMMENT '粉丝状态',
  `credit_conditon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分限制',
  `credit_bug` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分消费',
  `addon_condition` varchar(255) NOT NULL COMMENT '插件场景限制',
  `collect_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '已领取人数',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览人数',
  `update_time` int(10) NOT NULL COMMENT '更新时间',
  `end_img` int(10) unsigned NOT NULL COMMENT '过期提示图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_shop_footer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_footer`;
CREATE TABLE `wp_shop_footer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `url` varchar(255) DEFAULT NULL COMMENT '关联URL',
  `title` varchar(50) NOT NULL COMMENT '菜单名',
  `pid` tinyint(2) DEFAULT '0' COMMENT '一级菜单',
  `sort` tinyint(4) DEFAULT '0' COMMENT '排序号',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `icon` int(10) unsigned DEFAULT NULL COMMENT '图标',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_shop_product`
-- -----------------------------
DROP TABLE IF EXISTS `wp_shop_product`;
CREATE TABLE `wp_shop_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '商品名称',
  `intro` text NOT NULL COMMENT '商品简介',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `cover` int(10) unsigned NOT NULL COMMENT '商品封面图片',
  `content` text NOT NULL COMMENT '商品详情',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `param` text NOT NULL COMMENT '商品参数',
  `ad_url` varchar(255) NOT NULL COMMENT '商品广告页面',
  `buy_url` varchar(255) NOT NULL COMMENT '购买地址',
  `cate_id_1` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品一级分类',
  `cate_id_2` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品二级分类',
  `market_price` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '市场价',
  `discount_price` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '打折价',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  `img_1` int(10) unsigned NOT NULL COMMENT '商品图片1',
  `img_2` int(10) unsigned NOT NULL COMMENT '商品图片2',
  `img_3` int(10) unsigned NOT NULL COMMENT '商品图片3',
  `img_4` int(10) unsigned NOT NULL COMMENT '商品图片4',
  `img_5` int(10) unsigned NOT NULL COMMENT '商品图片5',
  `cate_id` char(50) NOT NULL COMMENT '商品分类',
  `bug_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '成交量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_sn_code`
-- -----------------------------
DROP TABLE IF EXISTS `wp_sn_code`;
CREATE TABLE `wp_sn_code` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sn` varchar(255) NOT NULL COMMENT 'SN码',
  `uid` int(10) NOT NULL COMMENT '粉丝UID',
  `cTime` int(10) NOT NULL COMMENT '创建时间',
  `is_use` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否已使用',
  `use_time` int(10) NOT NULL COMMENT '使用时间',
  `addon` varchar(255) NOT NULL DEFAULT 'Coupon' COMMENT '来自的插件',
  `target_id` int(10) unsigned NOT NULL COMMENT '来源ID',
  `prize_id` int(10) unsigned NOT NULL COMMENT '奖项ID',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否可用',
  `prize_title` varchar(255) NOT NULL COMMENT '奖项',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=174 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_store`
-- -----------------------------
DROP TABLE IF EXISTS `wp_store`;
CREATE TABLE `wp_store` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) DEFAULT '0' COMMENT '用户ID',
  `content` text COMMENT '内容',
  `cTime` int(10) DEFAULT NULL COMMENT '发布时间',
  `attach` varchar(255) DEFAULT NULL COMMENT '插件安装包',
  `is_top` int(10) DEFAULT '0' COMMENT '置顶',
  `cid` tinyint(4) DEFAULT NULL COMMENT '分类',
  `view_count` int(11) unsigned DEFAULT '0' COMMENT '浏览数',
  `img_1` int(10) unsigned DEFAULT NULL COMMENT '插件截图1',
  `img_2` int(10) unsigned DEFAULT NULL COMMENT '插件截图2',
  `img_3` int(10) unsigned DEFAULT NULL COMMENT '插件截图3',
  `img_4` int(10) unsigned DEFAULT NULL COMMENT '插件截图4',
  `download_count` int(10) unsigned DEFAULT '0' COMMENT '下载数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_suggestions`
-- -----------------------------
DROP TABLE IF EXISTS `wp_suggestions`;
CREATE TABLE `wp_suggestions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cTime` int(10) NOT NULL COMMENT '创建时间',
  `content` text NOT NULL COMMENT '内容',
  `uid` int(10) DEFAULT '0' COMMENT '用户ID',
  `nickname` varchar(255) NOT NULL COMMENT '用户昵称',
  `mobile` varchar(255) NOT NULL COMMENT '手机号',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_suggestions`
-- -----------------------------
INSERT INTO `wp_suggestions` VALUES ('25', '1402804076', '建议最好可以上传图�\�', '1', '', '', 'gh_ccbc7c79380e');

-- -----------------------------
-- Table structure for `wp_survey`
-- -----------------------------
DROP TABLE IF EXISTS `wp_survey`;
CREATE TABLE `wp_survey` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词类型',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `finish_tip` text NOT NULL COMMENT '结束语',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_survey_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_survey_answer`;
CREATE TABLE `wp_survey_answer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `survey_id` int(10) unsigned NOT NULL COMMENT 'survey_id',
  `question_id` int(10) unsigned NOT NULL COMMENT 'question_id',
  `uid` int(10) DEFAULT NULL COMMENT '用户UID',
  `openid` varchar(255) NOT NULL COMMENT 'OpenId',
  `answer` text NOT NULL COMMENT '回答内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_survey_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_survey_question`;
CREATE TABLE `wp_survey_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text NOT NULL COMMENT '问题描述',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `survey_id` int(10) unsigned NOT NULL COMMENT 'survey_id',
  `type` char(50) NOT NULL DEFAULT 'radio' COMMENT '问题类型',
  `extra` text NOT NULL COMMENT '参数',
  `is_must` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否必填',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_test`
-- -----------------------------
DROP TABLE IF EXISTS `wp_test`;
CREATE TABLE `wp_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '关键词类型',
  `title` varchar(255) NOT NULL COMMENT '问卷标题',
  `intro` text NOT NULL COMMENT '封面简介',
  `mTime` int(10) NOT NULL COMMENT '修改时间',
  `cover` int(10) unsigned NOT NULL COMMENT '封面图片',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `finish_tip` text NOT NULL COMMENT '评论语',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_test_answer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_test_answer`;
CREATE TABLE `wp_test_answer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `answer` text NOT NULL COMMENT '回答内容',
  `openid` varchar(255) NOT NULL COMMENT 'OpenId',
  `uid` int(10) DEFAULT NULL COMMENT '用户UID',
  `question_id` int(10) unsigned NOT NULL COMMENT 'question_id',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `test_id` int(10) unsigned NOT NULL COMMENT 'test_id',
  `score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '得分',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_test_question`
-- -----------------------------
DROP TABLE IF EXISTS `wp_test_question`;
CREATE TABLE `wp_test_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '题目标题',
  `intro` text NOT NULL COMMENT '题目描述',
  `cTime` int(10) unsigned NOT NULL COMMENT '发布时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `is_must` tinyint(2) NOT NULL DEFAULT '1' COMMENT '是否必填',
  `extra` text NOT NULL COMMENT '参数',
  `type` char(50) NOT NULL DEFAULT 'radio' COMMENT '题目类型',
  `test_id` int(10) unsigned NOT NULL COMMENT 'test_id',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_tongji`
-- -----------------------------
DROP TABLE IF EXISTS `wp_tongji`;
CREATE TABLE `wp_tongji` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `month` int(10) NOT NULL COMMENT '月份',
  `day` int(10) NOT NULL COMMENT '日期',
  `content` text NOT NULL COMMENT '统计数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wp_tongji`
-- -----------------------------
INSERT INTO `wp_tongji` VALUES ('1', '539811ab60f21', '201406', '20140611', 'a:21:{s:10:\"HelloWorld\";i:3;s:7:\"WeiSite\";i:140;s:5:\"Forms\";i:4;s:4:\"Chat\";i:1;s:10:\"CustomMenu\";i:3;s:3:\"Diy\";i:4;s:10:\"Extensions\";i:3;s:8:\"Leaflets\";i:2;s:14:\"EditorForAdmin\";i:1;s:5:\"Robot\";i:2;s:4:\"Card\";i:2;s:11:\"Suggestions\";i:2;s:6:\"Survey\";i:1;s:6:\"Coupon\";i:3;s:7:\"Scratch\";i:1;s:6:\"Wecome\";i:1;s:10:\"UserCenter\";i:8;s:11:\"CustomReply\";i:1;s:4:\"Vote\";i:1;s:4:\"Exam\";i:7;s:4:\"Test\";i:3;}');
INSERT INTO `wp_tongji` VALUES ('2', 'gh_ccbc7c79380e', '201406', '20140611', 'a:19:{s:4:\"Chat\";i:33;s:7:\"WeiSite\";i:197;s:3:\"Diy\";i:3;s:5:\"Forms\";i:4;s:14:\"EditorForAdmin\";i:2;s:10:\"Extensions\";i:5;s:10:\"CustomMenu\";i:85;s:4:\"Card\";i:10;s:8:\"Leaflets\";i:5;s:11:\"CustomReply\";i:20;s:4:\"Vote\";i:1;s:4:\"Exam\";i:3;s:4:\"Juhe\";i:3;s:5:\"Robot\";i:2;s:6:\"Wecome\";i:13;s:10:\"UserCenter\";i:20;s:11:\"Suggestions\";i:2;s:10:\"HelloWorld\";i:1;s:7:\"Scratch\";i:2;}');
INSERT INTO `wp_tongji` VALUES ('3', 'gh_ccbc7c79380e', '201406', '20140612', 'a:22:{s:10:\"UserCenter\";i:15;s:8:\"Leaflets\";i:20;s:6:\"Wecome\";i:70;s:10:\"CustomMenu\";i:31;s:11:\"CustomReply\";i:36;s:11:\"Suggestions\";i:2;s:5:\"Robot\";i:3;s:5:\"Forms\";i:7;s:7:\"WeiSite\";i:107;s:4:\"Card\";i:8;s:4:\"Chat\";i:22;s:3:\"Diy\";i:14;s:4:\"Juhe\";i:4;s:10:\"HelloWorld\";i:3;s:14:\"EditorForAdmin\";i:10;s:4:\"Vote\";i:2;s:6:\"Survey\";i:2;s:6:\"Coupon\";i:1;s:7:\"Scratch\";i:1;s:4:\"Exam\";i:10;s:4:\"Test\";i:4;s:10:\"Extensions\";i:3;}');
INSERT INTO `wp_tongji` VALUES ('4', '-1', '201406', '20140612', 'a:1:{s:11:\"CustomReply\";i:4;}');
INSERT INTO `wp_tongji` VALUES ('5', 'gh_ccbc7c79380e', '201406', '20140613', 'a:15:{s:4:\"Chat\";i:38;s:7:\"WeiSite\";i:302;s:8:\"Leaflets\";i:10;s:6:\"Wecome\";i:21;s:11:\"CustomReply\";i:216;s:10:\"CustomMenu\";i:24;s:10:\"UserCenter\";i:24;s:4:\"Card\";i:2;s:14:\"EditorForAdmin\";i:6;s:3:\"Diy\";i:2;s:4:\"Exam\";i:3;s:10:\"HelloWorld\";i:1;s:6:\"Survey\";i:1;s:7:\"_addons\";i:4;s:5:\"Forms\";i:1;}');
INSERT INTO `wp_tongji` VALUES ('6', '-1', '201406', '20140613', 'a:1:{s:7:\"WeiSite\";i:12;}');
INSERT INTO `wp_tongji` VALUES ('7', 'gh_ccbc7c79380e', '201406', '20140614', 'a:15:{s:7:\"WeiSite\";i:14;s:4:\"Chat\";i:17;s:13:\"MicroCatering\";i:14;s:7:\"Weather\";i:11;s:10:\"CustomMenu\";i:2;s:11:\"Suggestions\";i:2;s:10:\"Extensions\";i:3;s:4:\"Juhe\";i:1;s:10:\"HelloWorld\";i:1;s:4:\"Card\";i:1;s:10:\"UserCenter\";i:1;s:6:\"Wecome\";i:2;s:4:\"Exam\";i:1;s:5:\"Forms\";i:1;s:5:\"Robot\";i:1;}');
INSERT INTO `wp_tongji` VALUES ('8', '-1', '201406', '20140614', 'a:1:{s:7:\"WeiSite\";i:1;}');
INSERT INTO `wp_tongji` VALUES ('9', 'gh_ccbc7c79380e', '201406', '20140615', 'a:21:{s:10:\"CustomMenu\";i:124;s:7:\"WeiSite\";i:287;s:11:\"CustomReply\";i:78;s:5:\"Forms\";i:2;s:3:\"Diy\";i:2;s:4:\"Juhe\";i:2;s:4:\"Card\";i:14;s:8:\"Leaflets\";i:2;s:4:\"Chat\";i:25;s:14:\"EditorForAdmin\";i:4;s:5:\"Robot\";i:1;s:6:\"Coupon\";i:7;s:7:\"Scratch\";i:3;s:10:\"HelloWorld\";i:1;s:11:\"Suggestions\";i:16;s:6:\"Survey\";i:5;s:4:\"Vote\";i:3;s:10:\"UserCenter\";i:12;s:6:\"Wecome\";i:2;s:10:\"Extensions\";i:1;s:4:\"Exam\";i:4;}');
INSERT INTO `wp_tongji` VALUES ('10', '-1', '201406', '20140615', 'a:2:{s:7:\"_addons\";i:2;s:7:\"WeiSite\";i:10;}');
INSERT INTO `wp_tongji` VALUES ('11', 'gh_ccbc7c79380e', '201406', '20140616', 'a:16:{s:7:\"WeiSite\";i:237;s:10:\"CustomMenu\";i:61;s:10:\"Extensions\";i:3;s:5:\"Forms\";i:2;s:4:\"Chat\";i:7;s:11:\"CustomReply\";i:18;s:4:\"Exam\";i:1;s:4:\"Juhe\";i:2;s:3:\"Diy\";i:2;s:5:\"Robot\";i:1;s:11:\"Suggestions\";i:1;s:6:\"Survey\";i:1;s:6:\"Wecome\";i:1;s:4:\"Card\";i:1;s:10:\"HelloWorld\";i:1;s:13:\"MicroCatering\";i:2;}');
INSERT INTO `wp_tongji` VALUES ('12', '-1', '201406', '20140616', 'a:1:{s:7:\"WeiSite\";i:1;}');

-- -----------------------------
-- Table structure for `wp_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ucenter_admin`;
CREATE TABLE `wp_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `wp_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ucenter_app`;
CREATE TABLE `wp_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `wp_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ucenter_member`;
CREATE TABLE `wp_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(255) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `openid` varchar(200) DEFAULT NULL,
  `token` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=380 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `wp_ucenter_member`
-- -----------------------------
INSERT INTO `wp_ucenter_member` VALUES ('1', 'joint4', 'ab6e54141023e353cf9e3d138c0d4e0c', '601855132@qq.com', '', '1402479145', '454304396', '1402892369', '454301311', '1402479145', '1', '', '');
INSERT INTO `wp_ucenter_member` VALUES ('363', '539828a06d30580', '4784a8e245104b4ec68e9d3a5d00bd96', '1402480800@weiphp.cn', '', '1402480800', '1709325908', '0', '0', '1402480800', '1', 'oTsZWuNOJAnjoXJStasWFY4VKNoI', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('364', '539834ce0183d38', '4784a8e245104b4ec68e9d3a5d00bd96', '1402483918@weiphp.cn', '', '1402483917', '1709325909', '0', '0', '1402483917', '1', 'oTsZWuGuBk4HnIujifJU2HliIXRU', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('365', '539904e0a50ce95', '4784a8e245104b4ec68e9d3a5d00bd96', '1402537184@weiphp.cn', '', '1402537184', '1709325909', '0', '0', '1402537184', '1', 'oTsZWuGIHftATRBxGwZugNAqHv8s', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('366', '539914df33d1066', '4784a8e245104b4ec68e9d3a5d00bd96', '1402541279@weiphp.cn', '', '1402541279', '1709325909', '0', '0', '1402541279', '1', 'oTsZWuJbkoTqSEMqfT_aZhANLxzc', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('367', '53999377df37e77', '4784a8e245104b4ec68e9d3a5d00bd96', '1402573687@weiphp.cn', '', '1402573687', '1709325910', '0', '0', '1402573687', '1', 'oTsZWuJJRYcUbIEMw8gzbjRndC38', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('368', '5399949e70d4581', '4784a8e245104b4ec68e9d3a5d00bd96', '1402573982@weiphp.cn', '', '1402573982', '1709325910', '0', '0', '1402573982', '1', 'oTsZWuNrKNbNIXHkRo2oVrR3it4A', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('369', '539998ef285d720', '4784a8e245104b4ec68e9d3a5d00bd96', '1402575087@weiphp.cn', '', '1402575087', '1709325907', '0', '0', '1402575087', '1', 'oTsZWuPSlInJ4qGDAkMmJmMeZp7I', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('370', '539a4d764dcca59', '4784a8e245104b4ec68e9d3a5d00bd96', '1402621302@weiphp.cn', '', '1402621302', '1709325904', '0', '0', '1402621302', '1', 'oTsZWuO8Ot-eM4mXBWCqgyrUuyrY', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('371', 'xxkxxk831', '614ebf75fdaa590e418909a345a986a1', 'xxkxxk831@qq.com', '', '1402639274', '454333053', '1402795674', '454301311', '1402639274', '1', '', '');
INSERT INTO `wp_ucenter_member` VALUES ('372', 'admin', 'ae33a42933870befd236d8bdbcb2b083', '601855133@qq.com', '', '1402640384', '454300729', '0', '0', '1402640384', '1', '', '');
INSERT INTO `wp_ucenter_member` VALUES ('373', '539a9c148447c39', '4784a8e245104b4ec68e9d3a5d00bd96', '1402641428@weiphp.cn', '', '1402641427', '1709325910', '0', '0', '1402641427', '1', 'oTsZWuPrtyT5GxIcMpfuHIe8GEmU', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('374', '539bf3d2066e585', '4784a8e245104b4ec68e9d3a5d00bd96', '1402729426@weiphp.cn', '', '1402729425', '1709325909', '0', '0', '1402729425', '1', 'oTsZWuL1V3a8-64hyvBAVwlWHACs', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('375', '539bf604760b861', '4784a8e245104b4ec68e9d3a5d00bd96', '1402729988@weiphp.cn', '', '1402729988', '1709325903', '0', '0', '1402729988', '1', 'oTsZWuEXOLwTo0dYNRrePYkGf2PA', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('376', 'joint5', 'ab6e54141023e353cf9e3d138c0d4e0c', '601855134@qq.com', '', '1402737752', '454300729', '1402737810', '454300729', '1402737752', '1', '', '');
INSERT INTO `wp_ucenter_member` VALUES ('377', '539d611bc295e97', '4784a8e245104b4ec68e9d3a5d00bd96', '1402822939@weiphp.cn', '', '1402822939', '1709325906', '0', '0', '1402822939', '1', 'oTsZWuOzNLvJDBzj8MJ46znKyLbU', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('378', '539d77e26d09971', '4784a8e245104b4ec68e9d3a5d00bd96', '1402828770@weiphp.cn', '', '1402828769', '1709325909', '0', '0', '1402828769', '1', 'oTsZWuLBlcRHK-6QTiJeB9XIbU8o', 'gh_ccbc7c79380e');
INSERT INTO `wp_ucenter_member` VALUES ('379', '539e59fb5ed2738', '4784a8e245104b4ec68e9d3a5d00bd96', '1402886651@weiphp.cn', '', '1402886651', '1709325910', '0', '0', '1402886651', '1', 'oTsZWuFBUMzLNp4ASWPQWojAF_ZY', 'gh_ccbc7c79380e');

-- -----------------------------
-- Table structure for `wp_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `wp_ucenter_setting`;
CREATE TABLE `wp_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `wp_update_version`
-- -----------------------------
DROP TABLE IF EXISTS `wp_update_version`;
CREATE TABLE `wp_update_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `version` int(10) unsigned NOT NULL COMMENT '版本号',
  `title` varchar(50) NOT NULL COMMENT '升级包名',
  `description` text NOT NULL COMMENT '描述',
  `create_date` int(10) NOT NULL COMMENT '创建时间',
  `download_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载统计',
  `package` varchar(255) NOT NULL COMMENT '升级包地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_url`
-- -----------------------------
DROP TABLE IF EXISTS `wp_url`;
CREATE TABLE `wp_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `wp_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `wp_userdata`;
CREATE TABLE `wp_userdata` (
  `uid` int(10) DEFAULT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_vote`
-- -----------------------------
DROP TABLE IF EXISTS `wp_vote`;
CREATE TABLE `wp_vote` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(50) NOT NULL COMMENT '关键词',
  `title` varchar(100) NOT NULL COMMENT '投票标题',
  `description` text NOT NULL COMMENT '投票描述',
  `picurl` int(10) unsigned NOT NULL COMMENT '封面图片',
  `type` char(10) NOT NULL DEFAULT '0' COMMENT '选择类型',
  `start_date` int(10) NOT NULL COMMENT '开始日期',
  `end_date` int(10) NOT NULL COMMENT '结束日期',
  `is_img` tinyint(2) NOT NULL DEFAULT '0' COMMENT '文字/图片投票',
  `vote_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '投票数',
  `cTime` int(10) NOT NULL COMMENT '投票创建时间',
  `mTime` int(10) NOT NULL COMMENT '更新时间',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_vote_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_vote_log`;
CREATE TABLE `wp_vote_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `vote_id` int(10) unsigned NOT NULL COMMENT '投票ID',
  `user_id` int(10) NOT NULL COMMENT '用户ID',
  `token` varchar(255) NOT NULL COMMENT '用户TOKEN',
  `options` varchar(255) NOT NULL COMMENT '选择选项',
  `cTime` int(10) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_vote_option`
-- -----------------------------
DROP TABLE IF EXISTS `wp_vote_option`;
CREATE TABLE `wp_vote_option` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `vote_id` int(10) unsigned NOT NULL COMMENT '投票ID',
  `name` varchar(255) NOT NULL COMMENT '选项标题',
  `image` int(10) unsigned NOT NULL COMMENT '图片选项',
  `opt_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当前选项投票数',
  `order` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '选项排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_weisite_category`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_category`;
CREATE TABLE `wp_weisite_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(100) NOT NULL COMMENT '分类标题',
  `icon` int(10) unsigned DEFAULT NULL COMMENT '分类图片',
  `url` varchar(255) NOT NULL COMMENT '外链',
  `is_show` tinyint(2) NOT NULL DEFAULT '1' COMMENT '显示',
  `token` varchar(100) DEFAULT NULL COMMENT 'Token',
  `sort` int(10) DEFAULT '0' COMMENT '排序号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_weisite_category`
-- -----------------------------
INSERT INTO `wp_weisite_category` VALUES ('60', '亲子游戏', '374', '', '1', 'gh_ccbc7c79380e', '2');
INSERT INTO `wp_weisite_category` VALUES ('61', '学前教育', '375', '', '1', 'gh_ccbc7c79380e', '1');
INSERT INTO `wp_weisite_category` VALUES ('59', '健康保健', '372', '', '1', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_category` VALUES ('62', '备孕知识', '396', '', '1', 'gh_ccbc7c79380e', '9');
INSERT INTO `wp_weisite_category` VALUES ('63', '孕期知识', '397', '', '1', 'gh_ccbc7c79380e', '8');
INSERT INTO `wp_weisite_category` VALUES ('64', '婴儿护理', '399', '', '1', 'gh_ccbc7c79380e', '8');
INSERT INTO `wp_weisite_category` VALUES ('65', '产后康复', '398', '', '1', 'gh_ccbc7c79380e', '8');
INSERT INTO `wp_weisite_category` VALUES ('66', '宝贝秀', '400', '', '1', 'gh_ccbc7c79380e', '10');
INSERT INTO `wp_weisite_category` VALUES ('67', '交流互动', '405', '', '1', 'gh_ccbc7c79380e', '10');
INSERT INTO `wp_weisite_category` VALUES ('68', '幸运大转�\�', '402', '', '1', 'gh_ccbc7c79380e', '10');
INSERT INTO `wp_weisite_category` VALUES ('69', '积分兑换', '404', '', '1', 'gh_ccbc7c79380e', '10');
INSERT INTO `wp_weisite_category` VALUES ('70', '关于我们', '406', '', '1', 'gh_ccbc7c79380e', '10');
INSERT INTO `wp_weisite_category` VALUES ('71', '成长教育', '403', '', '1', 'gh_ccbc7c79380e', '8');

-- -----------------------------
-- Table structure for `wp_weisite_cms`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_cms`;
CREATE TABLE `wp_weisite_cms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `keyword` varchar(100) NOT NULL COMMENT '关键词',
  `keyword_type` tinyint(2) DEFAULT NULL COMMENT '关键词类型',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `intro` text COMMENT '简介',
  `cate_id` int(10) unsigned DEFAULT '0' COMMENT '所属类别',
  `cover` int(10) unsigned DEFAULT NULL COMMENT '封面图片',
  `content` text NOT NULL COMMENT '内容',
  `cTime` int(10) DEFAULT NULL COMMENT '发布时间',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序号',
  `view_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `wp_weisite_footer`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_footer`;
CREATE TABLE `wp_weisite_footer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `url` varchar(255) DEFAULT NULL COMMENT '关联URL',
  `title` varchar(50) NOT NULL COMMENT '菜单名',
  `pid` tinyint(2) DEFAULT '0' COMMENT '一级菜单',
  `sort` tinyint(4) DEFAULT '0' COMMENT '排序号',
  `token` varchar(255) NOT NULL COMMENT 'Token',
  `icon` int(10) unsigned DEFAULT NULL COMMENT '图标',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_weisite_footer`
-- -----------------------------
INSERT INTO `wp_weisite_footer` VALUES ('53', '', '亲子时光', '47', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('54', '', '学前教育', '47', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('55', '', '育儿互动', '48', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('56', '', '酷珠早教', '48', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('51', '', '健康保健', '47', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('52', '', '营养饮食', '47', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('50', '', '健康保健', '40', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('59', '', '会员积分', '49', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('58', '', '微网�\�', '49', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('60', '', '一周资�\�', '49', '0', 'gh_ccbc7c79380e', '0');
INSERT INTO `wp_weisite_footer` VALUES ('61', '', '关于我们', '49', '0', 'gh_ccbc7c79380e', '0');

-- -----------------------------
-- Table structure for `wp_weisite_slideshow`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weisite_slideshow`;
CREATE TABLE `wp_weisite_slideshow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `img` int(10) unsigned NOT NULL COMMENT '图片',
  `url` varchar(255) DEFAULT NULL COMMENT '链接地址',
  `is_show` tinyint(2) DEFAULT '1' COMMENT '是否显示',
  `sort` int(10) unsigned DEFAULT '0' COMMENT '排序',
  `token` varchar(100) DEFAULT NULL COMMENT 'Token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `wp_weisite_slideshow`
-- -----------------------------
INSERT INTO `wp_weisite_slideshow` VALUES ('27', '1', '367', 'http://www.3g.qq.com', '1', '0', '539811ab60f21');
INSERT INTO `wp_weisite_slideshow` VALUES ('28', '新浪', '365', '', '1', '1', '539811ab60f21');
INSERT INTO `wp_weisite_slideshow` VALUES ('29', '1', '367', 'http://www.3g.qq.com', '1', '0', 'gh_ccbc7c79380e');

-- -----------------------------
-- Table structure for `wp_weixin_log`
-- -----------------------------
DROP TABLE IF EXISTS `wp_weixin_log`;
CREATE TABLE `wp_weixin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cTime` int(11) DEFAULT NULL,
  `cTime_format` varchar(30) DEFAULT NULL,
  `data` text,
  `data_post` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7790 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `wp_weixin_log`
-- -----------------------------
INSERT INTO `wp_weixin_log` VALUES ('7213', '1402480769', '2014-06-11 17:59:29', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402480772\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402480772</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7214', '1402480800', '2014-06-11 18:00:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402480803\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402480803</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7215', '1402480800', '2014-06-11 18:00:00', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402480800</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7216', '1402480849', '2014-06-11 18:00:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402480852\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:4:\"test\";s:5:\"MsgId\";s:19:\"6023609392806817529\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402480852</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[test]]></Content>\n<MsgId>6023609392806817529</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7217', '1402480849', '2014-06-11 18:00:49', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[deletedanswer]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402480849</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7218', '1402482756', '2014-06-11 18:32:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402482759\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402482759</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7219', '1402482791', '2014-06-11 18:33:11', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402482795\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402482795</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7220', '1402482791', '2014-06-11 18:33:11', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402482791</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7221', '1402482977', '2014-06-11 18:36:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402482979\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402482979</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7222', '1402482993', '2014-06-11 18:36:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402482997\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402482997</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7223', '1402482993', '2014-06-11 18:36:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402482993</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7224', '1402483139', '2014-06-11 18:38:59', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402483141\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402483141</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7225', '1402483159', '2014-06-11 18:39:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402483161\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402483161</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7226', '1402483159', '2014-06-11 18:39:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402483159</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7227', '1402483917', '2014-06-11 18:51:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGuBk4HnIujifJU2HliIXRU\";s:10:\"CreateTime\";s:10:\"1402483920\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></FromUserName>\n<CreateTime>1402483920</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7228', '1402483917', '2014-06-11 18:51:57', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402483917</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7229', '1402484773', '2014-06-11 19:06:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402484775\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402484775</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7230', '1402484790', '2014-06-11 19:06:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402484793\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402484793</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7231', '1402484790', '2014-06-11 19:06:30', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402484790</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7232', '1402485017', '2014-06-11 19:10:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402485020\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402485020</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7233', '1402485037', '2014-06-11 19:10:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402485041\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402485041</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7234', '1402485037', '2014-06-11 19:10:37', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402485037</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7235', '1402485326', '2014-06-11 19:15:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402485328\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023628617080434982\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402485328</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023628617080434982</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7236', '1402485327', '2014-06-11 19:15:27', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402485326</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7237', '1402485342', '2014-06-11 19:15:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402485345\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:4:\"test\";s:5:\"MsgId\";s:19:\"6023628690094879016\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402485345</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[test]]></Content>\n<MsgId>6023628690094879016</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7238', '1402485342', '2014-06-11 19:15:42', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[tesat]]></Title><Description><![CDATA[tests]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/52.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402485342</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7239', '1402486848', '2014-06-11 19:40:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402486851\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6023635158315626981\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402486851</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6023635158315626981</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7240', '1402486848', '2014-06-11 19:40:48', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402486848</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7241', '1402487174', '2014-06-11 19:46:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402487178\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402487178</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7242', '1402487197', '2014-06-11 19:46:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402487201\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402487201</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7243', '1402487197', '2014-06-11 19:46:37', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂！]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402487197</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7244', '1402487624', '2014-06-11 19:53:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402487627\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402487627</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7245', '1402487646', '2014-06-11 19:54:06', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402487649\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402487649</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7246', '1402487646', '2014-06-11 19:54:06', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂！]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402487646</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7247', '1402487658', '2014-06-11 19:54:18', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402487662\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿交流\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402487662</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿交流]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7248', '1402487659', '2014-06-11 19:54:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402487663\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"互动社区\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402487663</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[互动社区]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7249', '1402487660', '2014-06-11 19:54:20', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402487658</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7250', '1402487660', '2014-06-11 19:54:20', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402487659</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7251', '1402488097', '2014-06-11 20:01:37', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[请先<a href=\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/UserCenter/_controller/UserCenter/_action/edit/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html\">绑定账号</a>再使用]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402488097</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7252', '1402488140', '2014-06-11 20:02:20', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[请先<a href=\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/UserCenter/_controller/UserCenter/_action/edit/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html\">绑定账号</a>再使用]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402488140</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7253', '1402488274', '2014-06-11 20:04:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402488278\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6023641287233958578\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402488278</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6023641287233958578</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7254', '1402488274', '2014-06-11 20:04:34', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402488274</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7255', '1402489771', '2014-06-11 20:29:31', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402489775\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023647716800000891\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402489775</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023647716800000891</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7256', '1402489771', '2014-06-11 20:29:31', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402489771</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7257', '1402492133', '2014-06-11 21:08:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402492137\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023657861512754397\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402492137</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023657861512754397</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7258', '1402492134', '2014-06-11 21:08:54', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492133</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7259', '1402492143', '2014-06-11 21:09:03', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492146\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492146</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7260', '1402492145', '2014-06-11 21:09:05', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492143</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7261', '1402492151', '2014-06-11 21:09:11', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492152\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492152</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7262', '1402492152', '2014-06-11 21:09:12', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492151</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7263', '1402492156', '2014-06-11 21:09:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492159\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"酷珠早教\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492159</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[酷珠早教]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7264', '1402492157', '2014-06-11 21:09:17', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492156</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7265', '1402492161', '2014-06-11 21:09:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492164\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492164</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7266', '1402492161', '2014-06-11 21:09:21', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492161</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7267', '1402492163', '2014-06-11 21:09:23', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492166\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"会员积分\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492166</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员积分]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7268', '1402492166', '2014-06-11 21:09:26', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492163</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7269', '1402492166', '2014-06-11 21:09:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492169\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"一周资�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492169</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[一周资讯]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7270', '1402492167', '2014-06-11 21:09:27', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492166</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7271', '1402492169', '2014-06-11 21:09:29', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492172\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"关于我们\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492172</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[关于我们]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7272', '1402492170', '2014-06-11 21:09:30', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492169</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7273', '1402492173', '2014-06-11 21:09:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492176\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子时光\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492176</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子时光]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7274', '1402492174', '2014-06-11 21:09:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492173</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7275', '1402492213', '2014-06-11 21:10:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492216\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492216</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7276', '1402492214', '2014-06-11 21:10:14', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492213</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7277', '1402492230', '2014-06-11 21:10:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492232\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492232</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7278', '1402492231', '2014-06-11 21:10:31', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492230</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7279', '1402492237', '2014-06-11 21:10:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492240\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492240</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7280', '1402492237', '2014-06-11 21:10:37', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492237</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7281', '1402492289', '2014-06-11 21:11:29', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492288\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"会员积分\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492288</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员积分]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7282', '1402492292', '2014-06-11 21:11:32', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492289</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7283', '1402492294', '2014-06-11 21:11:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492296\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492296</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7284', '1402492295', '2014-06-11 21:11:35', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492294</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7285', '1402492296', '2014-06-11 21:11:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492298\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"酷珠早教\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492298</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[酷珠早教]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7286', '1402492298', '2014-06-11 21:11:38', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492296</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7287', '1402492298', '2014-06-11 21:11:38', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492301\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492301</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7288', '1402492299', '2014-06-11 21:11:39', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492298</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7289', '1402492337', '2014-06-11 21:12:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402492340\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"微信官网\";s:5:\"MsgId\";s:19:\"6023658733391115535\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402492340</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微信官网]]></Content>\n<MsgId>6023658733391115535</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7290', '1402492338', '2014-06-11 21:12:18', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492337</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7291', '1402492343', '2014-06-11 21:12:23', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492346\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"会员积分\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492346</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员积分]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7292', '1402492352', '2014-06-11 21:12:32', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492355\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492355</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7293', '1402492352', '2014-06-11 21:12:32', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492352</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7294', '1402492358', '2014-06-11 21:12:38', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492360\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492360</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7295', '1402492362', '2014-06-11 21:12:42', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492358</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7296', '1402492364', '2014-06-11 21:12:44', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492343</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7297', '1402492366', '2014-06-11 21:12:46', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402492369\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6023658857945167126\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402492369</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6023658857945167126</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7298', '1402492366', '2014-06-11 21:12:46', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492366</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7299', '1402492481', '2014-06-11 21:14:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492484\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492484</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7300', '1402492482', '2014-06-11 21:14:42', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492481</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7301', '1402492501', '2014-06-11 21:15:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492504\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492504</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7302', '1402492501', '2014-06-11 21:15:01', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492501</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7303', '1402492585', '2014-06-11 21:16:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492588\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023659798543004964\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492588</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023659798543004964</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7304', '1402492585', '2014-06-11 21:16:25', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuJkMh089o6vRzOOT_7k2gso/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492585</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7305', '1402492672', '2014-06-11 21:17:52', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJkMh089o6vRzOOT_7k2gso\";s:10:\"CreateTime\";s:10:\"1402492675\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023660172205159727\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></FromUserName>\n<CreateTime>1402492675</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023660172205159727</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7306', '1402492672', '2014-06-11 21:17:52', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuJkMh089o6vRzOOT_7k2gso/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJkMh089o6vRzOOT_7k2gso]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402492672</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7307', '1402495275', '2014-06-11 22:01:15', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402495277\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6023671347710064332\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402495277</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6023671347710064332</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7308', '1402495275', '2014-06-11 22:01:15', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuJbkoTqSEMqfT_aZhANLxzc.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402495275</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7309', '1402495337', '2014-06-11 22:02:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402495338\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402495338</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7310', '1402495339', '2014-06-11 22:02:19', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402495337</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7311', '1402495341', '2014-06-11 22:02:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402495344\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402495344</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7312', '1402495341', '2014-06-11 22:02:21', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402495341</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7313', '1402495345', '2014-06-11 22:02:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402495348\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"关于我们\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402495348</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[关于我们]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7314', '1402495346', '2014-06-11 22:02:26', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402495345</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7315', '1402495363', '2014-06-11 22:02:43', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402495365\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"一周资�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402495365</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[一周资讯]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7316', '1402495364', '2014-06-11 22:02:44', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402495363</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7317', '1402495370', '2014-06-11 22:02:50', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402495373\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402495373</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7318', '1402495371', '2014-06-11 22:02:51', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402495370</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7319', '1402535770', '2014-06-12 09:16:10', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402535774\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6023845281000653586\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402535774</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6023845281000653586</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7320', '1402535770', '2014-06-12 09:16:10', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402535770</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7321', '1402536771', '2014-06-12 09:32:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402536774\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402536774</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7322', '1402536772', '2014-06-12 09:32:52', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402536771</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7323', '1402537161', '2014-06-12 09:39:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402537164\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402537164</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7324', '1402537184', '2014-06-12 09:39:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402537188\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402537188</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7325', '1402537184', '2014-06-12 09:39:44', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂！]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539904738ffef.jpg]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402537184</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7326', '1402537352', '2014-06-12 09:42:32', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402537354\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402537354</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7327', '1402537373', '2014-06-12 09:42:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402537377\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402537377</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7328', '1402537373', '2014-06-12 09:42:53', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<img src=\"http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539904738ffef.jpg\"  alt=\"欢迎来到酷珠儿童成长学堂\" />]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402537373</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7329', '1402537478', '2014-06-12 09:44:38', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402537481\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402537481</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7330', '1402537493', '2014-06-12 09:44:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402537496\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402537496</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7331', '1402537493', '2014-06-12 09:44:53', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<a href=\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html\">微首�\�</a>]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402537493</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7332', '1402537625', '2014-06-12 09:47:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402537629\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402537629</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7333', '1402537625', '2014-06-12 09:47:05', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402537625</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7334', '1402538290', '2014-06-12 09:58:10', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402538294\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402538294</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7335', '1402538326', '2014-06-12 09:58:46', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402538328\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402538328</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7336', '1402538326', '2014-06-12 09:58:46', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<a href=\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html\">微首�\�</a>]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/index.php?s=/home/addons/execute/_addons/CustomReply/_controller/CustomReply/_action/edit/id/53/model/64.html]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402538326</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7337', '1402538413', '2014-06-12 10:00:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402538417\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402538417</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7338', '1402538435', '2014-06-12 10:00:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402538438\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402538438</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7339', '1402538435', '2014-06-12 10:00:35', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/index.php?s=/home/addons/execute/_addons/CustomReply/_controller/CustomReply/_action/edit/id/53/model/64.html]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402538435</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7340', '1402538535', '2014-06-12 10:02:15', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402538538\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402538538</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7341', '1402538571', '2014-06-12 10:02:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402538574\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402538574</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7342', '1402538571', '2014-06-12 10:02:51', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402538571</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7343', '1402538645', '2014-06-12 10:04:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402538649\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402538649</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7344', '1402538662', '2014-06-12 10:04:22', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402538664\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402538664</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7345', '1402538662', '2014-06-12 10:04:22', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402538662</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7346', '1402538804', '2014-06-12 10:06:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402538808\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402538808</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7347', '1402538805', '2014-06-12 10:06:45', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402538804</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7348', '1402539432', '2014-06-12 10:17:12', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402539436\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402539436</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7349', '1402539489', '2014-06-12 10:18:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402539492\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402539492</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7350', '1402539489', '2014-06-12 10:18:09', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<img src=\"http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif\" />]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402539488</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7351', '1402539544', '2014-06-12 10:19:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402539547\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402539547</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7352', '1402539595', '2014-06-12 10:19:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402539599\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402539599</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7353', '1402539595', '2014-06-12 10:19:55', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<img src=\"[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]\" />]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402539595</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7354', '1402539668', '2014-06-12 10:21:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402539672\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402539672</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7355', '1402539683', '2014-06-12 10:21:23', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402539687\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402539687</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7356', '1402539683', '2014-06-12 10:21:23', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<img src=\"[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]\" ></img>]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402539683</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7357', '1402540072', '2014-06-12 10:27:52', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540073\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540073</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7358', '1402540090', '2014-06-12 10:28:10', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540092\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540092</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7359', '1402540090', '2014-06-12 10:28:10', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<img style=\"visibility: hidden;\" src=\"http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif\" ></img>]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402540090</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7360', '1402540290', '2014-06-12 10:31:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540293\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540293</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7361', '1402540307', '2014-06-12 10:31:47', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540310\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540310</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7362', '1402540307', '2014-06-12 10:31:47', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<img src=\"/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif\"/>]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402540307</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7363', '1402540398', '2014-06-12 10:33:18', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540401\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540401</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7364', '1402540439', '2014-06-12 10:33:59', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540443\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540443</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7365', '1402540439', '2014-06-12 10:33:59', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<p><img src=\"/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif\"/></p>]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402540439</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7366', '1402540523', '2014-06-12 10:35:23', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540527\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540527</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7367', '1402540539', '2014-06-12 10:35:39', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540543\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540543</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7368', '1402540539', '2014-06-12 10:35:39', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[Hello]]></Title><Description><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<p><img src=\"/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif\"/></p>]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402540539</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7369', '1402540580', '2014-06-12 10:36:20', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402540584\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023865939793348130\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402540584</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023865939793348130</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7370', '1402540580', '2014-06-12 10:36:20', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402540580</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7371', '1402541246', '2014-06-12 10:47:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402541249\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402541249</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7372', '1402541279', '2014-06-12 10:47:59', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402541283\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402541283</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7373', '1402541279', '2014-06-12 10:47:59', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n<a href=\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuJbkoTqSEMqfT_aZhANLxzc.html\">微首�\�</a>]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402541279</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7374', '1402541348', '2014-06-12 10:49:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402541351\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子时光\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402541351</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子时光]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7375', '1402541348', '2014-06-12 10:49:08', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402541347</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7376', '1402541412', '2014-06-12 10:50:12', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402541416\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402541416</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7377', '1402541474', '2014-06-12 10:51:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402541478\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402541478</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7378', '1402541474', '2014-06-12 10:51:14', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[欢迎来到酷珠儿童成长学堂的微官网]]></Title><Description><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402541474</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7379', '1402544568', '2014-06-12 11:42:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402544573\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6023883072417892464\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402544573</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6023883072417892464</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7380', '1402544569', '2014-06-12 11:42:49', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402544568</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7381', '1402559836', '2014-06-12 15:57:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559840\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559840</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7382', '1402559838', '2014-06-12 15:57:18', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559836</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7383', '1402559850', '2014-06-12 15:57:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559855\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子时光\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559855</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子时光]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7384', '1402559851', '2014-06-12 15:57:31', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559850</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7385', '1402559856', '2014-06-12 15:57:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559860\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559860</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7386', '1402559856', '2014-06-12 15:57:36', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559856</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7387', '1402559861', '2014-06-12 15:57:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559865\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"酷珠早教\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559865</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[酷珠早教]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7388', '1402559861', '2014-06-12 15:57:41', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559861</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7389', '1402559864', '2014-06-12 15:57:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559869\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559869</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7390', '1402559865', '2014-06-12 15:57:45', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559864</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7391', '1402559870', '2014-06-12 15:57:50', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559875\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559875</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7392', '1402559871', '2014-06-12 15:57:51', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559870</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7393', '1402559879', '2014-06-12 15:57:59', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559883\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559883</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7394', '1402559879', '2014-06-12 15:57:59', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559879</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7395', '1402559888', '2014-06-12 15:58:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559893\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"一周资�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559893</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[一周资讯]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7396', '1402559889', '2014-06-12 15:58:09', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559888</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7397', '1402559893', '2014-06-12 15:58:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402559897\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"关于我们\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402559897</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[关于我们]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7398', '1402559893', '2014-06-12 15:58:13', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402559893</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7399', '1402573687', '2014-06-12 19:48:07', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJJRYcUbIEMw8gzbjRndC38\";s:10:\"CreateTime\";s:10:\"1402573692\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJJRYcUbIEMw8gzbjRndC38]]></FromUserName>\n<CreateTime>1402573692</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7400', '1402573687', '2014-06-12 19:48:07', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[欢迎来到酷珠儿童成长学堂的微官网]]></Title><Description><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuJJRYcUbIEMw8gzbjRndC38.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJJRYcUbIEMw8gzbjRndC38]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402573687</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7401', '1402573982', '2014-06-12 19:53:02', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNrKNbNIXHkRo2oVrR3it4A\";s:10:\"CreateTime\";s:10:\"1402573986\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNrKNbNIXHkRo2oVrR3it4A]]></FromUserName>\n<CreateTime>1402573986</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7402', '1402573982', '2014-06-12 19:53:02', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[欢迎来到酷珠儿童成长学堂的微官网]]></Title><Description><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNrKNbNIXHkRo2oVrR3it4A.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNrKNbNIXHkRo2oVrR3it4A]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402573982</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7403', '1402575042', '2014-06-12 20:10:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402575047\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"关于我们\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402575047</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[关于我们]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7404', '1402575054', '2014-06-12 20:10:54', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402575042</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7405', '1402575087', '2014-06-12 20:11:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuPSlInJ4qGDAkMmJmMeZp7I\";s:10:\"CreateTime\";s:10:\"1402575092\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuPSlInJ4qGDAkMmJmMeZp7I]]></FromUserName>\n<CreateTime>1402575092</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7406', '1402575087', '2014-06-12 20:11:27', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[欢迎来到酷珠儿童成长学堂的微官网]]></Title><Description><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuPSlInJ4qGDAkMmJmMeZp7I.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuPSlInJ4qGDAkMmJmMeZp7I]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402575087</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7407', '1402580309', '2014-06-12 21:38:29', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuEtHb04AVck_CXISOy7vgos\";s:10:\"CreateTime\";s:10:\"1402580313\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuEtHb04AVck_CXISOy7vgos]]></FromUserName>\n<CreateTime>1402580313</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7408', '1402580325', '2014-06-12 21:38:45', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuEtHb04AVck_CXISOy7vgos]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402580309</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7409', '1402620953', '2014-06-13 08:55:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuI6yTio4eyNQdTInF88a0cA\";s:10:\"CreateTime\";s:10:\"1402620959\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuI6yTio4eyNQdTInF88a0cA]]></FromUserName>\n<CreateTime>1402620959</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7410', '1402620955', '2014-06-13 08:55:55', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuI6yTio4eyNQdTInF88a0cA]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402620953</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7411', '1402621302', '2014-06-13 09:01:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO8Ot-eM4mXBWCqgyrUuyrY\";s:10:\"CreateTime\";s:10:\"1402621308\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO8Ot-eM4mXBWCqgyrUuyrY]]></FromUserName>\n<CreateTime>1402621308</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7412', '1402621302', '2014-06-13 09:01:42', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[欢迎来到酷珠儿童成长学堂的微官网]]></Title><Description><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-12/539908c9eb2f4.gif]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuO8Ot-eM4mXBWCqgyrUuyrY.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO8Ot-eM4mXBWCqgyrUuyrY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402621302</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7413', '1402621500', '2014-06-13 09:05:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402621505\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402621505</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7414', '1402621537', '2014-06-13 09:05:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402621543\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402621543</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7415', '1402621537', '2014-06-13 09:05:37', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[欢迎来到酷珠儿童成长学堂的微官网]]></Title><Description><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�\r\n]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Editor/-1//2014-06-13/539a4de73c556.gif]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402621536</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7416', '1402621706', '2014-06-13 09:08:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402621712\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402621712</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7417', '1402621729', '2014-06-13 09:08:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402621736\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402621736</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7418', '1402621730', '2014-06-13 09:08:50', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[酷珠儿童成长学堂，更多精彩呈现，请点击进�\�<a href=\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html\">微首�\�</a>\r\n]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402621729</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7419', '1402622195', '2014-06-13 09:16:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402622201\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402622201</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7420', '1402622195', '2014-06-13 09:16:35', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402622195</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7421', '1402622413', '2014-06-13 09:20:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402622419\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402622419</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7422', '1402622413', '2014-06-13 09:20:13', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402622413</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7423', '1402622441', '2014-06-13 09:20:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402622446\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024217534406141220\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402622446</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024217534406141220</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7424', '1402622441', '2014-06-13 09:20:41', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402622441</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7425', '1402624517', '2014-06-13 09:55:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402624523\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微商�\�\";s:5:\"MsgId\";s:19:\"6024226455053215275\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402624523</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微商店]]></Content>\n<MsgId>6024226455053215275</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7426', '1402624518', '2014-06-13 09:55:18', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402624517</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7427', '1402625560', '2014-06-13 10:12:40', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402625566\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024230934704105138\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402625566</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024230934704105138</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7428', '1402625560', '2014-06-13 10:12:40', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首�\�<a href=\"[website]\">微首�\�</a>]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/54.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402625560</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7429', '1402626213', '2014-06-13 10:23:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402626219\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402626219</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7430', '1402626213', '2014-06-13 10:23:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402626213</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7431', '1402626245', '2014-06-13 10:24:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402626251\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024233876756702942\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402626251</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024233876756702942</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7432', '1402626245', '2014-06-13 10:24:05', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402626245</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7433', '1402626428', '2014-06-13 10:27:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402626433\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6024234658440750825\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402626433</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6024234658440750825</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7434', '1402626428', '2014-06-13 10:27:08', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402626428</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7435', '1402626501', '2014-06-13 10:28:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402626508\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024234980563298034\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402626508</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024234980563298034</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7436', '1402626502', '2014-06-13 10:28:22', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402626501</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7437', '1402632102', '2014-06-13 12:01:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402632108\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"会员积分\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402632108</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员积分]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7438', '1402632113', '2014-06-13 12:01:53', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402632101</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7439', '1402641428', '2014-06-13 14:37:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuPrtyT5GxIcMpfuHIe8GEmU\";s:10:\"CreateTime\";s:10:\"1402641434\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuPrtyT5GxIcMpfuHIe8GEmU]]></FromUserName>\n<CreateTime>1402641434</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7440', '1402641428', '2014-06-13 14:37:08', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuPrtyT5GxIcMpfuHIe8GEmU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402641427</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7441', '1402642471', '2014-06-13 14:54:31', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402642478\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:43:\"http://joint4.xicp.net/game/yijia/index.htm\";s:5:\"MsgId\";s:19:\"6024303571191017265\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402642478</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[http://joint4.xicp.net/game/yijia/index.htm]]></Content>\n<MsgId>6024303571191017265</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7442', '1402642472', '2014-06-13 14:54:32', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402642471</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7443', '1402642603', '2014-06-13 14:56:43', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuM10RYzxmAcI5-vfFC6rL0k\";s:10:\"CreateTime\";s:10:\"1402642608\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuM10RYzxmAcI5-vfFC6rL0k]]></FromUserName>\n<CreateTime>1402642608</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7444', '1402642604', '2014-06-13 14:56:44', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuM10RYzxmAcI5-vfFC6rL0k]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402642603</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7445', '1402642854', '2014-06-13 15:00:54', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402642861\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:26:\"weixin://addfriend/czxt001\";s:5:\"MsgId\";s:19:\"6024305216163491698\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402642861</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[weixin://addfriend/czxt001]]></Content>\n<MsgId>6024305216163491698</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7446', '1402642855', '2014-06-13 15:00:55', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402642854</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7447', '1402643022', '2014-06-13 15:03:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402643030\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6024305942012964748\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402643030</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6024305942012964748</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7448', '1402643022', '2014-06-13 15:03:42', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402643022</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7449', '1402643328', '2014-06-13 15:08:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402643332\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402643332</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7450', '1402643972', '2014-06-13 15:19:32', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGuBk4HnIujifJU2HliIXRU\";s:10:\"CreateTime\";s:10:\"1402643979\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></FromUserName>\n<CreateTime>1402643979</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7451', '1402643973', '2014-06-13 15:19:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402643972</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7452', '1402643985', '2014-06-13 15:19:45', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGuBk4HnIujifJU2HliIXRU\";s:10:\"CreateTime\";s:10:\"1402643991\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></FromUserName>\n<CreateTime>1402643991</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7453', '1402643986', '2014-06-13 15:19:46', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402643985</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7454', '1402643996', '2014-06-13 15:19:56', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGuBk4HnIujifJU2HliIXRU\";s:10:\"CreateTime\";s:10:\"1402644002\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGuBk4HnIujifJU2HliIXRU]]></FromUserName>\n<CreateTime>1402644002</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7455', '1402646079', '2014-06-13 15:54:39', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646086\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646086</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7456', '1402646080', '2014-06-13 15:54:40', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646079</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7457', '1402646086', '2014-06-13 15:54:46', 'a:11:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuA67gHUWZLkygIOZDUBFyHo\";s:10:\"CreateTime\";s:10:\"1402646092\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:17:\"MASSSENDJOBFINISH\";s:5:\"MsgID\";s:5:\"57690\";s:6:\"Status\";s:12:\"send success\";s:10:\"TotalCount\";s:3:\"793\";s:11:\"FilterCount\";s:3:\"783\";s:9:\"SentCount\";s:3:\"783\";s:10:\"ErrorCount\";s:1:\"0\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuA67gHUWZLkygIOZDUBFyHo]]></FromUserName>\n<CreateTime>1402646092</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[MASSSENDJOBFINISH]]></Event>\n<MsgID>57690</MsgID>\n<Status><![CDATA[send success]]></Status>\n<TotalCount>793</TotalCount>\n<FilterCount>783</FilterCount>\n<SentCount>783</SentCount>\n<ErrorCount>0</ErrorCount>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7458', '1402646094', '2014-06-13 15:54:54', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646101\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子时光\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646101</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子时光]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7459', '1402646094', '2014-06-13 15:54:54', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646094</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7460', '1402646100', '2014-06-13 15:55:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646107\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646107</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7461', '1402646101', '2014-06-13 15:55:01', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646100</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7462', '1402646106', '2014-06-13 15:55:06', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646113\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646113</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7463', '1402646107', '2014-06-13 15:55:07', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646106</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7464', '1402646112', '2014-06-13 15:55:12', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646120\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646120</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7465', '1402646113', '2014-06-13 15:55:13', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646112</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7466', '1402646127', '2014-06-13 15:55:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646135\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"一周资�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646135</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[一周资讯]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7467', '1402646128', '2014-06-13 15:55:28', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646127</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7468', '1402646133', '2014-06-13 15:55:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646141\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"关于我们\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646141</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[关于我们]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7469', '1402646134', '2014-06-13 15:55:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646133</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7470', '1402646143', '2014-06-13 15:55:43', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646150\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"酷珠早教\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646150</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[酷珠早教]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7471', '1402646143', '2014-06-13 15:55:43', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646143</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7472', '1402646161', '2014-06-13 15:56:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402646168\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:1:\"1\";s:5:\"MsgId\";s:19:\"6024319419620340047\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402646168</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[1]]></Content>\n<MsgId>6024319419620340047</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7473', '1402646161', '2014-06-13 15:56:01', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title>1</Title><Description>1</Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/Exam/_controller/Exam/_action/show/exam_id/9/token/gh_ccbc7c79380e/openid/oTsZWuJbkoTqSEMqfT_aZhANLxzc.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402646161</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7474', '1402646220', '2014-06-13 15:57:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuN_bRWurVItsdN35MFrUfkU\";s:10:\"CreateTime\";s:10:\"1402646227\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuN_bRWurVItsdN35MFrUfkU]]></FromUserName>\n<CreateTime>1402646227</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7475', '1402649681', '2014-06-13 16:54:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuEj7HRO2aNEHChkXnBc2E8I\";s:10:\"CreateTime\";s:10:\"1402649687\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></FromUserName>\n<CreateTime>1402649687</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7476', '1402649683', '2014-06-13 16:54:43', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402649681</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7477', '1402649705', '2014-06-13 16:55:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuEj7HRO2aNEHChkXnBc2E8I\";s:10:\"CreateTime\";s:10:\"1402649712\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></FromUserName>\n<CreateTime>1402649712</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7478', '1402649706', '2014-06-13 16:55:06', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402649705</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7479', '1402649715', '2014-06-13 16:55:15', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuEj7HRO2aNEHChkXnBc2E8I\";s:10:\"CreateTime\";s:10:\"1402649722\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></FromUserName>\n<CreateTime>1402649722</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7480', '1402649716', '2014-06-13 16:55:16', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402649715</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7481', '1402650545', '2014-06-13 17:09:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuEj7HRO2aNEHChkXnBc2E8I\";s:10:\"CreateTime\";s:10:\"1402650553\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子时光\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></FromUserName>\n<CreateTime>1402650553</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子时光]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7482', '1402650546', '2014-06-13 17:09:06', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuEj7HRO2aNEHChkXnBc2E8I]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402650545</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7483', '1402652305', '2014-06-13 17:38:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402652312\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402652312</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7484', '1402652305', '2014-06-13 17:38:25', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402652305</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7485', '1402652837', '2014-06-13 17:47:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402652845\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024348097116976259\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402652845</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024348097116976259</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7486', '1402652837', '2014-06-13 17:47:17', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402652837</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7487', '1402652885', '2014-06-13 17:48:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402652893\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:168:\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html\";s:5:\"MsgId\";s:19:\"6024348303275406476\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402652893</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Content>\n<MsgId>6024348303275406476</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7488', '1402652886', '2014-06-13 17:48:06', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402652885</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7489', '1402652955', '2014-06-13 17:49:15', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402652962\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024348599628149904\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402652962</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024348599628149904</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7490', '1402652955', '2014-06-13 17:49:15', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首�\�<a href=\"[website]\">微首�\�</a>]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/54.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402652955</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7491', '1402653044', '2014-06-13 17:50:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402653051\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024348981880239251\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402653051</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024348981880239251</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7492', '1402653044', '2014-06-13 17:50:44', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首�\�<a href=\"[website]\">微首�\�</a>]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/54.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402653044</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7493', '1402653125', '2014-06-13 17:52:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402653133\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024349334067557532\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402653133</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024349334067557532</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7494', '1402653125', '2014-06-13 17:52:05', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402653125</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7495', '1402653207', '2014-06-13 17:53:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402653214\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024349681959908514\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402653214</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024349681959908514</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7496', '1402653207', '2014-06-13 17:53:27', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402653207</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7497', '1402653332', '2014-06-13 17:55:32', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402653339\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:168:\"http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html\";s:5:\"MsgId\";s:19:\"6024350218830820532\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402653339</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/WeiSite/_controller/WeiSite/_action/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Content>\n<MsgId>6024350218830820532</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7498', '1402653333', '2014-06-13 17:55:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402653332</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7499', '1402653495', '2014-06-13 17:58:15', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402653503\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024350923205457095\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402653503</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024350923205457095</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7500', '1402653495', '2014-06-13 17:58:15', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402653495</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7501', '1402655163', '2014-06-13 18:26:03', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402655170\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024358082915939706\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402655170</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024358082915939706</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7502', '1402655163', '2014-06-13 18:26:03', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402655163</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7503', '1402655197', '2014-06-13 18:26:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402655205\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024358233239795071\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402655205</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024358233239795071</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7504', '1402655197', '2014-06-13 18:26:37', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402655197</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7505', '1402655281', '2014-06-13 18:28:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402655289\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024358594017047945\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402655289</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024358594017047945</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7506', '1402655281', '2014-06-13 18:28:01', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402655281</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7507', '1402655354', '2014-06-13 18:29:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402655360\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024358898959725963\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402655360</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024358898959725963</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7508', '1402655354', '2014-06-13 18:29:14', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402655354</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7509', '1402656321', '2014-06-13 18:45:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402656328\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024363056488068560\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402656328</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024363056488068560</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7510', '1402656321', '2014-06-13 18:45:21', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402656321</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7511', '1402656330', '2014-06-13 18:45:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402656338\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024363099437741523\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402656338</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024363099437741523</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7512', '1402656330', '2014-06-13 18:45:30', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402656330</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7513', '1402656353', '2014-06-13 18:45:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402656361\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024363198221989334\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402656361</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024363198221989334</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7514', '1402656353', '2014-06-13 18:45:53', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402656353</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7515', '1402656468', '2014-06-13 18:47:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402656473\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024363679258326499\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402656473</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024363679258326499</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7516', '1402656468', '2014-06-13 18:47:48', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402656468</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7517', '1402656696', '2014-06-13 18:51:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402656704\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024364671395771895\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402656704</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024364671395771895</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7518', '1402656696', '2014-06-13 18:51:36', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/Home/Addons/execute/_addons/CustomReply/_controller/CustomReply/_action/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402656696</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7519', '1402659441', '2014-06-13 19:37:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402659448\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024376456786032350\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402659448</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024376456786032350</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7520', '1402659441', '2014-06-13 19:37:21', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402659441</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7521', '1402660450', '2014-06-13 19:54:10', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402660458\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402660458</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7522', '1402660451', '2014-06-13 19:54:11', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402660450</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7523', '1402660473', '2014-06-13 19:54:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402660481\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402660481</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7524', '1402660473', '2014-06-13 19:54:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402660473</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7525', '1402660521', '2014-06-13 19:55:21', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402660529\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"微网\";s:5:\"MsgId\";s:19:\"6024381099645679442\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402660529</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微网]]></Content>\n<MsgId>6024381099645679442</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7526', '1402660523', '2014-06-13 19:55:23', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402660521</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7527', '1402660587', '2014-06-13 19:56:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402660594\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024381378818553686\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402660594</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024381378818553686</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7528', '1402660587', '2014-06-13 19:56:27', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402660587</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7529', '1402660733', '2014-06-13 19:58:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402660741\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024382010178746202\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402660741</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024382010178746202</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7530', '1402660733', '2014-06-13 19:58:53', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402660733</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7531', '1402660797', '2014-06-13 19:59:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402660805\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024382285056653151\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402660805</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024382285056653151</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7532', '1402660797', '2014-06-13 19:59:57', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402660797</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7533', '1402663031', '2014-06-13 20:37:11', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663038\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663038</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7534', '1402663031', '2014-06-13 20:37:11', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663031</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7535', '1402663128', '2014-06-13 20:38:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663135\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663135</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7536', '1402663128', '2014-06-13 20:38:48', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663128</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7537', '1402663137', '2014-06-13 20:38:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663145\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663145</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7538', '1402663187', '2014-06-13 20:39:47', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663194\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663194</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7539', '1402663187', '2014-06-13 20:39:47', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663187</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7540', '1402663197', '2014-06-13 20:39:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663205\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663205</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7541', '1402663197', '2014-06-13 20:39:57', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663197</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7542', '1402663249', '2014-06-13 20:40:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663257\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663257</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7543', '1402663249', '2014-06-13 20:40:49', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663249</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7544', '1402663279', '2014-06-13 20:41:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663286\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663286</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7545', '1402663279', '2014-06-13 20:41:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663279</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7546', '1402663294', '2014-06-13 20:41:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663302\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663302</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7547', '1402663294', '2014-06-13 20:41:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663294</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7548', '1402663554', '2014-06-13 20:45:54', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663562\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024394126281488517\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663562</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024394126281488517</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7549', '1402663554', '2014-06-13 20:45:54', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663554</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7550', '1402663681', '2014-06-13 20:48:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663689\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6024394671742335125\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663689</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6024394671742335125</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7551', '1402663681', '2014-06-13 20:48:01', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[hello1]]></Title><Description><![CDATA[hello2]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/53.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663681</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7552', '1402663736', '2014-06-13 20:48:56', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663744\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"网站\";s:5:\"MsgId\";s:19:\"6024394907965536431\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663744</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[网站]]></Content>\n<MsgId>6024394907965536431</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7553', '1402663736', '2014-06-13 20:48:56', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首页]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663736</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7554', '1402663805', '2014-06-13 20:50:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402663813\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"网站\";s:5:\"MsgId\";s:19:\"6024395204318279871\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402663813</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[网站]]></Content>\n<MsgId>6024395204318279871</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7555', '1402663805', '2014-06-13 20:50:05', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首页]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402663805</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7556', '1402664032', '2014-06-13 20:53:52', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402664039\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"网站\";s:5:\"MsgId\";s:19:\"6024396174980888782\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402664039</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[网站]]></Content>\n<MsgId>6024396174980888782</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7557', '1402664032', '2014-06-13 20:53:52', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首页]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402664031</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7558', '1402664221', '2014-06-13 20:57:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402664229\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"网站\";s:5:\"MsgId\";s:19:\"6024396991024675065\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402664229</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[网站]]></Content>\n<MsgId>6024396991024675065</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7559', '1402664221', '2014-06-13 20:57:01', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[微官网首页]]></Title><Description><![CDATA[微官网首页]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402664221</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7560', '1402688415', '2014-06-14 03:40:15', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688423\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688423</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7561', '1402688416', '2014-06-14 03:40:16', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688415</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7562', '1402688426', '2014-06-14 03:40:26', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688435\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688435</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7563', '1402688427', '2014-06-14 03:40:27', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688426</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7564', '1402688437', '2014-06-14 03:40:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688445\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子时光\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688445</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子时光]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7565', '1402688437', '2014-06-14 03:40:37', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688437</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7566', '1402688449', '2014-06-14 03:40:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688458\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688458</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7567', '1402688450', '2014-06-14 03:40:50', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688449</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7568', '1402688487', '2014-06-14 03:41:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688496\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"会员积分\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688496</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[会员积分]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7569', '1402688488', '2014-06-14 03:41:28', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688487</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7570', '1402688493', '2014-06-14 03:41:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688501\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688501</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7571', '1402688493', '2014-06-14 03:41:33', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688493</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7572', '1402688536', '2014-06-14 03:42:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402688544\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微网�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402688544</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微网站]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7573', '1402688536', '2014-06-14 03:42:16', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[去IT爱好者看看吧！很有趣的网站~自行百度哦~]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402688536</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7574', '1402729425', '2014-06-14 15:03:45', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuL1V3a8-64hyvBAVwlWHACs\";s:10:\"CreateTime\";s:10:\"1402729435\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuL1V3a8-64hyvBAVwlWHACs]]></FromUserName>\n<CreateTime>1402729435</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7575', '1402729425', '2014-06-14 15:03:45', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuL1V3a8-64hyvBAVwlWHACs]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402729425</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7576', '1402729988', '2014-06-14 15:13:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuEXOLwTo0dYNRrePYkGf2PA\";s:10:\"CreateTime\";s:10:\"1402729998\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuEXOLwTo0dYNRrePYkGf2PA]]></FromUserName>\n<CreateTime>1402729998</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7577', '1402729988', '2014-06-14 15:13:08', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuEXOLwTo0dYNRrePYkGf2PA]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402729988</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7578', '1402730344', '2014-06-14 15:19:04', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402730354\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"荆州天气\";s:5:\"MsgId\";s:19:\"6024680995737129859\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402730354</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[荆州天气]]></Content>\n<MsgId>6024680995737129859</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7579', '1402730345', '2014-06-14 15:19:05', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[【荆州�\�\r\n2014�\�3�\�4日星期二\r\n今天天气�\�13℃~6�\� 阴转多云，微�\�  \r\n紫外线指数：最�\�  \r\n明天天气�\�13℃~4�\� 阴转小雨，微�\� \r\n后天天气�\�7℃~2�\� \r\n小雨，微风]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402730344</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7580', '1402730386', '2014-06-14 15:19:46', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402730396\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"武汉天气\";s:5:\"MsgId\";s:19:\"6024681176125756298\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402730396</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[武汉天气]]></Content>\n<MsgId>6024681176125756298</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7581', '1402730386', '2014-06-14 15:19:46', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[【武汉�\�\r\n2014�\�3�\�4日星期二\r\n今天天气�\�13℃~5�\� 阴转多云，微�\�  \r\n紫外线指数：最�\�  \r\n明天天气�\�14℃~4�\� 多云转小雨，微风 \r\n后天天气�\�8℃~2�\� \r\n小雨，微风]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402730386</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7582', '1402738182', '2014-06-14 17:29:42', 'a:11:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuA67gHUWZLkygIOZDUBFyHo\";s:10:\"CreateTime\";s:10:\"1402738191\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:17:\"MASSSENDJOBFINISH\";s:5:\"MsgID\";s:5:\"57954\";s:6:\"Status\";s:12:\"send success\";s:10:\"TotalCount\";s:3:\"795\";s:11:\"FilterCount\";s:3:\"785\";s:9:\"SentCount\";s:3:\"785\";s:10:\"ErrorCount\";s:1:\"0\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuA67gHUWZLkygIOZDUBFyHo]]></FromUserName>\n<CreateTime>1402738191</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[MASSSENDJOBFINISH]]></Event>\n<MsgID>57954</MsgID>\n<Status><![CDATA[send success]]></Status>\n<TotalCount>795</TotalCount>\n<FilterCount>785</FilterCount>\n<SentCount>785</SentCount>\n<ErrorCount>0</ErrorCount>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7583', '1402738753', '2014-06-14 17:39:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuDLaHcq1XQY3opqJSpOJHa8\";s:10:\"CreateTime\";s:10:\"1402738763\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuDLaHcq1XQY3opqJSpOJHa8]]></FromUserName>\n<CreateTime>1402738763</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7584', '1402740090', '2014-06-14 18:01:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402740100\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"天气\";s:5:\"MsgId\";s:19:\"6024722854488398695\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402740100</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[天气]]></Content>\n<MsgId>6024722854488398695</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7585', '1402740095', '2014-06-14 18:01:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402740100\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"天气\";s:5:\"MsgId\";s:19:\"6024722854488398695\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402740100</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[天气]]></Content>\n<MsgId>6024722854488398695</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7586', '1402740100', '2014-06-14 18:01:40', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402740100\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"天气\";s:5:\"MsgId\";s:19:\"6024722854488398695\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402740100</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[天气]]></Content>\n<MsgId>6024722854488398695</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7587', '1402740105', '2014-06-14 18:01:45', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402740100\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"天气\";s:5:\"MsgId\";s:19:\"6024722854488398695\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402740100</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[天气]]></Content>\n<MsgId>6024722854488398695</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7588', '1402740109', '2014-06-14 18:01:49', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402740095</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7589', '1402740113', '2014-06-14 18:01:53', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402740100</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7590', '1402740114', '2014-06-14 18:01:54', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402740090</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7591', '1402740119', '2014-06-14 18:01:59', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402740105</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7592', '1402740127', '2014-06-14 18:02:07', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402740137\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"荆州天气\";s:5:\"MsgId\";s:19:\"6024723013402188651\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402740137</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[荆州天气]]></Content>\n<MsgId>6024723013402188651</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7593', '1402740128', '2014-06-14 18:02:08', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[【荆州�\�\r\n2014�\�3�\�4日星期二\r\n今天天气�\�13℃~6�\� 阴转多云，微�\�  \r\n紫外线指数：最�\�  \r\n明天天气�\�13℃~4�\� 阴转小雨，微�\� \r\n后天天气�\�7℃~2�\� \r\n小雨，微风]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402740127</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7594', '1402794093', '2014-06-15 09:01:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402794103\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024954795607288560\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402794103</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024954795607288560</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7595', '1402794093', '2014-06-15 09:01:33', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402794093</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7596', '1402794439', '2014-06-15 09:07:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402794448\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402794448</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7597', '1402794485', '2014-06-15 09:08:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402794494\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402794494</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7598', '1402794485', '2014-06-15 09:08:05', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402794485</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7599', '1402794622', '2014-06-15 09:10:22', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402794631\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:5:\"hello\";s:5:\"MsgId\";s:19:\"6024957063350020934\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402794631</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hello]]></Content>\n<MsgId>6024957063350020934</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7600', '1402794622', '2014-06-15 09:10:22', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402794622</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7601', '1402794685', '2014-06-15 09:11:25', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402794693\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:4:\"test\";s:5:\"MsgId\";s:19:\"6024957329637993297\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402794693</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[test]]></Content>\n<MsgId>6024957329637993297</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7602', '1402794685', '2014-06-15 09:11:25', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[tesat]]></Title><Description><![CDATA[tests]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/52.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402794685</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7603', '1402795029', '2014-06-15 09:17:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402795037\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402795037</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7604', '1402795080', '2014-06-15 09:18:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402795090\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402795090</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7605', '1402795080', '2014-06-15 09:18:00', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402795080</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7606', '1402795356', '2014-06-15 09:22:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402795366\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402795366</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7607', '1402795368', '2014-06-15 09:22:48', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402795356</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7608', '1402795370', '2014-06-15 09:22:50', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402795379\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402795379</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7609', '1402795373', '2014-06-15 09:22:53', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402795370</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7610', '1402795387', '2014-06-15 09:23:07', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402795396\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402795396</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7611', '1402795388', '2014-06-15 09:23:08', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402795387</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7612', '1402795452', '2014-06-15 09:24:12', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402795461\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"育儿互动\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402795461</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[育儿互动]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7613', '1402795453', '2014-06-15 09:24:13', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402795452</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7614', '1402795642', '2014-06-15 09:27:22', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402795651\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:4:\"test\";s:5:\"MsgId\";s:19:\"6024961444216662951\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402795651</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[test]]></Content>\n<MsgId>6024961444216662951</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7615', '1402795642', '2014-06-15 09:27:22', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[tesat]]></Title><Description><![CDATA[tests]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/52.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402795642</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7616', '1402796667', '2014-06-15 09:44:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402796677\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402796677</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7617', '1402796667', '2014-06-15 09:44:27', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402796667</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7618', '1402796703', '2014-06-15 09:45:03', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402796712\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402796712</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7619', '1402796710', '2014-06-15 09:45:10', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402796703</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7620', '1402796818', '2014-06-15 09:46:58', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402796827\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:4:\"test\";s:5:\"MsgId\";s:19:\"6024966495098203131\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402796827</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[test]]></Content>\n<MsgId>6024966495098203131</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7621', '1402796818', '2014-06-15 09:46:58', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402796818</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7622', '1402796870', '2014-06-15 09:47:50', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402796880\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024966722731469821\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402796880</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024966722731469821</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7623', '1402796870', '2014-06-15 09:47:50', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402796870</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7624', '1402796914', '2014-06-15 09:48:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402796924\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"学前教育\";s:5:\"MsgId\";s:19:\"6024966911710030849\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402796924</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[学前教育]]></Content>\n<MsgId>6024966911710030849</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7625', '1402796914', '2014-06-15 09:48:34', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402796914</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7626', '1402797117', '2014-06-15 09:51:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402797126\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"育儿宝典\";s:5:\"MsgId\";s:19:\"6024967779293424653\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402797126</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[育儿宝典]]></Content>\n<MsgId>6024967779293424653</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7627', '1402797118', '2014-06-15 09:51:58', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402797116</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7628', '1402797485', '2014-06-15 09:58:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402797494\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402797494</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7629', '1402797486', '2014-06-15 09:58:06', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402797485</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7630', '1402797720', '2014-06-15 10:02:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402797730\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402797730</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7631', '1402797722', '2014-06-15 10:02:02', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402797720</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7632', '1402798044', '2014-06-15 10:07:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402798053\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024971760728108104\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402798053</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024971760728108104</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7633', '1402798044', '2014-06-15 10:07:24', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402798044</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7634', '1402798898', '2014-06-15 10:21:38', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402798906\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402798906</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7635', '1402798898', '2014-06-15 10:21:38', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402798898</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7636', '1402799027', '2014-06-15 10:23:47', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402799035\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024975978385992822\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402799035</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024975978385992822</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7637', '1402799027', '2014-06-15 10:23:47', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799027</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7638', '1402799031', '2014-06-15 10:23:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402799041\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402799041</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7639', '1402799031', '2014-06-15 10:23:51', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuJbkoTqSEMqfT_aZhANLxzc.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799031</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7640', '1402799079', '2014-06-15 10:24:39', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402799088\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024976206019259513\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402799088</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024976206019259513</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7641', '1402799079', '2014-06-15 10:24:39', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799078</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7642', '1402799105', '2014-06-15 10:25:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402799114\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024976317688409214\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402799114</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024976317688409214</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7643', '1402799105', '2014-06-15 10:25:05', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799105</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7644', '1402799110', '2014-06-15 10:25:10', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402799119\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402799119</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7645', '1402799110', '2014-06-15 10:25:10', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuJbkoTqSEMqfT_aZhANLxzc/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799110</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7646', '1402799116', '2014-06-15 10:25:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402799126\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6024976369228016769\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402799126</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6024976369228016769</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7647', '1402799116', '2014-06-15 10:25:16', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799116</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7648', '1402799120', '2014-06-15 10:25:20', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402799130\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"酷珠早教\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402799130</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[酷珠早教]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7649', '1402799121', '2014-06-15 10:25:21', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799120</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7650', '1402799127', '2014-06-15 10:25:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402799136\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6024976412177689732\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402799136</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6024976412177689732</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7651', '1402799127', '2014-06-15 10:25:27', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402799127</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7652', '1402800423', '2014-06-15 10:47:03', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800431\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800431</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7653', '1402800424', '2014-06-15 10:47:04', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800423</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7654', '1402800429', '2014-06-15 10:47:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800439\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800439</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7655', '1402800430', '2014-06-15 10:47:10', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800429</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7656', '1402800496', '2014-06-15 10:48:16', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800506\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800506</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7657', '1402800497', '2014-06-15 10:48:17', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800496</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7658', '1402800502', '2014-06-15 10:48:22', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800511\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800511</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7659', '1402800502', '2014-06-15 10:48:22', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800501</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7660', '1402800600', '2014-06-15 10:50:00', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800609\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800609</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7661', '1402800620', '2014-06-15 10:50:20', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800630\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800630</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7662', '1402800620', '2014-06-15 10:50:20', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800620</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7663', '1402800635', '2014-06-15 10:50:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800644\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800644</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7664', '1402800636', '2014-06-15 10:50:36', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800635</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7665', '1402800640', '2014-06-15 10:50:40', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402800650\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402800650</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7666', '1402800641', '2014-06-15 10:50:41', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402800640</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7667', '1402801227', '2014-06-15 11:00:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402801235\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402801235</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7668', '1402801235', '2014-06-15 11:00:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402801244\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402801244</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7669', '1402801237', '2014-06-15 11:00:37', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801235</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7670', '1402801241', '2014-06-15 11:00:41', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801227</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7671', '1402801841', '2014-06-15 11:10:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402801850\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402801850</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7672', '1402801841', '2014-06-15 11:10:41', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801841</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7673', '1402801874', '2014-06-15 11:11:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402801884\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402801884</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7674', '1402801886', '2014-06-15 11:11:26', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801874</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7675', '1402801887', '2014-06-15 11:11:27', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402801897\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"营养饮食\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402801897</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[营养饮食]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7676', '1402801899', '2014-06-15 11:11:39', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801887</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7677', '1402801904', '2014-06-15 11:11:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402801914\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402801914</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7678', '1402801904', '2014-06-15 11:11:44', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801904</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7679', '1402801977', '2014-06-15 11:12:57', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402801987\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402801987</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7680', '1402801977', '2014-06-15 11:12:57', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402801977</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7681', '1402802779', '2014-06-15 11:26:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402802788\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402802788</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7682', '1402802779', '2014-06-15 11:26:19', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402802779</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7683', '1402803178', '2014-06-15 11:32:58', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402803188\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402803188</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7684', '1402803178', '2014-06-15 11:32:58', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402803178</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7685', '1402803210', '2014-06-15 11:33:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402803220\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"关于我们\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402803220</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[关于我们]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7686', '1402803218', '2014-06-15 11:33:38', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402803228\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402803228</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7687', '1402803218', '2014-06-15 11:33:38', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402803218</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7688', '1402803221', '2014-06-15 11:33:41', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402803210</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7689', '1402804859', '2014-06-15 12:00:59', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402804869\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:12:\"建议意见\";s:5:\"MsgId\";s:19:\"6025001035225198266\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402804869</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[建议意见]]></Content>\n<MsgId>6025001035225198266</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7690', '1402804859', '2014-06-15 12:00:59', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[建议意见]]></Title><Description><![CDATA[请点击进入填写反馈内容]]></Description><PicUrl><![CDATA[http://weiphp.cn/Public/Home/images/about/logo.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/Suggestions/Suggestions/suggest/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402804859</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7691', '1402806277', '2014-06-15 12:24:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402806286\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"首页\";s:5:\"MsgId\";s:19:\"6025007121193856855\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402806286</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[首页]]></Content>\n<MsgId>6025007121193856855</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7692', '1402806277', '2014-06-15 12:24:37', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402806277</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7693', '1402806301', '2014-06-15 12:25:01', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402806311\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:135:\"http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html\";s:5:\"MsgId\";s:19:\"6025007228568039259\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402806311</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Content>\n<MsgId>6025007228568039259</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7694', '1402806303', '2014-06-15 12:25:03', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[你话好多啊，不跟你聊了]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402806301</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7695', '1402806351', '2014-06-15 12:25:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402806361\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:6:\"微信\";s:5:\"MsgId\";s:19:\"6025007443316404061\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402806361</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微信]]></Content>\n<MsgId>6025007443316404061</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7696', '1402806351', '2014-06-15 12:25:51', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[首页]]></Title><Description><![CDATA[首页]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[/index.php?s=/addon/WeiSite/WeiSite/index.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402806351</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7697', '1402809127', '2014-06-15 13:12:07', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402809137\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402809137</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7698', '1402809154', '2014-06-15 13:12:34', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402809164\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402809164</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7699', '1402809154', '2014-06-15 13:12:34', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402809154</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7700', '1402810789', '2014-06-15 13:39:49', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402810799\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"会员�\�\";s:5:\"MsgId\";s:19:\"6025026504381264179\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402810799</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[会员卡]]></Content>\n<MsgId>6025026504381264179</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7701', '1402810789', '2014-06-15 13:39:49', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[时尚美容美发店VIP会员卡]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Addons/Card/View/default/Public/cover.png]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/Card/Card/show/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402810789</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7702', '1402818473', '2014-06-15 15:47:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJbkoTqSEMqfT_aZhANLxzc\";s:10:\"CreateTime\";s:10:\"1402818482\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></FromUserName>\n<CreateTime>1402818482</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7703', '1402818473', '2014-06-15 15:47:53', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuJbkoTqSEMqfT_aZhANLxzc.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJbkoTqSEMqfT_aZhANLxzc]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402818473</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7704', '1402819191', '2014-06-15 15:59:51', 'a:11:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuA67gHUWZLkygIOZDUBFyHo\";s:10:\"CreateTime\";s:10:\"1402819201\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:17:\"MASSSENDJOBFINISH\";s:5:\"MsgID\";s:5:\"58114\";s:6:\"Status\";s:12:\"send success\";s:10:\"TotalCount\";s:3:\"795\";s:11:\"FilterCount\";s:3:\"785\";s:9:\"SentCount\";s:3:\"785\";s:10:\"ErrorCount\";s:1:\"0\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuA67gHUWZLkygIOZDUBFyHo]]></FromUserName>\n<CreateTime>1402819201</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[MASSSENDJOBFINISH]]></Event>\n<MsgID>58114</MsgID>\n<Status><![CDATA[send success]]></Status>\n<TotalCount>795</TotalCount>\n<FilterCount>785</FilterCount>\n<SentCount>785</SentCount>\n<ErrorCount>0</ErrorCount>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7705', '1402820347', '2014-06-15 16:19:07', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO8Ot-eM4mXBWCqgyrUuyrY\";s:10:\"CreateTime\";s:10:\"1402820357\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO8Ot-eM4mXBWCqgyrUuyrY]]></FromUserName>\n<CreateTime>1402820357</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7706', '1402820347', '2014-06-15 16:19:07', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO8Ot-eM4mXBWCqgyrUuyrY/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO8Ot-eM4mXBWCqgyrUuyrY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402820347</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7707', '1402820360', '2014-06-15 16:19:20', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO8Ot-eM4mXBWCqgyrUuyrY\";s:10:\"CreateTime\";s:10:\"1402820370\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO8Ot-eM4mXBWCqgyrUuyrY]]></FromUserName>\n<CreateTime>1402820370</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7708', '1402820360', '2014-06-15 16:19:20', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO8Ot-eM4mXBWCqgyrUuyrY/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO8Ot-eM4mXBWCqgyrUuyrY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402820360</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7709', '1402821510', '2014-06-15 16:38:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402821521\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:10:\"hellottest\";s:5:\"MsgId\";s:19:\"6025072555020612883\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402821521</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hellottest]]></Content>\n<MsgId>6025072555020612883</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7710', '1402821510', '2014-06-15 16:38:30', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402821510</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7711', '1402821570', '2014-06-15 16:39:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402821580\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:10:\"hellottest\";s:5:\"MsgId\";s:19:\"6025072808423683353\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402821580</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hellottest]]></Content>\n<MsgId>6025072808423683353</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7712', '1402821575', '2014-06-15 16:39:35', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402821580\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:10:\"hellottest\";s:5:\"MsgId\";s:19:\"6025072808423683353\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402821580</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[hellottest]]></Content>\n<MsgId>6025072808423683353</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7713', '1402821576', '2014-06-15 16:39:36', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402821575</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7714', '1402821582', '2014-06-15 16:39:42', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[哈哈~~]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402821570</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7715', '1402822939', '2014-06-15 17:02:19', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuOzNLvJDBzj8MJ46znKyLbU\";s:10:\"CreateTime\";s:10:\"1402822948\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></FromUserName>\n<CreateTime>1402822948</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7716', '1402822939', '2014-06-15 17:02:19', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402822939</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7717', '1402822964', '2014-06-15 17:02:44', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuOzNLvJDBzj8MJ46znKyLbU\";s:10:\"CreateTime\";s:10:\"1402822974\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"成长教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></FromUserName>\n<CreateTime>1402822974</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[成长教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7718', '1402822964', '2014-06-15 17:02:44', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[只要三招 有效教育任性宝宝]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d12455695d.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuOzNLvJDBzj8MJ46znKyLbU/id/65.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402822963</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7719', '1402825187', '2014-06-15 17:39:47', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuOzNLvJDBzj8MJ46znKyLbU\";s:10:\"CreateTime\";s:10:\"1402825198\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"成长教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></FromUserName>\n<CreateTime>1402825198</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[成长教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7720', '1402825187', '2014-06-15 17:39:47', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[只要三招 有效教育任性宝宝]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d12455695d.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuOzNLvJDBzj8MJ46znKyLbU/id/65.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402825187</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7721', '1402825220', '2014-06-15 17:40:20', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuOzNLvJDBzj8MJ46znKyLbU\";s:10:\"CreateTime\";s:10:\"1402825231\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></FromUserName>\n<CreateTime>1402825231</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7722', '1402825220', '2014-06-15 17:40:20', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuOzNLvJDBzj8MJ46znKyLbU/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuOzNLvJDBzj8MJ46znKyLbU]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402825220</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7723', '1402828769', '2014-06-15 18:39:29', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuLBlcRHK-6QTiJeB9XIbU8o\";s:10:\"CreateTime\";s:10:\"1402828780\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuLBlcRHK-6QTiJeB9XIbU8o]]></FromUserName>\n<CreateTime>1402828780</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7724', '1402828770', '2014-06-15 18:39:30', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuLBlcRHK-6QTiJeB9XIbU8o]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402828769</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7725', '1402842665', '2014-06-15 22:31:05', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuJJRYcUbIEMw8gzbjRndC38\";s:10:\"CreateTime\";s:10:\"1402842676\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子游戏\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuJJRYcUbIEMw8gzbjRndC38]]></FromUserName>\n<CreateTime>1402842676</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子游戏]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7726', '1402842666', '2014-06-15 22:31:06', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[夏天如何陪伴宝宝安全玩水]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d0bd16b769.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuJJRYcUbIEMw8gzbjRndC38/id/61.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuJJRYcUbIEMw8gzbjRndC38]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402842665</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7727', '1402882483', '2014-06-16 09:34:43', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuGIHftATRBxGwZugNAqHv8s\";s:10:\"CreateTime\";s:10:\"1402882493\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></FromUserName>\n<CreateTime>1402882493</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7728', '1402882484', '2014-06-16 09:34:44', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuGIHftATRBxGwZugNAqHv8s/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuGIHftATRBxGwZugNAqHv8s]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402882483</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7729', '1402886413', '2014-06-16 10:40:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886426\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886426</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7730', '1402886414', '2014-06-16 10:40:14', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO7WZTzsav94y606TZ23lK4/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886413</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7731', '1402886447', '2014-06-16 10:40:47', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886458\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"成长教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886458</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[成长教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7732', '1402886447', '2014-06-16 10:40:47', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[只要三招 有效教育任性宝宝]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d12455695d.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO7WZTzsav94y606TZ23lK4/id/65.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886446</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7733', '1402886458', '2014-06-16 10:40:58', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886470\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886470</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7734', '1402886458', '2014-06-16 10:40:58', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO7WZTzsav94y606TZ23lK4/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886458</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7735', '1402886466', '2014-06-16 10:41:06', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886479\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子游戏\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886479</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子游戏]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7736', '1402886466', '2014-06-16 10:41:06', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[夏天如何陪伴宝宝安全玩水]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d0bd16b769.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO7WZTzsav94y606TZ23lK4/id/61.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886466</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7737', '1402886473', '2014-06-16 10:41:13', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886486\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"备孕知识\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886486</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[备孕知识]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7738', '1402886474', '2014-06-16 10:41:14', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886473</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7739', '1402886477', '2014-06-16 10:41:17', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886489\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"孕期知识\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886489</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[孕期知识]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7740', '1402886477', '2014-06-16 10:41:17', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886477</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7741', '1402886480', '2014-06-16 10:41:20', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886492\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"产后康复\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886492</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[产后康复]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7742', '1402886481', '2014-06-16 10:41:21', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886480</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7743', '1402886484', '2014-06-16 10:41:24', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuO7WZTzsav94y606TZ23lK4\";s:10:\"CreateTime\";s:10:\"1402886497\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></FromUserName>\n<CreateTime>1402886497</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7744', '1402886484', '2014-06-16 10:41:24', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuO7WZTzsav94y606TZ23lK4/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuO7WZTzsav94y606TZ23lK4]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886484</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7745', '1402886651', '2014-06-16 10:44:11', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886663\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886663</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7746', '1402886651', '2014-06-16 10:44:11', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886651</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7747', '1402886695', '2014-06-16 10:44:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886706\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"成长教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886706</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[成长教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7748', '1402886695', '2014-06-16 10:44:55', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[只要三招 有效教育任性宝宝]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d12455695d.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/65.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886695</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7749', '1402886733', '2014-06-16 10:45:33', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886746\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"成长教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886746</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[成长教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7750', '1402886733', '2014-06-16 10:45:33', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[只要三招 有效教育任性宝宝]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d12455695d.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/65.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886733</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7751', '1402886802', '2014-06-16 10:46:42', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886815\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"宝贝秀\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886815</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[宝贝秀]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7752', '1402886803', '2014-06-16 10:46:43', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[我今天累了，明天再陪你聊天吧]]></Content><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886802</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7753', '1402886815', '2014-06-16 10:46:55', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886827\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:9:\"微官�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886827</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[微官网]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7754', '1402886815', '2014-06-16 10:46:55', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886815</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7755', '1402886872', '2014-06-16 10:47:52', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886883\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886883</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7756', '1402886872', '2014-06-16 10:47:52', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886872</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7757', '1402886983', '2014-06-16 10:49:43', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402886995\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402886995</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7758', '1402886984', '2014-06-16 10:49:44', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402886983</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7759', '1402887126', '2014-06-16 10:52:06', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887139\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"成长教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887139</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[成长教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7760', '1402887126', '2014-06-16 10:52:06', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[只要三招 有效教育任性宝宝]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d12455695d.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/65.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887126</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7761', '1402887362', '2014-06-16 10:56:02', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887374\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子游戏\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887374</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子游戏]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7762', '1402887363', '2014-06-16 10:56:03', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[夏天如何陪伴宝宝安全玩水]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d0bd16b769.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/61.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887362</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7763', '1402887401', '2014-06-16 10:56:41', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887413\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"一周资�\�\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887413</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[一周资讯]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7764', '1402887402', '2014-06-16 10:56:42', '<?xml version=\"1.0\"?>\n<xml><Content>123</Content><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887401</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7765', '1402887428', '2014-06-16 10:57:08', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887441\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子游戏\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887441</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子游戏]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7766', '1402887428', '2014-06-16 10:57:08', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[夏天如何陪伴宝宝安全玩水]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d0bd16b769.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/61.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887428</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7767', '1402887448', '2014-06-16 10:57:28', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887461\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887461</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7768', '1402887448', '2014-06-16 10:57:28', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887448</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7769', '1402887533', '2014-06-16 10:58:53', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887546\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"孕期知识\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887546</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[孕期知识]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7770', '1402887534', '2014-06-16 10:58:54', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[虽然不懂，但觉得你说得很对]]></Content><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887533</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7771', '1402887729', '2014-06-16 11:02:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887740\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"亲子游戏\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887740</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[亲子游戏]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7772', '1402887729', '2014-06-16 11:02:09', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[夏天如何陪伴宝宝安全玩水]]></Title><Description><![CDATA[]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-15/539d0bd16b769.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/61.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887729</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7773', '1402887756', '2014-06-16 11:02:36', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887768\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"学前教育\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887768</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[学前教育]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7774', '1402887756', '2014-06-16 11:02:36', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[教你愉快亲子教育六个小方法]]></Title><Description><![CDATA[允许儿童按照他们自己的兴趣去做事是非常重要的，这也是帮助他们成功的最佳途径之一。如果你让孩子感到她有选择去学芭蕾舞或是去练健美操的自由，她就会更卖力气地去做这两件事中她所选中的那件�\� ]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539b00689f087.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/55.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887756</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7775', '1402887776', '2014-06-16 11:02:56', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuFBUMzLNp4ASWPQWojAF_ZY\";s:10:\"CreateTime\";s:10:\"1402887789\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:5:\"CLICK\";s:8:\"EventKey\";s:12:\"健康保健\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></FromUserName>\n<CreateTime>1402887789</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[CLICK]]></Event>\n<EventKey><![CDATA[健康保健]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7776', '1402887776', '2014-06-16 11:02:56', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[宝宝抱着睡易致脊柱弯曲]]></Title><Description><![CDATA[许多妈妈反映宝宝黏人，总要抱着才能入睡，一放下孩子就哭闹不休；也有些长辈特疼孩子，希望长时间与其亲密接触，但是像这样长时间“抱不离手”，很有可能导致孩子脊柱非正常弯曲。]]></Description><PicUrl><![CDATA[http://joint4.xicp.net/Uploads/Picture/2014-06-13/539af42e65084.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/index.php?s=/addon/CustomReply/CustomReply/detail/token/gh_ccbc7c79380e/openid/oTsZWuFBUMzLNp4ASWPQWojAF_ZY/id/56.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuFBUMzLNp4ASWPQWojAF_ZY]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402887776</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7777', '1402889992', '2014-06-16 11:39:52', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890002\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890002</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7778', '1402890030', '2014-06-16 11:40:30', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890042\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890042</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7779', '1402890030', '2014-06-16 11:40:30', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402890030</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7780', '1402890050', '2014-06-16 11:40:50', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890063\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:57:\"/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890063</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7781', '1402890074', '2014-06-16 11:41:14', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890087\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:57:\"/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/63.html\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890087</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/63.html]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7782', '1402890111', '2014-06-16 11:41:51', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890122\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:57:\"/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/70.html\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890122</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/70.html]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7783', '1402890217', '2014-06-16 11:43:37', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890230\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:57:\"/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890230</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7784', '1402890228', '2014-06-16 11:43:48', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890239\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:11:\"unsubscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890239</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[unsubscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7785', '1402890238', '2014-06-16 11:43:58', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890251\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:9:\"subscribe\";s:8:\"EventKey\";s:0:\"\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890251</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[subscribe]]></Event>\n<EventKey><![CDATA[]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7786', '1402890238', '2014-06-16 11:43:58', '<?xml version=\"1.0\"?>\n<xml><Content><![CDATA[欢迎来到酷珠儿童成长学堂�\�\r\n]]></Content><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402890238</CreateTime><MsgType><![CDATA[text]]></MsgType></xml>\n', '_replyData');
INSERT INTO `wp_weixin_log` VALUES ('7787', '1402890249', '2014-06-16 11:44:09', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890262\";s:7:\"MsgType\";s:5:\"event\";s:5:\"Event\";s:4:\"VIEW\";s:8:\"EventKey\";s:63:\"/kuzhu/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890262</CreateTime>\n<MsgType><![CDATA[event]]></MsgType>\n<Event><![CDATA[VIEW]]></Event>\n<EventKey><![CDATA[/kuzhu/index.php?s=/addon/WeiSite/WeiSite/lists/cate_id/61.html]]></EventKey>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7788', '1402890476', '2014-06-16 11:47:56', 'a:6:{s:10:\"ToUserName\";s:15:\"gh_ccbc7c79380e\";s:12:\"FromUserName\";s:28:\"oTsZWuNOJAnjoXJStasWFY4VKNoI\";s:10:\"CreateTime\";s:10:\"1402890489\";s:7:\"MsgType\";s:4:\"text\";s:7:\"Content\";s:9:\"微官�\�\";s:5:\"MsgId\";s:19:\"6025368770325087603\";}', '<xml><ToUserName><![CDATA[gh_ccbc7c79380e]]></ToUserName>\n<FromUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></FromUserName>\n<CreateTime>1402890489</CreateTime>\n<MsgType><![CDATA[text]]></MsgType>\n<Content><![CDATA[微官网]]></Content>\n<MsgId>6025368770325087603</MsgId>\n</xml>');
INSERT INTO `wp_weixin_log` VALUES ('7789', '1402890476', '2014-06-16 11:47:56', '<?xml version=\"1.0\"?>\n<xml><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[点击进入首页]]></Title><Description>123</Description><PicUrl><![CDATA[http://joint4.xicp.net/kuzhu/Uploads/Picture/2014-06-11/539822745fab7.jpg]]></PicUrl><Url><![CDATA[http://joint4.xicp.net/kuzhu/index.php?s=/addon/WeiSite/WeiSite/index/token/gh_ccbc7c79380e/openid/oTsZWuNOJAnjoXJStasWFY4VKNoI.html]]></Url></item></Articles><ToUserName><![CDATA[oTsZWuNOJAnjoXJStasWFY4VKNoI]]></ToUserName><FromUserName><![CDATA[gh_ccbc7c79380e]]></FromUserName><CreateTime>1402890476</CreateTime><MsgType><![CDATA[news]]></MsgType></xml>\n', '_replyData');
